# Skinceptor — Roadmap

## Foundation
- [x] Choose visual direction (design directions shown to user)
- [x] Design system in src/styles.css (editorial/scientific, semantic node-category colors)
- [x] Data model + curated dataset: 54 ingredients with formula, MW, PubChem/UniProt refs, targets, genes/proteins, pathways, processes, studies (PMID/DOI, type, sample size, limitations)
- [x] Evidence engine (Skinceptor Evidence Index, experimental, transparent weights)
- [x] Smart search with synonyms/fuzzy ("vit b3", "HA", topics)

## Routes
- [x] `/` landing: hero, search, example chips, featured pathways, quick entry cards
- [x] `/explore`
- [x] `/ingredient/$slug`: identity card, molecular view, interactive network graph (zoom/pan/focus/node drawer/confidence), pathway cards, evidence dashboard, filterable timeline, citations, sources
- [x] `/topic/$slug`: skin barrier, photoaging & collagen, melanogenesis, hair follicle cycling, epidermal turnover
- [x] `/research`: searchable/filterable literature with DOI/PMID links
- [x] `/compare`: side-by-side, shared vs distinct pathways
- [x] `/claim-checker`: claim → concepts → supporting/mixed evidence → pathway map
- [x] `/art`: deterministic generative styles (Constellation, Galaxy, Cellular Tapestry, Fingerprint), export
- [x] `/methodology`, `/sources`

## Cross-cutting
- [x] Mobile-responsive graph mode, accessibility (ARIA, keyboard, reduced motion, text alternatives)
- [x] Empty/error states, no fabricated data ("Data unavailable")
- [x] Medical/claims disclaimers throughout
- [x] Per-route head() metadata
- [x] Docs: README, ARCHITECTURE, DATA_MODEL, EVIDENCE_METHODOLOGY

## Accounts (Lovable Cloud)
- [x] Email sign-in, protected library area
- [x] Saved searches & saved claims
- [x] Personal ingredient/biology-map library with private notes
- [x] User-submitted evidence with review status + public approved list
- [x] AI claim analysis (mechanism steps, gaps, overstated language), saved per user
- [x] Reviewer/admin roles + review queue at /review (approve, decline, return to queue, review notes)
- [x] Structured data (JSON-LD) + canonical URLs on home and ingredient pages
- [x] Agent integrations (MCP): 7 tools, sign-in-protected, consent screen
- [x] Dataset expansion to 54 ingredients (adapalene, benzoyl peroxide, mandelic acid, ascorbyl glucoside, polyglutamic acid, avenanthramides) with second studies for previously single-study entries
- [x] Retrieved-date freshness check on every database reference (per-reference badge + dataset roll-up on /sources)

## Evidence depth & UX (done)
- [x] Claim-checker cites the specific curated studies behind each mechanism step
- [x] Replicated / single-study flags on ingredient cards, ingredient pages and comparisons
- [x] "Overstated relative to evidence" badge (local assessment + AI wording flags)
- [x] Simplified tiered biology view, default on small screens
- [x] Comparison + evidence report PDF export and shareable comparison links
- [x] Search keyboard autocomplete and "no results, try X" suggestions
