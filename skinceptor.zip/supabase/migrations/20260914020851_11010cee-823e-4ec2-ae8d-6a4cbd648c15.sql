CREATE OR REPLACE FUNCTION public.update_updated_at_column() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql SET search_path = public;

CREATE TABLE public.saved_searches (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  query text NOT NULL,
  label text,
  kind text NOT NULL DEFAULT 'search',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.saved_searches TO authenticated;
GRANT ALL ON public.saved_searches TO service_role;
ALTER TABLE public.saved_searches ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own saved searches" ON public.saved_searches FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_saved_searches_updated BEFORE UPDATE ON public.saved_searches FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX saved_searches_user_idx ON public.saved_searches (user_id, created_at DESC);

CREATE TABLE public.library_items (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  item_type text NOT NULL CHECK (item_type IN ('ingredient','topic')),
  slug text NOT NULL,
  note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, item_type, slug)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.library_items TO authenticated;
GRANT ALL ON public.library_items TO service_role;
ALTER TABLE public.library_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own library items" ON public.library_items FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_library_items_updated BEFORE UPDATE ON public.library_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.evidence_submissions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  submitter_label text,
  ingredient_slug text,
  topic_slug text,
  title text NOT NULL,
  journal text,
  year integer,
  study_type text NOT NULL DEFAULT 'other',
  sample_size integer,
  pmid text,
  doi text,
  url text,
  summary text NOT NULL,
  limitations text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  review_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.evidence_submissions TO authenticated;
GRANT SELECT ON public.evidence_submissions TO anon;
GRANT ALL ON public.evidence_submissions TO service_role;
ALTER TABLE public.evidence_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anyone can read approved evidence" ON public.evidence_submissions FOR SELECT TO anon, authenticated USING (status = 'approved');
CREATE POLICY "read own evidence" ON public.evidence_submissions FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert own evidence" ON public.evidence_submissions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id AND status = 'pending');
CREATE POLICY "update own pending evidence" ON public.evidence_submissions FOR UPDATE TO authenticated USING (auth.uid() = user_id AND status = 'pending') WITH CHECK (auth.uid() = user_id AND status = 'pending');
CREATE POLICY "delete own evidence" ON public.evidence_submissions FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER trg_evidence_submissions_updated BEFORE UPDATE ON public.evidence_submissions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX evidence_submissions_ingredient_idx ON public.evidence_submissions (ingredient_slug) WHERE status = 'approved';

CREATE TABLE public.claim_analyses (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  claim text NOT NULL,
  verdict text,
  plausibility text,
  analysis jsonb,
  model text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.claim_analyses TO authenticated;
GRANT ALL ON public.claim_analyses TO service_role;
ALTER TABLE public.claim_analyses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own claim analyses" ON public.claim_analyses FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_claim_analyses_updated BEFORE UPDATE ON public.claim_analyses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX claim_analyses_user_idx ON public.claim_analyses (user_id, created_at DESC);