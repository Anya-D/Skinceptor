/**
 * Skinceptor scientific data model.
 *
 * Every biological relationship carries a confidence tier and at least one
 * source reference. Fields are optional wherever public data may be missing —
 * the UI renders "Data unavailable" rather than inventing a value.
 */

export type Confidence = "HIGH" | "MEDIUM" | "LOW";

export type StudyType =
  | "human"
  | "rct"
  | "animal"
  | "in-vitro"
  | "review"
  | "meta-analysis";

export type NodeKind =
  | "ingredient"
  | "molecule"
  | "target"
  | "gene"
  | "protein"
  | "pathway"
  | "process"
  | "outcome";

export type RelationType =
  | "is molecule"
  | "targets"
  | "activates"
  | "inhibits"
  | "modulates"
  | "encoded by"
  | "participates in"
  | "associated with"
  | "expressed in"
  | "studied in";

/** A pointer to a public scientific database record. */
export interface SourceRef {
  db:
    | "PubChem"
    | "UniProt"
    | "NCBI Gene"
    | "Reactome"
    | "Gene Ontology"
    | "ChEBI"
    | "PubMed"
    | "Europe PMC";
  id: string;
  /** ISO date the identifier was curated into this dataset. */
  retrieved: string;
}

export interface TargetRef {
  name: string;
  kind: "enzyme" | "receptor" | "transporter" | "structural protein" | "complex";
  uniprot?: string;
  relation: RelationType;
  confidence: Confidence;
  note?: string;
}

export interface GeneRef {
  symbol: string;
  name: string;
  uniprot?: string;
  ncbiGene?: string;
  confidence: Confidence;
}

export interface PathwayRef {
  name: string;
  db: "Reactome" | "Gene Ontology" | "KEGG" | "Literature";
  id?: string;
  confidence: Confidence;
  summary: string;
}

export interface ProcessRef {
  name: string;
  goId?: string;
  tissue?: string;
  confidence: Confidence;
}

export interface OutcomeRef {
  /** Always phrased as "studied for" / "associated with" — never a promise. */
  name: string;
  confidence: Confidence;
}

export interface MoleculeRef {
  name: string;
  formula?: string;
  molecularWeight?: number;
  pubchemCid?: string;
  note?: string;
}

export interface Study {
  id: string;
  title: string;
  year: number;
  journal: string;
  type: StudyType;
  sampleSize?: number;
  pmid?: string;
  doi?: string;
  /** One-sentence, hedged description of what the study reported. */
  finding: string;
  limitations: string;
  ingredients: string[];
  topics: string[];
}

export type IngredientClass =
  | "Skin barrier"
  | "Antioxidant"
  | "Retinoid"
  | "Peptide"
  | "Pigmentation"
  | "Hair biology"
  | "Exfoliant"
  | "Humectant"
  | "Botanical"
  | "Mineral";

export interface Ingredient {
  slug: string;
  name: string;
  inci?: string;
  aliases: string[];
  className: IngredientClass;
  /** Plain-language, non-clinical summary. */
  summary: string;
  formula?: string;
  molecularWeight?: number;
  pubchemCid?: string;
  chebi?: string;
  smiles?: string;
  molecules: MoleculeRef[];
  targets: TargetRef[];
  genes: GeneRef[];
  pathways: PathwayRef[];
  processes: ProcessRef[];
  outcomes: OutcomeRef[];
  topics: string[];
  sources: SourceRef[];
}

export interface Topic {
  slug: string;
  name: string;
  aliases: string[];
  overview: string;
  genes: GeneRef[];
  pathways: PathwayRef[];
  processes: ProcessRef[];
  ingredients: string[];
  sources: SourceRef[];
}

export interface GraphNode {
  id: string;
  label: string;
  kind: NodeKind;
  /** Column index in the ingredient → outcome chain. */
  tier: number;
  confidence: Confidence;
  detail?: string | undefined;
  href?: string | undefined;
  externalId?: string | undefined;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  relation: RelationType;
  confidence: Confidence;
}

export interface BiologyGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
}
