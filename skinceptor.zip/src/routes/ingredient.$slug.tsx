import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { BiologyNetwork } from "@/components/BiologyNetwork";
import { EvidenceDashboard } from "@/components/EvidenceDashboard";
import { ResearchTimeline, StudyCard } from "@/components/Research";
import { ArtCanvas } from "@/components/ArtCanvas";
import { ConfidenceBadge } from "@/components/ConfidenceBadge";
import { SaveToLibraryButton } from "@/components/AccountActions";
import { CommunityEvidence } from "@/components/CommunityEvidence";
import { SourceList } from "@/components/Provenance";
import { PlainEnglishProvider, PlainEnglishToggle, PlainText } from "@/components/PlainLanguage";

import { ReplicationBadge } from "@/components/EvidenceFlags";
import { replicationFlag } from "@/lib/evidence";
import { exportEvidenceReport } from "@/lib/report";
import { ingredientBySlug } from "@/data/ingredients";
import { studiesForIngredient } from "@/data/studies";
import { topicBySlug } from "@/data/topics";
import { buildIngredientGraph } from "@/lib/graph";
import { externalLink } from "@/lib/links";

export const Route = createFileRoute("/ingredient/$slug")({
  staticData: { sitemap: true },
  loader: ({ params }) => {
    const ingredient = ingredientBySlug.get(params.slug);
    if (!ingredient) throw notFound();
    return {
      slug: ingredient.slug,
      name: ingredient.name,
      summary: ingredient.summary,
      aliases: ingredient.aliases,
      formula: ingredient.formula ?? null,
      molecularWeight: ingredient.molecularWeight ?? null,
      pubchemCid: ingredient.pubchemCid ?? null,
      smiles: ingredient.smiles ?? null,
      inci: ingredient.inci ?? null,
    };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Ingredient unavailable — Skinceptor" }, { name: "robots", content: "noindex" }] };
    }
    const title = `${loaderData.name} — biological intelligence | Skinceptor`;
    const url = `https://skinceptor.tech/ingredient/${loaderData.slug}`;
    const chemical: Record<string, unknown> = {
      "@context": "https://schema.org",
      "@type": "ChemicalSubstance",
      name: loaderData.name,
      alternateName: loaderData.aliases,
      description: loaderData.summary,
      url,
      isPartOf: { "@type": "WebSite", name: "Skinceptor", url: "https://skinceptor.tech/" },
    };
    if (loaderData.formula) chemical["molecularFormula"] = loaderData.formula;
    if (loaderData.molecularWeight) chemical["molecularWeight"] = `${loaderData.molecularWeight} g/mol`;
    if (loaderData.smiles) chemical["smiles"] = loaderData.smiles;
    if (loaderData.pubchemCid) {
      chemical["sameAs"] = `https://pubchem.ncbi.nlm.nih.gov/compound/${loaderData.pubchemCid}`;
    }
    return {
      meta: [
        { title },
        { name: "description", content: loaderData.summary.slice(0, 155) },
        { property: "og:title", content: title },
        { property: "og:description", content: loaderData.summary.slice(0, 155) },
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: [{ type: "application/ld+json", children: JSON.stringify(chemical) }],
    };
  },
  notFoundComponent: IngredientNotFound,
  errorComponent: ({ error }) => (
    <PageShell>
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <h1 className="font-display text-3xl text-card-foreground">This page didn't load</h1>
        <p className="mt-2 text-sm text-foreground/60">{error.message}</p>
      </div>
    </PageShell>
  ),
  component: IngredientPage,
});

/** Shows a "back to your list" link only if the user just came from the ingredient checker. */
function BackToCheckerLink() {
  const [hasList, setHasList] = useState(false);
  useEffect(() => {
    setHasList(Boolean(window.sessionStorage.getItem("skinceptor:ingredient-checker:list")));
  }, []);
  if (!hasList) return null;
  return (
    <Link
      to="/ingredient-checker"
      className="mb-1 inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-foreground/55 transition-colors hover:text-card-foreground"
    >
      ← Back to your ingredient list
    </Link>
  );
}

function IngredientNotFound() {
  return (
    <PageShell>
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <h1 className="font-display text-3xl text-card-foreground">No biological data found.</h1>
        <p className="mt-2 text-sm text-foreground/60">
          Try an ingredient, gene, pathway, or beauty topic from the explore page.
        </p>
        <Link
          to="/explore"
          className="mt-6 inline-block rounded-full border border-border bg-foreground/10 px-5 py-2 text-sm"
        >
          Explore biology
        </Link>
      </div>
    </PageShell>
  );
}

function IngredientPage() {
  const { slug } = Route.useParams();
  const ing = ingredientBySlug.get(slug)!;
  const studies = studiesForIngredient(slug);
  const graph = buildIngredientGraph(ing);

  return (
    <PageShell>
      <PlainEnglishProvider>
      <article className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <BackToCheckerLink />
        <Eyebrow>Ingredient intelligence</Eyebrow>
        <div className="mt-3 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-4xl font-light tracking-tight text-card-foreground md:text-6xl">
              {ing.name}
            </h1>
            <p className="mt-2 font-mono text-xs uppercase tracking-[0.15em] text-foreground/50">
              {ing.className} · {ing.inci ?? "INCI unavailable"} · {ing.formula ?? "formula unavailable"}
            </p>
          </div>
          <div className="flex gap-2">
            <Link
              to="/compare"
              search={{ a: ing.slug, b: "" }}
              className="rounded-full border border-border bg-foreground/10 px-4 py-2 text-sm"
            >
              Compare
            </Link>
            <button
              type="button"
              onClick={() => exportEvidenceReport([{ ingredient: ing, studies }], `${ing.name} — evidence report`)}
              className="rounded-full border border-border bg-foreground/10 px-4 py-2 text-sm"
            >
              Export PDF report
            </button>
            <a href="#network" className="rounded-full border border-accent/40 bg-accent/10 px-4 py-2 text-sm text-accent">
              Explore biology
            </a>
          </div>
        </div>
        <p className="mt-4 max-w-3xl text-[15px] leading-relaxed text-foreground/70">
          <PlainText>{ing.summary}</PlainText>
        </p>

        <div className="mt-4 flex flex-wrap items-center gap-3">
          <PlainEnglishToggle />
          <SaveToLibraryButton itemType="ingredient" slug={ing.slug} />
          <ReplicationBadge flag={replicationFlag(studies)} showDetail />
        </div>
        <p className="mt-2 max-w-2xl text-xs leading-relaxed text-foreground/45">
          Any underlined term can be tapped for an everyday-English translation.
        </p>

        <div className="mt-10 grid gap-4 lg:grid-cols-3">
          <GlassPanel className="p-5">
            <Eyebrow tone="brand">Molecular identity</Eyebrow>
            {ing.pubchemCid ? (
              <img
                src={externalLink.pubchemImage(ing.pubchemCid)}
                alt={`Two-dimensional chemical structure of ${ing.name}`}
                loading="lazy"
                width={500}
                height={500}
                className="mt-4 w-full rounded-xl border border-border bg-fog/90 p-2"
              />
            ) : (
              <p className="mt-4 rounded-xl border border-border p-6 text-center text-sm text-foreground/50">
                Structure image unavailable
              </p>
            )}
            <dl className="mt-4 space-y-2 font-mono text-[11px]">
              {[
                ["Formula", ing.formula],
                ["Molecular weight", ing.molecularWeight ? `${ing.molecularWeight} g/mol` : undefined],
                ["PubChem CID", ing.pubchemCid],
                ["ChEBI", ing.chebi],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between gap-3 border-b border-border/60 pb-1.5">
                  <dt className="text-foreground/45">{label}</dt>
                  <dd className="text-right text-card-foreground">{value ?? "Data unavailable"}</dd>
                </div>
              ))}
            </dl>
            {ing.pubchemCid && (
              <a
                href={externalLink.pubchem(ing.pubchemCid)}
                target="_blank"
                rel="noreferrer noopener"
                className="mt-3 inline-block text-xs text-accent underline underline-offset-4"
              >
                Open PubChem record →
              </a>
            )}
          </GlassPanel>

          <GlassPanel className="p-5">
            <Eyebrow tone="rose">Biological targets</Eyebrow>
            <ul className="mt-4 space-y-3">
              {ing.targets.map((t) => (
                <li key={t.name} className="border-b border-border/60 pb-3 last:border-0">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-sm text-card-foreground">{t.name}</p>
                    <ConfidenceBadge level={t.confidence} />
                  </div>
                  <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-foreground/40">
                    {t.relation} · {t.kind}
                  </p>
                  {t.note && (
                    <p className="mt-1 text-xs leading-relaxed text-foreground/55">
                      <PlainText>{t.note}</PlainText>
                    </p>
                  )}
                  {t.uniprot && (
                    <a
                      href={externalLink.uniprot(t.uniprot)}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="mt-1 inline-block font-mono text-[10px] text-accent underline underline-offset-4"
                    >
                      UniProt {t.uniprot}
                    </a>
                  )}
                </li>
              ))}
            </ul>
          </GlassPanel>

          <GlassPanel className="p-5">
            <Eyebrow tone="violet">Molecules & genes</Eyebrow>
            <p className="mt-4 font-mono text-[10px] uppercase tracking-wider text-foreground/40">Molecules</p>
            <ul className="mt-2 space-y-2 text-sm text-foreground/70">
              {ing.molecules.map((m) => (
                <li key={m.name}>
                  {m.name}
                  <span className="block font-mono text-[10px] text-foreground/40">
                    {m.formula ?? "formula unavailable"}
                    {m.molecularWeight ? ` · ${m.molecularWeight} g/mol` : ""}
                  </span>
                </li>
              ))}
            </ul>
            <p className="mt-4 font-mono text-[10px] uppercase tracking-wider text-foreground/40">Genes / proteins</p>
            <ul className="mt-2 flex flex-wrap gap-1.5">
              {ing.genes.map((g) => (
                <li key={g.symbol}>
                  <a
                    href={g.uniprot ? externalLink.uniprot(g.uniprot) : externalLink.ncbiGene(g.ncbiGene ?? "")}
                    target="_blank"
                    rel="noreferrer noopener"
                    title={g.name}
                    className="rounded-md border border-accent/30 bg-accent/10 px-2 py-0.5 font-mono text-[10px] text-accent"
                  >
                    {g.symbol}
                  </a>
                </li>
              ))}
            </ul>
          </GlassPanel>
        </div>

        <section id="network" className="mt-12 scroll-mt-24">
          <Eyebrow>How could this ingredient interact with biology?</Eyebrow>
          <h2 className="mt-2 font-display text-2xl text-card-foreground">Biological network</h2>
          <p className="mt-2 max-w-3xl text-sm text-foreground/60">
            Ingredient → molecule → target → gene/protein → pathway → process → studied outcome. Relationship strength is
            drawn from the curated confidence tier; nothing is added to make the chain look complete.
          </p>
          <div className="mt-4">
            <BiologyNetwork graph={graph} caption={`${ing.name} biological network`} />
          </div>
        </section>

        <section className="mt-12">
          <Eyebrow tone="amber">Biological pathways</Eyebrow>
          <div className="mt-4 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {ing.pathways.map((p) => (
              <GlassPanel key={p.name} className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-sm text-card-foreground">{p.name}</h3>
                  <ConfidenceBadge level={p.confidence} />
                </div>
                <p className="mt-2 text-xs leading-relaxed text-foreground/60">
                  <PlainText>{p.summary}</PlainText>
                </p>
                <p className="mt-2 font-mono text-[10px] text-foreground/40">
                  {p.db}
                  {p.id ? ` ${p.id}` : ""}
                </p>
              </GlassPanel>
            ))}
          </div>
        </section>

        <section className="mt-12 grid gap-4 lg:grid-cols-2">
          <EvidenceDashboard studies={studies} />
          <ResearchTimeline studies={studies} />
        </section>

        <section className="mt-12">
          <Eyebrow tone="rose">Ingredient fingerprint</Eyebrow>
          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <ArtCanvas graph={graph} seed={ing.slug} style="fingerprint" size={620} />
            <div>
              <p className="text-sm leading-relaxed text-foreground/65">
                The fingerprint is a deterministic visual signature: ridge amplitude comes from the number of entities in
                each tier, node placement from identifier hashes, and opacity from confidence. Two ingredients can never
                produce the same figure unless their networks are identical.
              </p>
              <Link
                to="/art"
                search={{ ingredient: ing.slug, style: "constellation" as const, labels: false }}
                className="mt-4 inline-block rounded-full border border-border bg-foreground/10 px-4 py-2 text-sm"
              >
                Open in Biology as Art →
              </Link>
            </div>
          </div>
        </section>

        <section className="mt-12">
          <Eyebrow tone="muted">Research</Eyebrow>
          <h2 className="mt-2 font-display text-2xl text-card-foreground">
            {studies.length} curated {studies.length === 1 ? "study" : "studies"}
          </h2>
          {studies.length === 0 ? (
            <p className="mt-3 text-sm text-foreground/55">
              No curated studies for this ingredient yet. Insufficient evidence to characterise it here.
            </p>
          ) : (
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {studies.map((s) => (
                <StudyCard key={s.id} study={s} />
              ))}
            </div>
          )}
        </section>

        <section className="mt-12">
          <CommunityEvidence ingredientSlug={ing.slug} />
        </section>

        <section className="mt-12 grid gap-4 lg:grid-cols-2">
          <GlassPanel className="p-5">
            <Eyebrow tone="muted">Sources</Eyebrow>
            <SourceList sources={ing.sources} />
          </GlassPanel>
          <GlassPanel className="p-5">
            <Eyebrow tone="muted">Related biology maps</Eyebrow>
            <ul className="mt-3 space-y-2">
              {ing.topics.map((slug) => {
                const t = topicBySlug.get(slug);
                if (!t) return null;
                return (
                  <li key={slug}>
                    <Link
                      to="/topic/$slug"
                      params={{ slug }}
                      className="text-sm text-foreground/75 underline underline-offset-4 hover:text-card-foreground"
                    >
                      {t.name}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </GlassPanel>
        </section>
      </article>
      </PlainEnglishProvider>
    </PageShell>
  );
}
