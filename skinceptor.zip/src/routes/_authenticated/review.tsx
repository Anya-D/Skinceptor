import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { ingredientBySlug } from "@/data/ingredients";
import { topicBySlug } from "@/data/topics";
import { listMyRoles, listSubmissionsForReview, reviewSubmission, reviewCounts } from "@/lib/review.functions";

export const Route = createFileRoute("/_authenticated/review")({
  staticData: { sitemap: false },
  head: () => ({
    meta: [
      { title: "Evidence review queue | Skinceptor" },
      {
        name: "description",
        content:
          "Reviewer workspace for reader-submitted studies: check citations, study design and limitations, then approve or decline with a note.",
      },
      { property: "og:title", content: "Evidence review queue — Skinceptor" },
      { property: "og:description", content: "Approve or decline reader-submitted studies with a review note." },
    ],
  }),
  component: ReviewPage,
});

const STATUS_TABS = [
  { key: "pending", label: "Awaiting review" },
  { key: "approved", label: "Approved" },
  { key: "rejected", label: "Declined" },
] as const;

const STATUS_TONE: Record<string, string> = {
  pending: "border-amber/40 bg-amber/10 text-amber",
  approved: "border-accent/40 bg-accent/10 text-accent",
  rejected: "border-rose/40 bg-rose/10 text-rose",
};

function ReviewPage() {
  const qc = useQueryClient();
  const fetchRoles = useServerFn(listMyRoles);
  const fetchQueue = useServerFn(listSubmissionsForReview);
  const fetchCounts = useServerFn(reviewCounts);
  const decide = useServerFn(reviewSubmission);

  const [status, setStatus] = useState<string>("pending");
  const [notes, setNotes] = useState<Record<string, string>>({});

  const roles = useQuery({ queryKey: ["my-roles"], queryFn: () => fetchRoles() });
  const isReviewer = (roles.data ?? []).some((r) => r === "reviewer" || r === "admin");

  const counts = useQuery({
    queryKey: ["review-counts"],
    queryFn: () => fetchCounts(),
    enabled: isReviewer,
  });
  const queue = useQuery({
    queryKey: ["review-queue", status],
    queryFn: () => fetchQueue({ data: { status } }),
    enabled: isReviewer,
  });

  const decision = useMutation({
    mutationFn: (v: { id: string; status: string; reviewNote?: string }) => decide({ data: v }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["review-queue"] });
      void qc.invalidateQueries({ queryKey: ["review-counts"] });
      void qc.invalidateQueries({ queryKey: ["community-evidence"] });
    },
  });

  if (roles.isLoading) {
    return (
      <PageShell>
        <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
          <p className="text-sm text-foreground/55">Checking your access…</p>
        </section>
      </PageShell>
    );
  }

  if (!isReviewer) {
    return (
      <PageShell>
        <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
          <Eyebrow tone="brand">Restricted</Eyebrow>
          <h1 className="mt-3 font-display text-4xl font-light text-card-foreground">Reviewer access required</h1>
          <p className="mt-3 text-sm leading-relaxed text-foreground/60">
            This workspace is limited to accounts with a reviewer role. Reader submissions stay private until a reviewer
            checks the citation, study design and stated limitations.
          </p>
          <Link to="/library" className="mt-6 inline-block text-sm text-accent hover:underline">
            Back to my library
          </Link>
        </section>
      </PageShell>
    );
  }

  const rows = queue.data ?? [];

  return (
    <PageShell>
      <section className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
        <Eyebrow tone="brand">Reviewer workspace</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">Evidence review queue</h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-foreground/60">
          Check that each submission names a real, findable study, that the described design matches the claim, and that
          limitations are stated honestly. Approved entries appear publicly as reader-submitted evidence, clearly
          separated from the curated dataset. Approval is not an endorsement of any product or outcome.
        </p>

        <div className="mt-8 flex flex-wrap gap-2" role="tablist" aria-label="Submission status">
          {STATUS_TABS.map((tab) => {
            const active = status === tab.key;
            const count = counts.data?.[tab.key];
            return (
              <button
                key={tab.key}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setStatus(tab.key)}
                className={`rounded-full border px-4 py-1.5 font-mono text-[11px] uppercase tracking-wider transition ${
                  active
                    ? "border-accent/50 bg-accent/10 text-accent"
                    : "border-border bg-ink-2/40 text-foreground/55 hover:text-foreground/80"
                }`}
              >
                {tab.label}
                {typeof count === "number" ? ` · ${count}` : ""}
              </button>
            );
          })}
        </div>

        {decision.isError ? (
          <p className="mt-4 text-sm text-rose">{(decision.error as Error).message}</p>
        ) : null}

        <div className="mt-8 space-y-4">
          {queue.isLoading ? (
            <p className="text-sm text-foreground/55">Loading submissions…</p>
          ) : rows.length === 0 ? (
            <GlassPanel className="p-6">
              <p className="text-sm text-foreground/55">
                Nothing in this list right now.{" "}
                {status === "pending" ? "The queue is clear." : "Try another status."}
              </p>
            </GlassPanel>
          ) : (
            rows.map((row) => {
              const subject =
                (row.ingredient_slug ? ingredientBySlug.get(row.ingredient_slug)?.name : null) ??
                (row.topic_slug ? topicBySlug.get(row.topic_slug)?.name : null) ??
                row.ingredient_slug ??
                row.topic_slug ??
                "Unlinked";
              const busy = decision.isPending && decision.variables?.id === row.id;
              return (
                <GlassPanel key={row.id} className="p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">
                        {subject} · {row.study_type}
                        {row.year ? ` · ${row.year}` : ""}
                        {row.sample_size ? ` · n=${row.sample_size}` : ""}
                      </p>
                      <h2 className="mt-1 text-base leading-snug text-card-foreground">{row.title}</h2>
                      {row.journal ? <p className="mt-1 text-xs text-foreground/50">{row.journal}</p> : null}
                    </div>
                    <span
                      className={`rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-wider ${
                        STATUS_TONE[row.status] ?? "border-border text-foreground/50"
                      }`}
                    >
                      {row.status}
                    </span>
                  </div>

                  <p className="mt-4 text-sm leading-relaxed text-foreground/75">{row.summary}</p>
                  {row.limitations ? (
                    <p className="mt-3 text-xs leading-relaxed text-foreground/55">
                      <span className="font-mono uppercase tracking-wider text-foreground/40">Limitations · </span>
                      {row.limitations}
                    </p>
                  ) : (
                    <p className="mt-3 text-xs text-amber/80">No limitations stated by the submitter.</p>
                  )}

                  <div className="mt-4 flex flex-wrap gap-3 text-xs">
                    {row.pmid ? (
                      <a
                        href={`https://pubmed.ncbi.nlm.nih.gov/${encodeURIComponent(row.pmid)}/`}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="text-accent hover:underline"
                      >
                        PMID {row.pmid}
                      </a>
                    ) : null}
                    {row.doi ? (
                      <a
                        href={`https://doi.org/${row.doi}`}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="text-accent hover:underline"
                      >
                        DOI {row.doi}
                      </a>
                    ) : null}
                    {row.url ? (
                      <a href={row.url} target="_blank" rel="noreferrer noopener" className="text-accent hover:underline">
                        Submitted link
                      </a>
                    ) : null}
                    {!row.pmid && !row.doi && !row.url ? (
                      <span className="text-amber/80">No identifier provided — verify before approving.</span>
                    ) : null}
                  </div>

                  {row.submitter_label ? (
                    <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-foreground/40">
                      Credited as {row.submitter_label}
                    </p>
                  ) : null}

                  {row.review_note ? (
                    <p className="mt-3 rounded-lg border border-border bg-ink-2/40 p-3 text-xs text-foreground/60">
                      <span className="font-mono uppercase tracking-wider text-foreground/40">Review note · </span>
                      {row.review_note}
                    </p>
                  ) : null}

                  <div className="mt-5 border-t border-border pt-4">
                    <label
                      htmlFor={`note-${row.id}`}
                      className="font-mono text-[10px] uppercase tracking-wider text-foreground/45"
                    >
                      Review note (visible to the submitter)
                    </label>
                    <textarea
                      id={`note-${row.id}`}
                      rows={2}
                      value={notes[row.id] ?? row.review_note ?? ""}
                      onChange={(e) => setNotes((prev) => ({ ...prev, [row.id]: e.target.value }))}
                      placeholder="Why this was approved or declined…"
                      className="mt-2 w-full rounded-lg border border-border bg-ink-2/40 px-3 py-2 text-sm text-card-foreground outline-none placeholder:text-foreground/35 focus-visible:border-accent/60"
                    />
                    <div className="mt-3 flex flex-wrap gap-2">
                      {row.status !== "approved" ? (
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() =>
                            decision.mutate({ id: row.id, status: "approved", reviewNote: notes[row.id] ?? "" })
                          }
                          className="rounded-full border border-accent/50 bg-accent/10 px-4 py-1.5 font-mono text-[11px] uppercase tracking-wider text-accent transition hover:bg-accent/20 disabled:opacity-50"
                        >
                          {busy ? "Saving…" : "Approve"}
                        </button>
                      ) : null}
                      {row.status !== "rejected" ? (
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() =>
                            decision.mutate({ id: row.id, status: "rejected", reviewNote: notes[row.id] ?? "" })
                          }
                          className="rounded-full border border-rose/50 bg-rose/10 px-4 py-1.5 font-mono text-[11px] uppercase tracking-wider text-rose transition hover:bg-rose/20 disabled:opacity-50"
                        >
                          Decline
                        </button>
                      ) : null}
                      {row.status !== "pending" ? (
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() =>
                            decision.mutate({ id: row.id, status: "pending", reviewNote: notes[row.id] ?? "" })
                          }
                          className="rounded-full border border-border bg-ink-2/40 px-4 py-1.5 font-mono text-[11px] uppercase tracking-wider text-foreground/60 transition hover:text-foreground/85 disabled:opacity-50"
                        >
                          Return to queue
                        </button>
                      ) : null}
                    </div>
                  </div>
                </GlassPanel>
              );
            })
          )}
        </div>
      </section>
    </PageShell>
  );
}
