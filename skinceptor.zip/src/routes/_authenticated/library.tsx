import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { ingredientBySlug } from "@/data/ingredients";
import { topicBySlug } from "@/data/topics";
import {
  listLibrary,
  listSavedSearches,
  deleteSavedSearch,
  updateLibraryNote,
  toggleLibraryItem,
  listMySubmissions,
  deleteSubmission,
} from "@/lib/account.functions";
import { listClaimAnalyses, deleteClaimAnalysis } from "@/lib/claim-ai.functions";
import type { ClaimAnalysis } from "@/lib/claim-ai.functions";

export const Route = createFileRoute("/_authenticated/library")({
  staticData: { sitemap: false },
  head: () => ({
    meta: [
      { title: "My library — saved ingredients, searches and analyses | Skinceptor" },
      {
        name: "description",
        content:
          "Your saved Skinceptor research: ingredient and biology-map library with notes, saved searches, submitted evidence and AI claim analyses.",
      },
      { property: "og:title", content: "My library — Skinceptor" },
      { property: "og:description", content: "Saved ingredients, searches, submissions and AI claim analyses." },
    ],
  }),
  component: LibraryPage,
});

const STATUS_TONE: Record<string, string> = {
  pending: "border-amber/40 bg-amber/10 text-amber",
  approved: "border-accent/40 bg-accent/10 text-accent",
  rejected: "border-rose/40 bg-rose/10 text-rose",
};

function LibraryPage() {
  const qc = useQueryClient();
  const fetchLibrary = useServerFn(listLibrary);
  const fetchSearches = useServerFn(listSavedSearches);
  const fetchSubmissions = useServerFn(listMySubmissions);
  const fetchAnalyses = useServerFn(listClaimAnalyses);
  const removeSearch = useServerFn(deleteSavedSearch);
  const removeItem = useServerFn(toggleLibraryItem);
  const saveNote = useServerFn(updateLibraryNote);
  const removeSubmission = useServerFn(deleteSubmission);
  const removeAnalysis = useServerFn(deleteClaimAnalysis);

  const library = useQuery({ queryKey: ["library"], queryFn: () => fetchLibrary() });
  const searches = useQuery({ queryKey: ["saved-searches"], queryFn: () => fetchSearches() });
  const submissions = useQuery({ queryKey: ["my-submissions"], queryFn: () => fetchSubmissions() });
  const analyses = useQuery({ queryKey: ["claim-analyses"], queryFn: () => fetchAnalyses() });

  const invalidate = (key: string) => () => void qc.invalidateQueries({ queryKey: [key] });

  const delSearch = useMutation({
    mutationFn: (id: string) => removeSearch({ data: { id } }),
    onSuccess: invalidate("saved-searches"),
  });
  const delItem = useMutation({
    mutationFn: (v: { itemType: "ingredient" | "topic"; slug: string }) => removeItem({ data: v }),
    onSuccess: invalidate("library"),
  });
  const noteMutation = useMutation({
    mutationFn: (v: { id: string; note: string }) => saveNote({ data: v }),
    onSuccess: invalidate("library"),
  });
  const delSubmission = useMutation({
    mutationFn: (id: string) => removeSubmission({ data: { id } }),
    onSuccess: invalidate("my-submissions"),
  });
  const delAnalysis = useMutation({
    mutationFn: (id: string) => removeAnalysis({ data: { id } }),
    onSuccess: invalidate("claim-analyses"),
  });

  return (
    <PageShell>
      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <Eyebrow tone="brand">Your space</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">My library</h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-foreground/60">
          Everything you saved: ingredients and biology maps with private notes, saved searches, evidence you submitted
          for review, and AI claim analyses. Educational only — never medical advice.
        </p>

        <div className="mt-10 grid gap-5 lg:grid-cols-2">
          {/* Library items */}
          <GlassPanel className="p-5">
            <Eyebrow tone="accent">Saved ingredients &amp; biology maps</Eyebrow>
            {library.isLoading ? (
              <p className="mt-4 text-sm text-foreground/55">Loading…</p>
            ) : (library.data ?? []).length === 0 ? (
              <p className="mt-4 text-sm text-foreground/55">
                Nothing saved yet.{" "}
                <Link to="/explore" className="text-accent hover:underline">
                  Explore ingredients
                </Link>{" "}
                and hit “Save to library”.
              </p>
            ) : (
              <ul className="mt-4 space-y-3">
                {(library.data ?? []).map((item) => {
                  const name =
                    item.item_type === "ingredient"
                      ? ingredientBySlug.get(item.slug)?.name ?? item.slug
                      : topicBySlug.get(item.slug)?.name ?? item.slug;
                  return (
                    <li key={item.id} className="rounded-xl border border-border bg-ink-2/40 p-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        {item.item_type === "ingredient" ? (
                          <Link
                            to="/ingredient/$slug"
                            params={{ slug: item.slug }}
                            className="text-sm text-card-foreground hover:text-accent"
                          >
                            {name}
                          </Link>
                        ) : (
                          <Link
                            to="/topic/$slug"
                            params={{ slug: item.slug }}
                            className="text-sm text-card-foreground hover:text-accent"
                          >
                            {name}
                          </Link>
                        )}
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[10px] uppercase tracking-wider text-foreground/40">
                            {item.item_type === "ingredient" ? "Ingredient" : "Biology map"}
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              delItem.mutate({
                                itemType: item.item_type as "ingredient" | "topic",
                                slug: item.slug,
                              })
                            }
                            className="text-xs text-foreground/45 hover:text-rose"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                      <NoteEditor
                        initial={item.note ?? ""}
                        onSave={(note) => noteMutation.mutate({ id: item.id, note })}
                        saving={noteMutation.isPending}
                      />
                    </li>
                  );
                })}
              </ul>
            )}
          </GlassPanel>

          {/* Saved searches */}
          <GlassPanel className="p-5">
            <Eyebrow tone="violet">Saved searches &amp; claims</Eyebrow>
            {searches.isLoading ? (
              <p className="mt-4 text-sm text-foreground/55">Loading…</p>
            ) : (searches.data ?? []).length === 0 ? (
              <p className="mt-4 text-sm text-foreground/55">
                No saved searches yet — save one from the{" "}
                <Link to="/research" className="text-accent hover:underline">
                  research explorer
                </Link>
                .
              </p>
            ) : (
              <ul className="mt-4 space-y-2">
                {(searches.data ?? []).map((s) => (
                  <li
                    key={s.id}
                    className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border bg-ink-2/40 px-4 py-3"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm text-card-foreground">{s.label || s.query}</p>
                      {s.label && <p className="truncate text-xs text-foreground/50">{s.query}</p>}
                    </div>
                    <div className="flex items-center gap-3">
                      {s.kind === "claim" ? (
                        <Link
                          to="/claim-checker"
                          className="font-mono text-[10px] uppercase tracking-wider text-accent"
                        >
                          Claim
                        </Link>
                      ) : (
                        <Link to="/research" className="font-mono text-[10px] uppercase tracking-wider text-brand">
                          Search
                        </Link>
                      )}
                      <button
                        type="button"
                        onClick={() => delSearch.mutate(s.id)}
                        className="text-xs text-foreground/45 hover:text-rose"
                      >
                        Remove
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </GlassPanel>

          {/* Submissions */}
          <GlassPanel className="p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <Eyebrow tone="amber">Evidence you submitted</Eyebrow>
              <Link
                to="/submit-evidence"
                search={{ ingredient: "", topic: "" }}
                className="rounded-full border border-border px-3 py-1.5 text-xs text-foreground/70 hover:text-card-foreground"
              >
                Submit a study
              </Link>
            </div>
            {submissions.isLoading ? (
              <p className="mt-4 text-sm text-foreground/55">Loading…</p>
            ) : (submissions.data ?? []).length === 0 ? (
              <p className="mt-4 text-sm text-foreground/55">
                You haven’t submitted any studies. Submissions are reviewed before they appear publicly.
              </p>
            ) : (
              <ul className="mt-4 space-y-3">
                {(submissions.data ?? []).map((s) => (
                  <li key={s.id} className="rounded-xl border border-border bg-ink-2/40 p-4">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <p className="text-sm text-card-foreground">{s.title}</p>
                      <span
                        className={`rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ${
                          STATUS_TONE[s.status] ?? "border-border text-foreground/50"
                        }`}
                      >
                        {s.status}
                      </span>
                    </div>
                    <p className="mt-1 font-mono text-[11px] uppercase tracking-wider text-foreground/45">
                      {[
                        s.ingredient_slug ? ingredientBySlug.get(s.ingredient_slug)?.name ?? s.ingredient_slug : null,
                        s.topic_slug ? topicBySlug.get(s.topic_slug)?.name ?? s.topic_slug : null,
                        s.study_type,
                        s.year,
                      ]
                        .filter(Boolean)
                        .join(" · ")}
                    </p>
                    <p className="mt-2 text-sm leading-relaxed text-foreground/70">{s.summary}</p>
                    {s.review_note && <p className="mt-2 text-xs text-amber/80">Reviewer note: {s.review_note}</p>}
                    <button
                      type="button"
                      onClick={() => delSubmission.mutate(s.id)}
                      className="mt-3 text-xs text-foreground/45 hover:text-rose"
                    >
                      Withdraw submission
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </GlassPanel>

          {/* AI analyses */}
          <GlassPanel className="p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <Eyebrow tone="rose">AI claim analyses</Eyebrow>
              <Link
                to="/claim-checker"
                className="rounded-full border border-border px-3 py-1.5 text-xs text-foreground/70 hover:text-card-foreground"
              >
                Analyse a claim
              </Link>
            </div>
            {analyses.isLoading ? (
              <p className="mt-4 text-sm text-foreground/55">Loading…</p>
            ) : (analyses.data ?? []).length === 0 ? (
              <p className="mt-4 text-sm text-foreground/55">
                No analyses yet. Run one from the claim checker and it is stored here.
              </p>
            ) : (
              <ul className="mt-4 space-y-3">
                {(analyses.data ?? []).map((a) => {
                  const detail = a.analysis as ClaimAnalysis | null;
                  return (
                    <li key={a.id} className="rounded-xl border border-border bg-ink-2/40 p-4">
                      <p className="text-sm text-card-foreground">“{a.claim}”</p>
                      {a.verdict && (
                        <p className="mt-1 font-mono text-[10px] uppercase tracking-wider text-accent">{a.verdict}</p>
                      )}
                      {a.plausibility && (
                        <p className="mt-2 text-sm leading-relaxed text-foreground/70">{a.plausibility}</p>
                      )}
                      {detail?.evidence_gaps?.length ? (
                        <p className="mt-2 text-xs leading-relaxed text-amber/80">
                          Gaps: {detail.evidence_gaps.join("; ")}
                        </p>
                      ) : null}
                      <button
                        type="button"
                        onClick={() => delAnalysis.mutate(a.id)}
                        className="mt-3 text-xs text-foreground/45 hover:text-rose"
                      >
                        Delete
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </GlassPanel>
        </div>
      </section>
    </PageShell>
  );
}

function NoteEditor({
  initial,
  onSave,
  saving,
}: {
  initial: string;
  onSave: (note: string) => void;
  saving: boolean;
}) {
  const [note, setNote] = useState(initial);
  const dirty = note !== initial;
  return (
    <div className="mt-3">
      <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/40">Private note</label>
      <textarea
        value={note}
        onChange={(e) => setNote(e.target.value)}
        rows={2}
        placeholder="Why you saved this, what to read next…"
        className="mt-1.5 w-full rounded-xl border border-border bg-ink-2/60 px-3 py-2 text-sm text-card-foreground placeholder:text-foreground/35"
      />
      {dirty && (
        <button
          type="button"
          onClick={() => onSave(note)}
          disabled={saving}
          className="mt-2 rounded-full border border-accent/40 bg-accent/15 px-3 py-1 text-xs text-accent disabled:opacity-50"
        >
          {saving ? "Saving…" : "Save note"}
        </button>
      )}
    </div>
  );
}
