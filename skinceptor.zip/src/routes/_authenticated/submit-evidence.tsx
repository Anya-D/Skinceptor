import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { ingredients } from "@/data/ingredients";
import { topics } from "@/data/topics";
import { submitEvidence } from "@/lib/account.functions";

export const Route = createFileRoute("/_authenticated/submit-evidence")({
  staticData: { sitemap: false },
  validateSearch: (search: Record<string, unknown>) => ({
    ingredient: typeof search["ingredient"] === "string" ? (search["ingredient"] as string) : "",
    topic: typeof search["topic"] === "string" ? (search["topic"] as string) : "",
  }),
  head: () => ({
    meta: [
      { title: "Submit evidence — contribute a study | Skinceptor" },
      {
        name: "description",
        content:
          "Submit a peer-reviewed study for review: link it to an ingredient or biology map, state the design, sample size, finding and limitations.",
      },
      { property: "og:title", content: "Submit evidence — Skinceptor" },
      { property: "og:description", content: "Contribute a study with its design, finding and stated limitations." },
    ],
  }),
  component: SubmitEvidencePage,
});

const STUDY_TYPES = [
  { value: "human", label: "Human" },
  { value: "rct", label: "Randomised controlled trial" },
  { value: "meta-analysis", label: "Meta-analysis" },
  { value: "review", label: "Review" },
  { value: "animal", label: "Animal" },
  { value: "in-vitro", label: "In-vitro" },
  { value: "other", label: "Other" },
];

function SubmitEvidencePage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const submit = useServerFn(submitEvidence);

  const [form, setForm] = useState({
    ingredientSlug: search.ingredient,
    topicSlug: search.topic,
    title: "",
    journal: "",
    year: "",
    studyType: "human",
    sampleSize: "",
    pmid: "",
    doi: "",
    url: "",
    summary: "",
    limitations: "",
    submitterLabel: "",
  });
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const mutation = useMutation({
    mutationFn: () => submit({ data: form }),
    onSuccess: () => {
      setDone(true);
      setError(null);
    },
    onError: (err) => setError(err instanceof Error ? err.message : "Submission failed."),
  });

  const field =
    "mt-1.5 w-full rounded-xl border border-border bg-ink-2/60 px-3 py-2 text-sm text-card-foreground placeholder:text-foreground/35";
  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  if (done) {
    return (
      <PageShell>
        <section className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
          <Eyebrow tone="accent">Received</Eyebrow>
          <h1 className="mt-3 font-display text-4xl font-light text-card-foreground">Thanks — it’s in review</h1>
          <p className="mt-3 text-sm leading-relaxed text-foreground/60">
            Your submission is stored as pending. It appears publicly only after review, and it never changes the
            curated Evidence Index on its own.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              to="/library"
              className="rounded-full border border-accent/40 bg-accent/15 px-4 py-2 text-sm text-accent"
            >
              View my submissions
            </Link>
            <button
              type="button"
              onClick={() => {
                setDone(false);
                setForm((f) => ({ ...f, title: "", summary: "", limitations: "", pmid: "", doi: "", url: "" }));
              }}
              className="rounded-full border border-border px-4 py-2 text-sm text-foreground/70"
            >
              Submit another
            </button>
          </div>
        </section>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <section className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <Eyebrow tone="amber">Contribute</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">Submit evidence</h1>
        <p className="mt-3 text-sm leading-relaxed text-foreground/60">
          Add a peer-reviewed study we’re missing. Please describe what was actually measured and state the limitations —
          submissions with promotional or medical claims are rejected.
        </p>

        <GlassPanel className="mt-8 p-5">
          <form
            className="space-y-5"
            onSubmit={(e) => {
              e.preventDefault();
              mutation.mutate();
            }}
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Ingredient</label>
                <select value={form.ingredientSlug} onChange={set("ingredientSlug")} className={field}>
                  <option value="">— none —</option>
                  {ingredients.map((i) => (
                    <option key={i.slug} value={i.slug}>
                      {i.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Biology map</label>
                <select value={form.topicSlug} onChange={set("topicSlug")} className={field}>
                  <option value="">— none —</option>
                  {topics.map((t) => (
                    <option key={t.slug} value={t.slug}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="title" className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">
                Study title or full citation *
              </label>
              <input id="title" required value={form.title} onChange={set("title")} className={field} />
            </div>

            <div className="grid gap-4 sm:grid-cols-4">
              <div className="sm:col-span-2">
                <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Journal</label>
                <input value={form.journal} onChange={set("journal")} className={field} />
              </div>
              <div>
                <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Year</label>
                <input value={form.year} onChange={set("year")} inputMode="numeric" className={field} />
              </div>
              <div>
                <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Sample size</label>
                <input value={form.sampleSize} onChange={set("sampleSize")} inputMode="numeric" className={field} />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-4">
              <div>
                <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Study design</label>
                <select value={form.studyType} onChange={set("studyType")} className={field}>
                  {STUDY_TYPES.map((t) => (
                    <option key={t.value} value={t.value}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">PMID</label>
                <input value={form.pmid} onChange={set("pmid")} className={field} />
              </div>
              <div>
                <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">DOI</label>
                <input value={form.doi} onChange={set("doi")} className={field} />
              </div>
              <div>
                <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Link</label>
                <input value={form.url} onChange={set("url")} placeholder="https://" className={field} />
              </div>
            </div>

            <div>
              <label htmlFor="summary" className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">
                What was measured and reported? *
              </label>
              <textarea id="summary" required rows={3} value={form.summary} onChange={set("summary")} className={field} />
            </div>

            <div>
              <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Limitations</label>
              <textarea rows={2} value={form.limitations} onChange={set("limitations")} className={field} />
            </div>

            <div>
              <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">
                Display name (optional)
              </label>
              <input value={form.submitterLabel} onChange={set("submitterLabel")} className={field} />
            </div>

            {error && (
              <p role="alert" className="rounded-xl border border-rose/40 bg-rose/10 px-3 py-2 text-xs text-rose">
                {error}
              </p>
            )}

            <div className="flex flex-wrap gap-3">
              <button
                type="submit"
                disabled={mutation.isPending}
                className="rounded-full border border-accent/40 bg-accent/15 px-4 py-2 text-sm text-accent disabled:opacity-50"
              >
                {mutation.isPending ? "Submitting…" : "Submit for review"}
              </button>
              <button
                type="button"
                onClick={() => void navigate({ to: "/library" })}
                className="rounded-full border border-border px-4 py-2 text-sm text-foreground/70"
              >
                Cancel
              </button>
            </div>
          </form>
        </GlassPanel>
      </section>
    </PageShell>
  );
}
