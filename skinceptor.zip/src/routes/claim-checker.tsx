import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useAuth } from "@/hooks/useAuth";
import { analyzeClaim } from "@/lib/claim-ai.functions";
import { SaveSearchButton } from "@/components/AccountActions";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { StudyCard, StudyTypeTag } from "@/components/Research";
import { OverstatedBadge, ReplicationBadge } from "@/components/EvidenceFlags";
import { ingredients } from "@/data/ingredients";
import { topics } from "@/data/topics";
import { studies, studyById } from "@/data/studies";
import { assessOverstatement, computeEvidence, replicationFlag } from "@/lib/evidence";
import { externalLink } from "@/lib/links";

export const Route = createFileRoute("/claim-checker")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Claim checker — test a beauty claim against biology | Skinceptor" },
      {
        name: "description",
        content:
          "Paste a beauty marketing claim and see which ingredients, pathways and curated studies relate to it, plus where the evidence is mixed or absent.",
      },
      { property: "og:title", content: "Claim checker — Skinceptor" },
      { property: "og:description", content: "Biological plausibility, mapped pathways and supporting literature." },
    ],
  }),
  component: ClaimChecker,
});

const EXAMPLES = [
  "Peptides stimulate collagen synthesis and skin firmness",
  "Niacinamide reduces hyperpigmentation",
  "Retinol reverses wrinkles permanently",
  "Hyaluronic acid rebuilds the skin barrier",
];

function tokenize(text: string) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 3);
}

function ClaimChecker() {
  const [claim, setClaim] = useState("");
  const [submitted, setSubmitted] = useState<string | null>(null);
  const { signedIn, loading: authLoading } = useAuth();
  const runAnalysis = useServerFn(analyzeClaim);
  const ai = useMutation({
    mutationFn: (input: { claim: string; context: string }) => runAnalysis({ data: input }),
  });

  const words = submitted ? tokenize(submitted) : [];
  const matchedIngredients = ingredients.filter((i) =>
    words.some(
      (w) =>
        i.name.toLowerCase().includes(w) ||
        i.className.toLowerCase().includes(w),
    ),
  );
  const matchedTopics = topics.filter((t) =>
    words.some((w) => `${t.name} ${t.overview}`.toLowerCase().includes(w)),
  );
  const slugs = new Set(matchedIngredients.map((i) => i.slug));
  const topicSlugs = new Set(matchedTopics.map((t) => t.slug));
  const related = studies.filter(
    (s) => s.ingredients.some((x) => slugs.has(x)) || s.topics.some((x) => topicSlugs.has(x)),
  );
  const evidence = computeEvidence(related);
  const flag = replicationFlag(related);
  const overstatement = submitted
    ? assessOverstatement(submitted, evidence, related)
    : { overstated: false, reasons: [], words: [] };

  const plausibility =
    related.length === 0
      ? "Not assessable with our curated dataset"
      : matchedIngredients.length && matchedTopics.length
        ? "Biologically plausible mechanism exists"
        : "Partially mapped — mechanism only indirectly supported";

  const aiContext = [
    matchedIngredients
      .map(
        (i) =>
          `INGREDIENT ${i.name} (${i.className}). ${i.summary} Targets: ${i.targets
            .map((t) => `${t.name} [${t.relation}, confidence ${t.confidence}]`)
            .join("; ")}. Pathways: ${i.pathways.map((p) => p.name).join("; ")}. Processes: ${i.processes
            .map((p) => p.name)
            .join("; ")}.`,
      )
      .join("\n"),
    matchedTopics.map((t) => `BIOLOGY MAP ${t.name}. ${t.overview}`).join("\n"),
    related
      .slice(0, 25)
      .map(
        (s) =>
          `STUDY [id=${s.id}] "${s.title}" (${s.year}, ${s.journal}), design ${s.type}${
            s.sampleSize ? `, n=${s.sampleSize}` : ""
          }. Finding: ${s.finding} Limitations: ${s.limitations}`,
      )
      .join("\n"),
    `Curated evidence index (experimental): ${evidence.index}/100, strength ${evidence.strength}, based on ${related.length} studies.`,
  ]
    .filter(Boolean)
    .join("\n\n");

  const analysis = ai.data?.analysis;
  /** Only ids that exist in the curated dataset are shown, so a hallucinated id silently drops out. */
  const citedFor = (ids: string[] | undefined) =>
    (ids ?? []).map((id) => studyById.get(id)).filter((s): s is NonNullable<typeof s> => Boolean(s));

  return (
    <PageShell>
      <section className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
        <Eyebrow tone="rose">Claim checker</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">Check a beauty claim</h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-foreground/60">
          This tool maps a claim onto ingredients, pathways and curated literature. It does not verify a product, approve
          a claim, or provide medical advice.
        </p>

        <GlassPanel className="mt-8 p-5">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSubmitted(claim.trim() || null);
            }}
          >
            <label htmlFor="claim" className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">
              Claim text
            </label>
            <textarea
              id="claim"
              value={claim}
              onChange={(e) => setClaim(e.target.value)}
              rows={3}
              placeholder="e.g. Peptides stimulate collagen synthesis and skin firmness"
              className="mt-2 w-full rounded-xl border border-border bg-ink-2/60 px-3 py-2 text-sm text-card-foreground"
            />
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button
                type="submit"
                className="rounded-full border border-accent/40 bg-accent/15 px-4 py-2 text-sm text-accent"
              >
                Evaluate claim
              </button>
              {EXAMPLES.map((ex) => (
                <button
                  key={ex}
                  type="button"
                  onClick={() => {
                    setClaim(ex);
                    setSubmitted(ex);
                  }}
                  className="rounded-full border border-border px-3 py-1 text-xs text-foreground/60"
                >
                  {ex}
                </button>
              ))}
            </div>
          </form>
        </GlassPanel>

        {submitted && (
          <div className="mt-8 space-y-4">
            <GlassPanel className="p-5">
              <Eyebrow>Assessment</Eyebrow>
              <p className="mt-3 font-display text-2xl text-card-foreground">{plausibility}</p>
              <p className="mt-2 text-sm text-foreground/65">
                {related.length} curated {related.length === 1 ? "study" : "studies"} relate to this claim · evidence
                strength {evidence.strength} (index {evidence.index}, experimental)
              </p>
              <div className="mt-3">
                <ReplicationBadge flag={flag} showDetail />
              </div>
              {(overstatement.overstated || analysis?.verdict === "overstated") && (
                <div className="mt-3">
                  <OverstatedBadge
                    reasons={
                      analysis?.verdict === "overstated" && analysis.overstated_language.length
                        ? [...overstatement.reasons, ...analysis.overstated_language]
                        : overstatement.reasons.length
                          ? overstatement.reasons
                          : ["The AI analysis judged this wording stronger than the curated evidence supports."]
                    }
                  />
                </div>
              )}
              {related.length === 0 && (
                <p className="mt-3 text-xs text-foreground/50">
                  Insufficient evidence in our dataset to evaluate this claim. That is not proof the claim is false.
                </p>
              )}
            </GlassPanel>

            <GlassPanel className="p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <Eyebrow tone="violet">AI mechanism analysis</Eyebrow>
                <div className="flex flex-wrap gap-2">
                  <SaveSearchButton query={submitted} label={submitted.slice(0, 80)} kind="claim" />
                  {!authLoading && signedIn ? (
                    <button
                      type="button"
                      onClick={() => ai.mutate({ claim: submitted, context: aiContext })}
                      disabled={ai.isPending}
                      className="rounded-full border border-violet/40 bg-violet/15 px-4 py-1.5 text-xs text-violet disabled:opacity-50"
                    >
                      {ai.isPending ? "Analysing…" : analysis ? "Re-run analysis" : "Analyse with AI"}
                    </button>
                  ) : (
                    <Link
                      to="/auth"
                      className="rounded-full border border-border px-4 py-1.5 text-xs text-foreground/60"
                    >
                      Sign in to analyse
                    </Link>
                  )}
                </div>
              </div>
              <p className="mt-3 text-xs leading-relaxed text-foreground/50">
                The analysis reasons only over the curated context above. It is educational, experimental, and not a
                medical, diagnostic or efficacy assessment.
              </p>

              {ai.isError && (
                <p className="mt-3 rounded-xl border border-rose/40 bg-rose/10 p-3 text-xs text-rose">
                  {ai.error instanceof Error ? ai.error.message : "The analysis could not be completed."}
                </p>
              )}

              {analysis && (
                <div className="mt-5 space-y-4">
                  <div>
                    <p className="font-mono text-[10px] uppercase tracking-wider text-foreground/40">Verdict</p>
                    <p className="mt-1 font-display text-2xl text-card-foreground">{analysis.verdict}</p>
                    <p className="mt-2 text-sm leading-relaxed text-foreground/70">{analysis.plausibility_summary}</p>
                  </div>

                  {analysis.mechanism_steps.length > 0 && (
                    <ol className="space-y-4 border-l border-border pl-4">
                      {analysis.mechanism_steps.map((m, idx) => {
                        const cited = citedFor(m.study_ids);
                        return (
                          <li key={`${m.step}-${idx}`}>
                            <p className="text-sm text-card-foreground">
                              <span className="font-mono text-[10px] text-foreground/40">{idx + 1}. </span>
                              {m.step}
                            </p>
                            <p className="mt-0.5 text-xs leading-relaxed text-foreground/55">{m.explanation}</p>
                            {cited.length > 0 ? (
                              <ul className="mt-2 space-y-1.5">
                                {cited.map((s) => (
                                  <li
                                    key={s.id}
                                    className="rounded-xl border border-border bg-ink-2/40 px-3 py-2 text-xs"
                                  >
                                    <div className="flex flex-wrap items-center gap-2">
                                      <StudyTypeTag type={s.type} />
                                      <span className="font-mono text-[10px] text-foreground/45">
                                        {s.journal} · {s.year}
                                        {s.sampleSize ? ` · n = ${s.sampleSize}` : ""}
                                      </span>
                                      <a
                                        href={
                                          s.pmid
                                            ? externalLink.pubmed(s.pmid)
                                            : s.doi
                                              ? externalLink.doi(s.doi)
                                              : externalLink.europePmcSearch(s.title)
                                        }
                                        target="_blank"
                                        rel="noreferrer noopener"
                                        className="font-mono text-[10px] text-accent underline underline-offset-4"
                                      >
                                        {s.pmid ? `PMID ${s.pmid}` : s.doi ? `DOI ${s.doi}` : "search Europe PMC"}
                                      </a>
                                    </div>
                                    <p className="mt-1 leading-snug text-card-foreground">{s.title}</p>
                                    <p className="mt-1 leading-relaxed text-foreground/50">
                                      <span className="font-mono uppercase tracking-wider">Limitations</span> —{" "}
                                      {s.limitations}
                                    </p>
                                  </li>
                                ))}
                              </ul>
                            ) : (
                              <p className="mt-2 rounded-xl border border-amber/30 bg-amber/8 px-3 py-1.5 text-[11px] text-amber">
                                No curated study in this dataset tests this step directly — it rests on general biology.
                              </p>
                            )}
                          </li>
                        );
                      })}
                    </ol>
                  )}

                  <div className="grid gap-4 md:grid-cols-2">
                    {[
                      ["Supported by", analysis.supported_by] as const,
                      ["Evidence gaps", analysis.evidence_gaps] as const,
                      ["Overstated language", analysis.overstated_language] as const,
                    ].map(([label, list]) =>
                      list.length > 0 ? (
                        <div key={label}>
                          <p className="font-mono text-[10px] uppercase tracking-wider text-foreground/40">{label}</p>
                          <ul className="mt-1.5 space-y-1 text-xs leading-relaxed text-foreground/65">
                            {list.map((x) => (
                              <li key={x}>· {x}</li>
                            ))}
                          </ul>
                        </div>
                      ) : null,
                    )}
                  </div>

                  <p className="rounded-xl border border-border bg-foreground/5 p-3 text-xs leading-relaxed text-foreground/55">
                    {analysis.medical_caveat}
                  </p>
                </div>
              )}
            </GlassPanel>

            <div className="grid gap-4 md:grid-cols-2">
              <GlassPanel className="p-5">
                <Eyebrow tone="brand">Mapped ingredients</Eyebrow>
                <ul className="mt-3 flex flex-wrap gap-1.5">
                  {matchedIngredients.length ? (
                    matchedIngredients.map((i) => (
                      <li key={i.slug}>
                        <Link
                          to="/ingredient/$slug"
                          params={{ slug: i.slug }}
                          className="rounded-full border border-border bg-foreground/5 px-3 py-1 text-xs"
                        >
                          {i.name}
                        </Link>
                      </li>
                    ))
                  ) : (
                    <li className="text-sm text-foreground/50">No ingredient recognised in the claim</li>
                  )}
                </ul>
              </GlassPanel>
              <GlassPanel className="p-5">
                <Eyebrow tone="amber">Mapped biology</Eyebrow>
                <ul className="mt-3 flex flex-wrap gap-1.5">
                  {matchedTopics.length ? (
                    matchedTopics.map((t) => (
                      <li key={t.slug}>
                        <Link
                          to="/topic/$slug"
                          params={{ slug: t.slug }}
                          className="rounded-full border border-border bg-foreground/5 px-3 py-1 text-xs"
                        >
                          {t.name}
                        </Link>
                      </li>
                    ))
                  ) : (
                    <li className="text-sm text-foreground/50">No biology map recognised in the claim</li>
                  )}
                </ul>
              </GlassPanel>
            </div>

            {related.length > 0 && (
              <div>
                <Eyebrow tone="muted">Supporting and mixed literature</Eyebrow>
                <div className="mt-3 grid gap-3 md:grid-cols-2">
                  {related.slice(0, 12).map((s) => (
                    <StudyCard key={s.id} study={s} />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </section>
    </PageShell>
  );
}
