import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { ArtCanvas } from "@/components/ArtCanvas";
import { ingredients, ingredientBySlug } from "@/data/ingredients";
import { buildIngredientGraph } from "@/lib/graph";
import { ART_STYLES, type ArtStyle } from "@/lib/art";

export const Route = createFileRoute("/art")({
  staticData: { sitemap: true },
  validateSearch: (search: Record<string, unknown>) => ({
    ingredient: typeof search['ingredient'] === "string" && search['ingredient'] ? search['ingredient'] : "niacinamide",
    style: (typeof search['style'] === "string" && ART_STYLES.some((s) => s.id === search['style'])
      ? search['style']
      : "constellation") as ArtStyle,
    labels: search['labels'] === true || search['labels'] === "true",
  }),
  head: () => ({
    meta: [
      { title: "Biology as Art — generative visuals from real networks | Skinceptor" },
      {
        name: "description",
        content:
          "Turn ingredient biology networks into deterministic generative artwork — constellation, galaxy, cellular tapestry and fingerprint styles, exportable as PNG.",
      },
      { property: "og:title", content: "Biology as Art — Skinceptor" },
      { property: "og:description", content: "Deterministic art generated from scientific relationship graphs." },
    ],
  }),
  component: ArtPage,
});

function ArtPage() {
  const { ingredient, style, labels } = Route.useSearch();
  const navigate = Route.useNavigate();
  const ing = ingredientBySlug.get(ingredient) ?? ingredients[0]!;
  const graph = buildIngredientGraph(ing);

  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <Eyebrow tone="rose">Biology as art</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">
          The same data, seen differently
        </h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-foreground/60">
          Each artwork is generated deterministically from the ingredient's biological network. The same ingredient and
          style always produce the same image; nothing is randomised for decoration.
        </p>

        <div className="mt-8 grid gap-6 lg:grid-cols-[320px_1fr]">
          <div className="space-y-4">
            <GlassPanel className="p-5">
              <label className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Ingredient</label>
              <select
                value={ing.slug}
                onChange={(e) => navigate({ to: ".", search: (prev) => ({ ...prev, ingredient: e.target.value }) })}
                className="mt-2 w-full rounded-xl border border-border bg-ink-2/60 px-3 py-2 text-sm text-card-foreground"
              >
                {ingredients.map((i) => (
                  <option key={i.slug} value={i.slug}>
                    {i.name}
                  </option>
                ))}
              </select>

              <p className="mt-5 font-mono text-[10px] uppercase tracking-wider text-foreground/45">Style</p>
              <div className="mt-2 space-y-2">
                {ART_STYLES.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => navigate({ to: ".", search: (prev) => ({ ...prev, style: s.id }) })}
                    aria-pressed={style === s.id}
                    className={`w-full rounded-xl border px-3 py-2 text-left transition-colors ${
                      style === s.id ? "border-accent/50 bg-accent/10" : "border-border"
                    }`}
                  >
                    <span className="text-sm text-card-foreground">{s.label}</span>
                    <span className="mt-0.5 block text-xs text-foreground/55">{s.description}</span>
                  </button>
                ))}
              </div>

              <label className="mt-5 flex items-center gap-2 text-xs text-foreground/65">
                <input
                  type="checkbox"
                  checked={labels}
                  onChange={(e) => navigate({ to: ".", search: (prev) => ({ ...prev, labels: e.target.checked }) })}
                />
                Show scientific labels
              </label>
            </GlassPanel>

            <GlassPanel className="p-5">
              <Eyebrow tone="muted">What you are looking at</Eyebrow>
              <p className="mt-2 text-xs leading-relaxed text-foreground/60">
                {graph.nodes.length} biological entities and {graph.edges.length} curated relationships for {ing.name}.
                Colour encodes entity category; opacity encodes relationship confidence.
              </p>
            </GlassPanel>
          </div>

          <ArtCanvas graph={graph} seed={`${ing.slug}`} style={style} showLabels={labels} size={860} />
        </div>
      </section>
    </PageShell>
  );
}
