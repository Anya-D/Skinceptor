import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { EvidenceDashboard } from "@/components/EvidenceDashboard";
import { ingredients, ingredientBySlug } from "@/data/ingredients";
import { studiesForIngredient } from "@/data/studies";
import { replicationFlag } from "@/lib/evidence";
import { ReplicationBadge } from "@/components/EvidenceFlags";
import { exportEvidenceReport } from "@/lib/report";

export const Route = createFileRoute("/compare")({
  staticData: { sitemap: true },
  validateSearch: (search: Record<string, unknown>) => ({
    a: typeof search['a'] === "string" && search['a'] ? search['a'] : "niacinamide",
    b: typeof search['b'] === "string" && search['b'] ? search['b'] : "l-ascorbic-acid",
  }),
  head: () => ({
    meta: [
      { title: "Compare ingredients biologically — Skinceptor" },
      {
        name: "description",
        content:
          "Compare two cosmetic ingredients side by side: shared and distinct biological targets, pathways, processes and evidence profiles.",
      },
      { property: "og:title", content: "Compare ingredients biologically — Skinceptor" },
      { property: "og:description", content: "Shared vs distinct pathways, targets and evidence." },
    ],
  }),
  component: ComparePage,
});

function ComparePage() {
  const { a, b } = Route.useSearch();
  const navigate = Route.useNavigate();
  const A = ingredientBySlug.get(a) ?? ingredients[0]!;
  const B = ingredientBySlug.get(b) ?? ingredients[1]!;

  const pathA = new Set(A.pathways.map((p) => p.name));
  const pathB = new Set(B.pathways.map((p) => p.name));
  const shared = [...pathA].filter((p) => pathB.has(p));
  const onlyA = [...pathA].filter((p) => !pathB.has(p));
  const onlyB = [...pathB].filter((p) => !pathA.has(p));

  const [copied, setCopied] = useState(false);
  const shareLink = async () => {
    const url = `${window.location.origin}/compare?a=${encodeURIComponent(A.slug)}&b=${encodeURIComponent(B.slug)}`;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2500);
    } catch {
      window.prompt("Copy this comparison link", url);
    }
  };

  const select = "rounded-xl border border-border bg-ink-2/60 px-3 py-2 text-sm text-card-foreground w-full";

  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <Eyebrow tone="violet">Comparison</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">
          Biological comparison
        </h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-foreground/60">
          This compares mechanisms and evidence profiles. It is not a ranking, a recommendation, or a safety assessment.
        </p>

        <div className="mt-6 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={shareLink}
            className="rounded-full border border-border bg-foreground/10 px-4 py-2 text-sm"
          >
            {copied ? "Link copied" : "Copy shareable link"}
          </button>
          <button
            type="button"
            onClick={() =>
              exportEvidenceReport(
                [
                  { ingredient: A, studies: studiesForIngredient(A.slug) },
                  { ingredient: B, studies: studiesForIngredient(B.slug) },
                ],
                `${A.name} vs ${B.name} — comparison and evidence report`,
              )
            }
            className="rounded-full border border-accent/40 bg-accent/10 px-4 py-2 text-sm text-accent"
          >
            Export PDF report
          </button>
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <label>
            <span className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Ingredient A</span>
            <select
              value={A.slug}
              onChange={(e) => navigate({ to: ".", search: (prev) => ({ ...prev, a: e.target.value }) })}
              className={`mt-1 ${select}`}
            >
              {ingredients.map((i) => (
                <option key={i.slug} value={i.slug}>
                  {i.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">Ingredient B</span>
            <select
              value={B.slug}
              onChange={(e) => navigate({ to: ".", search: (prev) => ({ ...prev, b: e.target.value }) })}
              className={`mt-1 ${select}`}
            >
              {ingredients.map((i) => (
                <option key={i.slug} value={i.slug}>
                  {i.name}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="mt-8 grid gap-4 lg:grid-cols-3">
          <GlassPanel className="p-5">
            <Eyebrow tone="brand">{A.name} only</Eyebrow>
            <ul className="mt-3 space-y-1.5 text-sm text-foreground/70">
              {onlyA.length ? onlyA.map((p) => <li key={p}>{p}</li>) : <li className="text-foreground/45">None</li>}
            </ul>
          </GlassPanel>
          <GlassPanel className="p-5">
            <Eyebrow>Shared pathways</Eyebrow>
            <ul className="mt-3 space-y-1.5 text-sm text-card-foreground">
              {shared.length ? (
                shared.map((p) => <li key={p}>{p}</li>)
              ) : (
                <li className="text-foreground/45">No shared curated pathways</li>
              )}
            </ul>
          </GlassPanel>
          <GlassPanel className="p-5">
            <Eyebrow tone="rose">{B.name} only</Eyebrow>
            <ul className="mt-3 space-y-1.5 text-sm text-foreground/70">
              {onlyB.length ? onlyB.map((p) => <li key={p}>{p}</li>) : <li className="text-foreground/45">None</li>}
            </ul>
          </GlassPanel>
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          {[A, B].map((ing) => (
            <GlassPanel key={ing.slug} className="p-5">
              <h2 className="font-display text-2xl text-card-foreground">{ing.name}</h2>
              <p className="mt-1 font-mono text-[11px] text-foreground/45">
                {ing.formula ?? "formula unavailable"} · {ing.className}
              </p>
              <div className="mt-3">
                <ReplicationBadge flag={replicationFlag(studiesForIngredient(ing.slug))} showDetail />
              </div>
              <p className="mt-3 text-sm leading-relaxed text-foreground/65">{ing.summary}</p>
              <p className="mt-4 font-mono text-[10px] uppercase tracking-wider text-foreground/40">Targets</p>
              <ul className="mt-1 space-y-1 text-xs text-foreground/65">
                {ing.targets.map((t) => (
                  <li key={t.name}>
                    {t.name} — {t.relation} ({t.confidence.toLowerCase()} confidence)
                  </li>
                ))}
              </ul>
            </GlassPanel>
          ))}
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          <EvidenceDashboard studies={studiesForIngredient(A.slug)} />
          <EvidenceDashboard studies={studiesForIngredient(B.slug)} />
        </div>
      </section>
    </PageShell>
  );
}
