import { createFileRoute } from "@tanstack/react-router";
import { getRouterInstance } from "@tanstack/react-start";
import { isSitemapRouteIncluded, sitemapStaticPaths, sitemapXML, sitemapPathForLocation, type SitemapEntry } from "@/lib/sitemap";
import { ingredients } from "@/data/ingredients";
import { topics } from "@/data/topics";

const BASE_URL = "https://skinceptor.tech";

export const Route = createFileRoute("/sitemap.xml")({
  staticData: { sitemap: false },
  server: {
    handlers: {
      GET: async () => {
        if (!BASE_URL) {
          return new Response("Sitemap domain not configured", {
            status: 503,
            headers: { "Cache-Control": "no-store" },
          });
        }
        const router = await getRouterInstance();
        const entries: SitemapEntry[] = sitemapStaticPaths(router).map((path) => ({ path }));

        // Dynamic ingredient pages — sourced from the local curated dataset.
        const ingredientRouteId = "/ingredient/$slug";
        if (isSitemapRouteIncluded(router.routesById[ingredientRouteId])) {
          for (const ing of ingredients) {
            const location = router.buildLocation({
              to: ingredientRouteId,
              params: { slug: ing.slug },
              search: () => ({}),
              hash: "",
            });
            const path = sitemapPathForLocation(router, location, ingredientRouteId);
            if (path) entries.push({ path });
          }
        }

        // Dynamic biology-map (topic) pages — sourced from the local curated dataset.
        const topicRouteId = "/topic/$slug";
        if (isSitemapRouteIncluded(router.routesById[topicRouteId])) {
          for (const tp of topics) {
            const location = router.buildLocation({
              to: topicRouteId,
              params: { slug: tp.slug },
              search: () => ({}),
              hash: "",
            });
            const path = sitemapPathForLocation(router, location, topicRouteId);
            if (path) entries.push({ path });
          }
        }

        if (entries.length === 0) {
          return new Response(
            'No pages are included in this sitemap. Check route decisions and ancestor exclusions. Setting "exclude-subtree" on the root excludes the entire site.',
            { status: 404, headers: { "Cache-Control": "no-store" } },
          );
        }
        return new Response(sitemapXML(BASE_URL, entries), {
          headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=3600" },
        });
      },
    },
  },
});
