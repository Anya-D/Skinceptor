import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/SiteChrome";
import { SearchBar } from "@/components/SearchBar";
import { BiologyNetwork } from "@/components/BiologyNetwork";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { ArtCanvas } from "@/components/ArtCanvas";
import { ingredientBySlug } from "@/data/ingredients";
import { topics } from "@/data/topics";
import { studiesForIngredient } from "@/data/studies";
import { buildIngredientGraph, filterGraph } from "@/lib/graph";
import { computeEvidence } from "@/lib/evidence";

export const Route = createFileRoute("/")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Skinceptor — Explore the biology underneath beauty" },
      {
        name: "description",
        content:
          "Search a cosmetic ingredient, gene, pathway or beauty topic and explore its molecules, biological targets, pathways and the evidence behind them.",
      },
      { property: "og:title", content: "Skinceptor — Explore the biology underneath beauty" },
      {
        property: "og:description",
        content:
          "An interactive scientific platform connecting ingredients, molecules, pathways and peer-reviewed evidence.",
      },
    ],
    links: [{ rel: "canonical", href: "https://skinceptor.tech/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "WebSite",
              "@id": "https://skinceptor.tech/#website",
              name: "Skinceptor",
              url: "https://skinceptor.tech/",
              description:
                "Educational biological-intelligence platform mapping beauty ingredients to molecules, biological targets, genes, pathways and peer-reviewed evidence.",
              inLanguage: "en",
              potentialAction: {
                "@type": "SearchAction",
                target: {
                  "@type": "EntryPoint",
                  urlTemplate: "https://skinceptor.tech/research?q={search_term_string}",
                },
                "query-input": "required name=search_term_string",
              },
            },
            {
              "@type": "Organization",
              "@id": "https://skinceptor.tech/#organization",
              name: "Skinceptor",
              url: "https://skinceptor.tech/",
            },
          ],
        }),
      },
    ],
  }),
  component: Home,
});

function Home() {
  const niacinamide = ingredientBySlug.get("niacinamide")!;
  const graph = buildIngredientGraph(niacinamide);
  const preview = filterGraph(graph, "HIGH");
  const evidence = computeEvidence(studiesForIngredient("niacinamide"));

  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 pb-10 pt-12 sm:px-6 sm:pt-16">
        <div className="grid items-start gap-10 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-foreground/5 px-3 py-1 font-mono text-[11px] uppercase tracking-[0.18em] text-accent">
              <span className="size-1.5 rounded-full bg-accent" aria-hidden="true" /> Evidence-grounded biology
            </div>
            <h1 className="mt-6 font-display font-light leading-[0.95] tracking-tight text-card-foreground">
              <span className="sr-only">Skinceptor — biological intelligence for beauty ingredients. </span>
              <span className="block text-5xl md:text-7xl">Beauty isn't just</span>
              <span className="block text-5xl md:text-7xl">
                what you <span className="text-accent">see.</span>
              </span>
            </h1>
            <p className="mt-5 font-display text-2xl font-light text-foreground/90 md:text-3xl">
              Explore the biology underneath it.
            </p>
            <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-foreground/60">
              Skinceptor connects ingredients, molecules, biological pathways and peer-reviewed evidence — so you can
              understand what beauty products are doing beneath the surface.
            </p>

            <div className="mt-8 max-w-2xl">
              <SearchBar />
            </div>

            <p className="mt-5 font-mono text-xs uppercase tracking-wider text-foreground/40">
              Ingredients → Molecules → Targets → Genes → Pathways → Evidence
            </p>
          </div>

          <div className="lg:col-span-5">
            <GlassPanel className="rounded-3xl p-4">
              <div className="mb-3 flex items-center justify-between gap-3">
                <div>
                  <Eyebrow as="h2">Live biology network</Eyebrow>
                  <p className="font-display text-lg text-card-foreground">Niacinamide → biology</p>
                </div>
                <Link
                  to="/ingredient/$slug"
                  params={{ slug: "niacinamide" }}
                  className="rounded-md border border-accent/40 bg-accent/10 px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-accent"
                >
                  Open
                </Link>
              </div>
              <BiologyNetwork graph={preview} caption="High-confidence niacinamide network" className="border-0 p-0" />
            </GlassPanel>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6">
        <div className="grid gap-4 md:grid-cols-3">
          <GlassPanel className="p-5">
            <Eyebrow as="h2" tone="brand">Evidence engine</Eyebrow>
            <div className="mt-4 flex items-center justify-between">
              <span className="font-display text-2xl text-card-foreground">{evidence.strength}</span>
              <span className="font-mono text-[11px] text-foreground/50">Index {evidence.index} · experimental</span>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-foreground/60">
              Every ingredient gets a transparent breakdown of study design, human data, replication, consistency and
              recency — never a single unexplained score.
            </p>
            <Link
              to="/methodology"
              className="mt-4 inline-block text-xs text-accent underline underline-offset-4 hover:text-card-foreground"
            >
              How is this determined? →
            </Link>
          </GlassPanel>

          <GlassPanel className="p-5">
            <Eyebrow as="h2" tone="amber">Biology maps</Eyebrow>
            <ul className="mt-4 space-y-2">
              {topics.map((t) => (
                <li key={t.slug}>
                  <Link
                    to="/topic/$slug"
                    params={{ slug: t.slug }}
                    className="flex items-baseline justify-between gap-3 rounded-lg px-2 py-1.5 text-sm text-foreground/75 transition-colors hover:bg-foreground/5 hover:text-card-foreground"
                  >
                    {t.name}
                    <span className="font-mono text-[10px] text-foreground/40">{t.genes.length} genes</span>
                  </Link>
                </li>
              ))}
            </ul>
          </GlassPanel>

          <GlassPanel className="p-5">
            <Eyebrow as="h2" tone="rose">Biology as art</Eyebrow>
            <ArtCanvas
              graph={graph}
              seed="niacinamide"
              style="fingerprint"
              size={420}
              interactive={false}
              className="mt-4"
            />
            <p className="mt-3 text-xs text-foreground/50">
              Deterministically generated from the underlying scientific network — never decorative.
            </p>
            <Link to="/art" search={{ ingredient: "niacinamide", style: "constellation", labels: false }} className="mt-3 inline-block text-xs text-accent underline underline-offset-4">
              Open art mode →
            </Link>
          </GlassPanel>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6">
        <GlassPanel className="flex flex-col gap-6 p-6 md:flex-row md:items-center md:justify-between">
          <div className="max-w-xl">
            <Eyebrow as="h2" tone="violet">Ingredient checker</Eyebrow>
            <h2 className="mt-3 font-display text-2xl text-card-foreground md:text-3xl">
              Paste a product's ingredient list. See the biology underneath.
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-foreground/60">
              Drop in any skincare INCI list and Skinceptor matches each entry against its curated dataset — showing the
              pathways, processes and evidence strength behind every recognised ingredient, plus a summary of where the
              formula concentrates. Entries it doesn't cover yet are listed honestly. It never judges safety or product quality.
            </p>
          </div>
          <Link
            to="/ingredient-checker"
            className="shrink-0 rounded-full border border-accent/40 bg-accent/10 px-6 py-3 font-mono text-xs uppercase tracking-[0.18em] text-accent transition-colors hover:bg-accent/20"
          >
            Check a list →
          </Link>
        </GlassPanel>
      </section>
    </PageShell>
  );
}
