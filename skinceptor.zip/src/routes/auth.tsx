import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

/** Same-origin relative path only — anything else is discarded. */
function safeNext(value: unknown): string | undefined {
  if (typeof value !== "string" || !value.startsWith("/") || value.startsWith("//")) return undefined;
  return value;
}

export const Route = createFileRoute("/auth")({
  staticData: { sitemap: false },
  validateSearch: (s: Record<string, unknown>): { next?: string } => {
    const next = safeNext(s["next"]);
    return next ? { next } : {};
  },
  head: () => ({
    meta: [
      { title: "Sign in — save your Skinceptor research | Skinceptor" },
      {
        name: "description",
        content:
          "Create a Skinceptor account to save searches, build a personal ingredient library, submit evidence and run AI claim analysis.",
      },
      { property: "og:title", content: "Sign in — Skinceptor" },
      { property: "og:description", content: "Saved searches, a personal ingredient library and AI claim analysis." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const { signedIn, loading } = useAuth();
  const { next } = Route.useSearch();
  const go = () => (next ? window.location.assign(next) : void navigate({ to: "/library" }));
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (!loading && signedIn) go();
  }, [loading, signedIn, navigate]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      if (mode === "signup") {
        const { data, error: err } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/auth${next ? `?next=${encodeURIComponent(next)}` : ""}` },
        });
        if (err) throw err;
        if (data.session) {
          go();
        } else {
          setNotice("Check your inbox for a confirmation link, then sign in.");
        }
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({ email, password });
        if (err) throw err;
        go();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong. Try again.");
    } finally {
      setBusy(false);
    }
  }

  const input =
    "mt-1.5 w-full rounded-xl border border-border bg-ink-2/60 px-3 py-2 text-sm text-card-foreground placeholder:text-foreground/35";

  return (
    <PageShell>
      <section className="mx-auto max-w-lg px-4 py-16 sm:px-6">
        <Eyebrow tone="brand">Your research space</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground">
          {mode === "signin" ? "Sign in" : "Create an account"}
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-foreground/60">
          An account lets you save searches, keep a personal ingredient library, submit evidence for review and run AI
          claim analysis. Skinceptor remains an educational tool — never medical advice.
        </p>

        <GlassPanel className="mt-8 p-5">
          <form onSubmit={onSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">
                Email
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={input}
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label htmlFor="password" className="font-mono text-[10px] uppercase tracking-wider text-foreground/45">
                Password
              </label>
              <input
                id="password"
                type="password"
                autoComplete={mode === "signup" ? "new-password" : "current-password"}
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={input}
                placeholder="At least 6 characters"
              />
            </div>

            {error && (
              <p role="alert" className="rounded-xl border border-rose/40 bg-rose/10 px-3 py-2 text-xs text-rose">
                {error}
              </p>
            )}
            {notice && (
              <p className="rounded-xl border border-accent/40 bg-accent/10 px-3 py-2 text-xs text-accent">{notice}</p>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full rounded-full border border-accent/40 bg-accent/15 px-4 py-2 text-sm text-accent disabled:opacity-50"
            >
              {busy ? "Working…" : mode === "signin" ? "Sign in" : "Create account"}
            </button>
          </form>

          <div className="mt-4 flex items-center justify-between text-xs text-foreground/55">
            <button
              type="button"
              onClick={() => {
                setMode(mode === "signin" ? "signup" : "signin");
                setError(null);
                setNotice(null);
              }}
              className="underline decoration-foreground/30 underline-offset-4 hover:text-card-foreground"
            >
              {mode === "signin" ? "Need an account? Sign up" : "Already have an account? Sign in"}
            </button>
            <Link to="/explore" className="hover:text-card-foreground">
              Browse without an account
            </Link>
          </div>
        </GlassPanel>
      </section>
    </PageShell>
  );
}
