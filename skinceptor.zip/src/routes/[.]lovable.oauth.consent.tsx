import { createFileRoute, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { supabase } from "@/integrations/supabase/client";

type OAuthNamespace = {
  getAuthorizationDetails: (id: string) => Promise<{ data: AuthorizationDetails | null; error: Error | null }>;
  approveAuthorization: (id: string) => Promise<{ data: RedirectResult | null; error: Error | null }>;
  denyAuthorization: (id: string) => Promise<{ data: RedirectResult | null; error: Error | null }>;
};

interface AuthorizationDetails {
  client?: { name?: string; client_id?: string; client_uri?: string } | null;
  redirect_url?: string;
  redirect_to?: string;
  scope?: string;
}

interface RedirectResult {
  redirect_url?: string;
  redirect_to?: string;
}

const oauth = () => (supabase.auth as unknown as { oauth: OAuthNamespace }).oauth;

export const Route = createFileRoute("/.lovable/oauth/consent")({
  staticData: { sitemap: false },
  ssr: false,
  validateSearch: (s: Record<string, unknown>) => ({
    authorization_id: typeof s["authorization_id"] === "string" ? s["authorization_id"] : "",
  }),
  beforeLoad: async ({ search, location }) => {
    if (!search.authorization_id) throw new Error("Missing authorization_id");
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      throw redirect({ to: "/auth", search: { next: location.pathname + location.searchStr } });
    }
  },
  loader: async ({ location }) => {
    const authorizationId = new URLSearchParams(location.search).get("authorization_id")!;
    const { data, error } = await oauth().getAuthorizationDetails(authorizationId);
    if (error) throw error;
    const immediate = data?.redirect_url ?? data?.redirect_to;
    if (immediate && !data?.client) throw redirect({ href: immediate });
    return data;
  },
  component: Consent,
  errorComponent: ({ error }) => (
    <PageShell>
      <section className="mx-auto max-w-lg px-4 py-20 sm:px-6">
        <GlassPanel className="p-6 text-sm text-foreground/70">
          Could not load this authorization request: {String((error as Error)?.message ?? error)}
        </GlassPanel>
      </section>
    </PageShell>
  ),
});

function Consent() {
  const details = Route.useLoaderData();
  const { authorization_id } = Route.useSearch();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const clientName = details?.client?.name ?? "this app";

  async function decide(approve: boolean) {
    setBusy(true);
    setError(null);
    const { data, error: err } = approve
      ? await oauth().approveAuthorization(authorization_id)
      : await oauth().denyAuthorization(authorization_id);
    if (err) {
      setBusy(false);
      setError(err.message);
      return;
    }
    const target = data?.redirect_url ?? data?.redirect_to;
    if (!target) {
      setBusy(false);
      setError("No redirect returned by the authorization server.");
      return;
    }
    window.location.href = target;
  }

  const btn =
    "rounded-xl px-4 py-2 text-sm font-medium transition disabled:opacity-50 disabled:cursor-not-allowed";

  return (
    <PageShell>
      <section className="mx-auto max-w-lg px-4 py-20 sm:px-6">
        <Eyebrow tone="brand">Authorize access</Eyebrow>
        <h1 className="mt-3 font-display text-3xl font-light text-card-foreground">
          Connect {clientName} to your Skinceptor account
        </h1>
        <GlassPanel className="mt-6 p-6">
          <p className="text-sm leading-relaxed text-foreground/70">
            {clientName} is asking to use Skinceptor as you. It will be able to read Skinceptor&rsquo;s curated
            ingredient biology and studies, read your saved library and searches, and save new items to your library.
          </p>
          <p className="mt-3 text-xs leading-relaxed text-foreground/50">
            Skinceptor is an educational biological-intelligence tool. Nothing it returns is medical advice, diagnosis
            or treatment. You can revoke this access at any time.
          </p>
          {error && (
            <p role="alert" className="mt-4 text-sm text-rose-300">
              {error}
            </p>
          )}
          <div className="mt-6 flex flex-wrap gap-3">
            <button
              type="button"
              disabled={busy}
              onClick={() => void decide(true)}
              className={`${btn} bg-brand/20 text-card-foreground ring-1 ring-brand/40 hover:bg-brand/30`}
            >
              {busy ? "Working…" : "Approve"}
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => void decide(false)}
              className={`${btn} border border-border text-foreground/70 hover:text-card-foreground`}
            >
              Deny
            </button>
          </div>
        </GlassPanel>
      </section>
    </PageShell>
  );
}
