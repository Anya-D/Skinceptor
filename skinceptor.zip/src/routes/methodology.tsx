import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { EVIDENCE_WEIGHTS } from "@/lib/evidence";

export const Route = createFileRoute("/methodology")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Methodology — how the Skinceptor Evidence Index works" },
      {
        name: "description",
        content:
          "How Skinceptor builds biological networks, assigns confidence tiers, and computes its experimental Evidence Index from study design, human data, replication and recency.",
      },
      { property: "og:title", content: "Methodology — Skinceptor" },
      { property: "og:description", content: "Transparent scoring, confidence tiers and stated limitations." },
    ],
  }),
  component: Methodology,
});

const WEIGHT_COPY: Record<string, string> = {
  design: "Study design quality — randomised and controlled human work counts most",
  human: "Proportion of evidence generated in human skin or hair",
  volume: "Number of independent curated studies",
  sample: "Largest reported sample size",
  replication: "Independent replication across separate studies",
  recency: "How recent the body of evidence is",
  identifiers: "Traceability — verified PMIDs or DOIs",
};

const SECTIONS = [
  {
    title: "Confidence tiers",
    body: "HIGH means the relationship is documented in a curated public database (UniProt, Reactome, Gene Ontology) or replicated in human studies. MEDIUM means mechanistic support exists but human replication is limited. LOW means the relationship is proposed, in-vitro only, or inconsistently reported. When we cannot place a relationship in any tier, we omit it rather than guess.",
  },
  {
    title: "Network construction",
    body: "Networks are generated from the curated dataset in a fixed order: ingredient → molecule → biological target → gene/protein → pathway → tissue process → studied outcome. A tier appears only when curated entities exist for it. Missing links are shown as gaps, not bridged with inference.",
  },
  {
    title: "What the Evidence Index is not",
    body: "It is not a safety rating, an efficacy guarantee, a product score, or a clinical recommendation. It summarises how much and what kind of published evidence our dataset holds for an ingredient. A low index frequently means 'little studied', not 'ineffective'.",
  },
  {
    title: "Quantitative synthesis",
    body: "We only describe pooled effects when at least four comparable human or randomised studies exist. Otherwise the interface states: insufficient comparable evidence for quantitative synthesis.",
  },
  {
    title: "Medical boundary",
    body: "Skinceptor is educational biological intelligence and research navigation. It does not diagnose, treat, or prescribe, and it is not a substitute for a dermatologist or physician.",
  },
];

function Methodology() {
  return (
    <PageShell>
      <section className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <Eyebrow>Methodology</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">
          How we determine what we show
        </h1>
        <p className="mt-4 text-[15px] leading-relaxed text-foreground/65">
          Every number in Skinceptor is decomposable. If a component cannot be traced to a public database record or a
          published study, it does not appear.
        </p>

        <GlassPanel className="mt-8 p-6">
          <Eyebrow tone="brand">Evidence Index components (experimental)</Eyebrow>
          <ul className="mt-4 space-y-3">
            {Object.entries(EVIDENCE_WEIGHTS).map(([key, weight]) => (
              <li key={key} className="border-b border-border/60 pb-3 last:border-0">
                <div className="flex items-baseline justify-between gap-3">
                  <p className="text-sm text-card-foreground">{WEIGHT_COPY[key] ?? key}</p>
                  <span className="font-mono text-xs text-accent">{Math.round(weight * 100)}%</span>
                </div>
              </li>
            ))}
          </ul>
        </GlassPanel>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {SECTIONS.map((s) => (
            <GlassPanel key={s.title} className="p-5">
              <h2 className="font-display text-xl text-card-foreground">{s.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-foreground/65">{s.body}</p>
            </GlassPanel>
          ))}
        </div>

        <p className="mt-8 text-sm text-foreground/60">
          See the{" "}
          <Link to="/sources" className="text-accent underline underline-offset-4">
            data sources
          </Link>{" "}
          page for every database we draw on.
        </p>
      </section>
    </PageShell>
  );
}
