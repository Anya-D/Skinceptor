import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { ingredients } from "@/data/ingredients";
import { topics } from "@/data/topics";
import { studies } from "@/data/studies";

export const Route = createFileRoute("/about")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "About — Skinceptor, biological intelligence for beauty" },
      {
        name: "description",
        content:
          "Skinceptor maps beauty ingredients to their molecules, biological targets, genes and pathways with sourced evidence — educational biological intelligence, not medical advice.",
      },
      { property: "og:type", content: "website" },
      { property: "og:title", content: "About — Skinceptor" },
      {
        property: "og:description",
        content:
          "An educational biological-intelligence platform connecting beauty ingredients, molecules, pathways and peer-reviewed evidence.",
      },
      { property: "og:url", content: "https://skinceptor.tech/about" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://skinceptor.tech/about" }],
  }),
  component: About,
});

const CAPABILITIES = [
  {
    title: "Ingredient explorer",
    body: "Chemical identity — formula, molecular weight, PubChem and UniProt references — alongside an interactive Ingredient → Molecule → Target → Gene → Pathway → Process → Outcome network, a confidence-tiered evidence dashboard and a filterable study timeline.",
    to: "/explore" as const,
    link: "Browse ingredients",
  },
  {
    title: "Biology maps",
    body: "Topic explorers for skin barrier function, photoaging and collagen degradation, melanogenesis, hair follicle cycling, epidermal turnover and oxidative stress — each traced to its genes, pathways and studied ingredients.",
    to: "/explore" as const,
    link: "Open biology maps",
  },
  {
    title: "Research library",
    body: "Filterable literature by ingredient, pathway and study design — human, in-vitro, animal, RCT and review — with DOI and PMID links to the original records.",
    to: "/research" as const,
    link: "Search the literature",
  },
  {
    title: "Compare",
    body: "Side-by-side biological comparison of two ingredients, surfacing shared versus distinct pathways, targets and supporting evidence.",
    to: "/compare" as const,
    link: "Compare ingredients",
  },
  {
    title: "Claim checker",
    body: "Evaluate a beauty claim for biological plausibility. Supporting and mixed evidence is mapped to pathways, and signed-in users can run an AI mechanism analysis saved to their library.",
    to: "/claim-checker" as const,
    link: "Check a claim",
  },
  {
    title: "Ingredient checker",
    body: "Paste a product's full ingredient list (INCI) and Skinceptor matches each entry against its curated dataset — surfacing the biology, pathways and evidence strength behind every recognised ingredient, alongside an honest list of what it doesn't yet cover. It does not judge safety or product quality.",
    to: "/ingredient-checker" as const,
    link: "Check a list",
  },
  {
    title: "Biology as art",
    body: "Deterministic generative artwork — Constellation, Galaxy, Cellular Tapestry and Fingerprint — derived from real scientific networks and exportable as PNG.",
    to: "/art" as const,
    link: "Generate art",
  },
];

const ACCOUNT_FEATURES = [
  "A personal ingredient and biology-map library with private notes",
  "Saved searches and saved claims, kept per account",
  "Reader-submitted evidence for editorial review",
  "AI-powered claim mechanism analysis, stored to your library",
  "Agent integrations (MCP) so assistants like Claude or ChatGPT can search the dataset and read or add to your own saved library",
];

function About() {
  return (
    <PageShell>
      <section className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <Eyebrow>About</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">
          Biological intelligence for beauty
        </h1>
        <p className="mt-5 text-[15px] leading-relaxed text-foreground/70">
          Skinceptor is an educational biological-intelligence platform for beauty ingredients. It maps a curated,
          cited dataset of {ingredients.length} ingredients to their underlying chemistry, biological targets, genes,
          pathways and cellular processes — visualized as interactive network graphs — and backs every relationship
          with transparent, sourced evidence rather than a single opaque score.
        </p>

        <p className="mt-4 text-[15px] leading-relaxed text-foreground/70">
          The current corpus holds {ingredients.length} ingredients, {topics.length} biology maps and {studies.length}{" "}
          studies. It is a demonstration of the approach, not an exhaustive index of cosmetic science.
        </p>

        <div className="mt-10 grid gap-4 md:grid-cols-2">
          {CAPABILITIES.map((c) => (
            <GlassPanel key={c.title} className="flex flex-col p-5">
              <h2 className="font-display text-xl text-card-foreground">{c.title}</h2>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-foreground/65">{c.body}</p>
              <Link
                to={c.to}
                className="mt-4 inline-block font-mono text-[11px] uppercase tracking-[0.18em] text-accent transition-colors hover:text-brand"
              >
                {c.link} →
              </Link>
            </GlassPanel>
          ))}
        </div>

        <GlassPanel as="section" className="mt-8 p-6">
          <Eyebrow tone="rose">Biology as art — why it matters</Eyebrow>
          <h2 className="mt-3 font-display text-2xl text-card-foreground">
            Every image is a real network, not decoration
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-foreground/65">
            Most "data art" layers randomness over a dataset to look scientific. Skinceptor does the opposite: each
            artwork — Constellation, Pathway Galaxy, Cellular Tapestry and Ingredient Fingerprint — is generated
            deterministically from the ingredient's actual biological relationship graph. The same ingredient and style
            always produce the identical image, because every coordinate is a pure function of real node identifiers,
            biological category, edge structure and relationship confidence. No decorative nodes are invented; nothing
            is randomised.
          </p>
          <p className="mt-4 text-sm leading-relaxed text-foreground/65">
            This matters for three reasons. First, it makes complex biology legible at a glance — a reader can feel
            the density, structure and confidence of an ingredient's evidence network before reading a single citation.
            Second, it gives every ingredient a visual fingerprint: a Fingerprint of Niacinamide is structurally
            distinct from a Fingerprint of Retinol because the underlying science is different, not because the styling
            changed. Third, it bridges the gap between data and intuition — the same rigor that drives the Evidence
            Dashboard produces something you can hang on a wall or export as a PNG, turning peer-reviewed relationships
            into something shareable and human.
          </p>
          <p className="mt-4 text-sm leading-relaxed text-foreground/65">
            In short, Biology as Art is not a novelty layer. It is the same scientific model the rest of Skinceptor
            uses, expressed in a register that prioritizes pattern recognition over precision — a complementary way
            into the same sourced, cited data.
          </p>
          <div className="mt-5">
            <Link
              to="/art"
              search={{ ingredient: "niacinamide", style: "constellation", labels: false }}
              className="inline-block font-mono text-[11px] uppercase tracking-[0.18em] text-accent transition-colors hover:text-brand"
            >
              Generate art →
            </Link>
          </div>
        </GlassPanel>

        <GlassPanel as="section" className="mt-8 p-6">
          <Eyebrow tone="violet">Your account</Eyebrow>
          <h2 className="mt-3 font-display text-2xl text-card-foreground">What signing in unlocks</h2>
          <p className="mt-2 text-sm leading-relaxed text-foreground/65">
            With a free account, Skinceptor becomes personal. Everything below is tied to your account and protected by
            row-level security — you only ever see your own data.
          </p>
          <ul className="mt-4 list-disc space-y-2 pl-5 text-sm leading-relaxed text-foreground/70">
            {ACCOUNT_FEATURES.map((f) => (
              <li key={f}>{f}</li>
            ))}
          </ul>
        </GlassPanel>

        <GlassPanel as="section" className="mt-6 p-6">
          <Eyebrow tone="amber">Medical boundary</Eyebrow>
          <h2 className="mt-3 font-display text-2xl text-card-foreground">What Skinceptor is — and is not</h2>
          <p className="mt-2 text-sm leading-relaxed text-foreground/70">
            Skinceptor is research navigation and educational biological intelligence. It does not diagnose, treat,
            prescribe, or rate the safety or efficacy of any product, and it is not a substitute for a dermatologist or
            physician. Where evidence is absent, the interface shows a gap rather than inventing one — and a low
            evidence index frequently means “little studied”, not “ineffective”.
          </p>
          <div className="mt-5 flex flex-wrap gap-5 text-sm">
            <Link to="/methodology" className="text-accent underline underline-offset-4">
              How the Evidence Index works
            </Link>
            <Link to="/sources" className="text-accent underline underline-offset-4">
              Data sources & limitations
            </Link>
            <Link to="/claim-checker" className="text-accent underline underline-offset-4">
              Check a claim
            </Link>
          </div>
        </GlassPanel>
      </section>
    </PageShell>
  );
}
