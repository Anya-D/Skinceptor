import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { StudyCard } from "@/components/Research";
import { studies } from "@/data/studies";
import { ingredients } from "@/data/ingredients";
import { topics } from "@/data/topics";
import { STUDY_TYPE_LABEL } from "@/lib/evidence";
import { SaveSearchButton } from "@/components/AccountActions";
import type { StudyType } from "@/data/types";

export const Route = createFileRoute("/research")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Research explorer — curated beauty biology literature | Skinceptor" },
      {
        name: "description",
        content:
          "Search and filter curated peer-reviewed studies on cosmetic ingredients by ingredient, biology topic and study design, with direct PMID and DOI links.",
      },
      { property: "og:title", content: "Research explorer — Skinceptor" },
      { property: "og:description", content: "Curated literature with PMIDs, study designs and stated limitations." },
    ],
  }),
  component: ResearchPage,
});

const TYPES: StudyType[] = ["human", "rct", "meta-analysis", "in-vitro", "animal", "review"];

function ResearchPage() {
  const [q, setQ] = useState("");
  const [ingredient, setIngredient] = useState("");
  const [topic, setTopic] = useState("");
  const [type, setType] = useState("");

  const results = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return studies
      .filter((s) => (ingredient ? s.ingredients.includes(ingredient) : true))
      .filter((s) => (topic ? s.topics.includes(topic) : true))
      .filter((s) => (type ? s.type === type : true))
      .filter((s) =>
        needle
          ? `${s.title} ${s.journal} ${s.finding} ${s.ingredients.join(" ")}`.toLowerCase().includes(needle)
          : true,
      )
      .sort((a, b) => b.year - a.year);
  }, [q, ingredient, topic, type]);

  const select = "rounded-xl border border-border bg-ink-2/60 px-3 py-2 text-sm text-card-foreground";

  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <Eyebrow tone="muted">Research explorer</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">
          {studies.length} curated studies
        </h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-foreground/60">
          Every record states its study design, sample size where reported, key finding and limitations. Where an
          identifier could not be verified, the entry links to a Europe PMC title search instead of asserting a PMID.
        </p>

        <GlassPanel className="mt-8 p-4">
          <div className="grid gap-3 md:grid-cols-4">
            <label className="md:col-span-2">
              <span className="sr-only">Search studies</span>
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search titles, journals, findings…"
                className={`${select} w-full`}
              />
            </label>
            <label>
              <span className="sr-only">Filter by ingredient</span>
              <select value={ingredient} onChange={(e) => setIngredient(e.target.value)} className={`${select} w-full`}>
                <option value="">All ingredients</option>
                {ingredients.map((i) => (
                  <option key={i.slug} value={i.slug}>
                    {i.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span className="sr-only">Filter by topic</span>
              <select value={topic} onChange={(e) => setTopic(e.target.value)} className={`${select} w-full`}>
                <option value="">All topics</option>
                {topics.map((t) => (
                  <option key={t.slug} value={t.slug}>
                    {t.name}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setType("")}
              aria-pressed={type === ""}
              className={`rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-wider ${type === "" ? "border-accent/50 bg-accent/15 text-accent" : "border-border text-foreground/55"}`}
            >
              All designs
            </button>
            {TYPES.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setType(t)}
                aria-pressed={type === t}
                className={`rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-wider ${type === t ? "border-accent/50 bg-accent/15 text-accent" : "border-border text-foreground/55"}`}
              >
                {STUDY_TYPE_LABEL[t]}
              </button>
            ))}
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-border/60 pt-3">
            <SaveSearchButton
              query={[q, ingredient, topic, type].filter(Boolean).join(" | ")}
              label={q.trim() || "Filtered research view"}
            />
            <span className="text-xs text-foreground/40">Saved searches live in your library.</span>
          </div>
        </GlassPanel>

        <p className="mt-6 font-mono text-xs uppercase tracking-wider text-foreground/45">
          {results.length} matching {results.length === 1 ? "record" : "records"}
        </p>

        {results.length === 0 ? (
          <p className="mt-6 text-sm text-foreground/55">
            No curated studies match those filters. Absence here means our dataset has no record — not that no research
            exists.
          </p>
        ) : (
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {results.map((s) => (
              <StudyCard key={s.id} study={s} />
            ))}
          </div>
        )}
      </section>
    </PageShell>
  );
}
