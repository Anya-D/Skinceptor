import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { ingredients } from "@/data/ingredients";
import { topics } from "@/data/topics";
import { studies } from "@/data/studies";
import { ProvenanceSummary } from "@/components/Provenance";

export const Route = createFileRoute("/sources")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Data sources — public scientific databases behind Skinceptor" },
      {
        name: "description",
        content:
          "Skinceptor draws on PubChem, UniProt, NCBI Gene, Reactome, Gene Ontology, ChEBI and PubMed. See how each source is used and its limitations.",
      },
      { property: "og:title", content: "Data sources — Skinceptor" },
      { property: "og:description", content: "PubChem, UniProt, Reactome, Gene Ontology, PubMed and more." },
    ],
  }),
  component: Sources,
});

const SOURCES = [
  {
    name: "PubChem",
    url: "https://pubchem.ncbi.nlm.nih.gov/",
    use: "Chemical identity: molecular formula, molecular weight, CID, SMILES and 2D structure images.",
  },
  {
    name: "UniProt",
    url: "https://www.uniprot.org/",
    use: "Protein and enzyme records for biological targets, including accession numbers and functional annotation.",
  },
  {
    name: "NCBI Gene",
    url: "https://www.ncbi.nlm.nih.gov/gene/",
    use: "Gene symbols, official names and identifiers for the genes referenced in networks and topic maps.",
  },
  {
    name: "Reactome",
    url: "https://reactome.org/",
    use: "Curated human pathway definitions used for the pathway tier of every network.",
  },
  {
    name: "Gene Ontology",
    url: "https://geneontology.org/",
    use: "Standardised biological process terms where a Reactome pathway is not the right level of description.",
  },
  {
    name: "ChEBI",
    url: "https://www.ebi.ac.uk/chebi/",
    use: "Chemical entity ontology identifiers for cross-referencing molecules.",
  },
  {
    name: "PubMed / Europe PMC",
    url: "https://pubmed.ncbi.nlm.nih.gov/",
    use: "Primary literature. Each curated study links to its PMID or DOI; unverified identifiers link to a title search instead.",
  },
];

function Sources() {
  return (
    <PageShell>
      <section className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <Eyebrow tone="muted">Sources</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">
          Where the data comes from
        </h1>
        <p className="mt-4 text-[15px] leading-relaxed text-foreground/65">
          Skinceptor is a navigation layer over public scientific resources. The current dataset is curated and static:{" "}
          {ingredients.length} ingredients, {topics.length} biology maps and {studies.length} studies. It is a
          demonstration corpus, not an exhaustive index of cosmetic science.
        </p>

        <div className="mt-8 grid gap-3">
          {SOURCES.map((s) => (
            <GlassPanel key={s.name} className="p-5">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h2 className="font-display text-xl text-card-foreground">{s.name}</h2>
                <a
                  href={s.url}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="font-mono text-[11px] text-accent underline underline-offset-4"
                >
                  Visit source →
                </a>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-foreground/65">{s.use}</p>
            </GlassPanel>
          ))}
        </div>

        <div className="mt-6">
          <ProvenanceSummary />
        </div>

        <GlassPanel className="mt-6 p-5">
          <Eyebrow tone="amber">Known limitations</Eyebrow>
          <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-relaxed text-foreground/65">
            <li>Coverage is uneven — well-funded ingredients have far more literature than newer actives.</li>
            <li>Many cosmetic studies are small, short, industry-funded, or in-vitro only; we label these explicitly.</li>
            <li>Absence of a relationship here means absence from our curated dataset, not absence from science.</li>
            <li>Database identifiers carry the date they were last verified; anything past the re-check window is flagged, not hidden.</li>
            <li>Nothing here accounts for formulation, concentration, pH, stability or individual biology.</li>
          </ul>
        </GlassPanel>
      </section>
    </PageShell>
  );
}
