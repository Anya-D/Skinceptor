import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { SearchBar } from "@/components/SearchBar";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { ingredients } from "@/data/ingredients";
import { studiesForIngredient } from "@/data/studies";
import { replicationFlag } from "@/lib/evidence";
import { ReplicationBadge } from "@/components/EvidenceFlags";
import { topics } from "@/data/topics";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/explore")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Explore beauty biology — Skinceptor" },
      {
        name: "description",
        content:
          "Browse curated cosmetic ingredients by class, plus biology maps for the skin barrier, photoaging, pigmentation, hair cycling and oxidative stress.",
      },
      { property: "og:title", content: "Explore beauty biology — Skinceptor" },
      { property: "og:description", content: "Curated ingredients, genes, pathways and biology maps." },
    ],
  }),
  component: Explore,
});

function Explore() {
  const classes = [...new Set(ingredients.map((i) => i.className))].sort();
  const [active, setActive] = useState<string>("All");
  const shown = active === "All" ? ingredients : ingredients.filter((i) => i.className === active);

  return (
    <PageShell>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <Eyebrow>Explore</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light text-card-foreground md:text-5xl">
          A map of beauty biology
        </h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-foreground/60">
          {ingredients.length} curated ingredients and {topics.length} biology maps. Every relationship shown anywhere in
          Skinceptor is traceable to a public database record or a published study.
        </p>

        <div className="mt-8 max-w-2xl">
          <SearchBar showExamples={false} size="sm" />
        </div>

        <div className="mt-10 grid gap-4 lg:grid-cols-3">
          {topics.map((t) => (
            <Link key={t.slug} to="/topic/$slug" params={{ slug: t.slug }} className="group">
              <GlassPanel className="h-full p-5 transition-colors group-hover:border-accent/40">
                <Eyebrow tone="amber">Biology map</Eyebrow>
                <h2 className="mt-2 font-display text-xl text-card-foreground">{t.name}</h2>
                <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-foreground/60">{t.overview}</p>
                <p className="mt-3 font-mono text-[10px] uppercase tracking-wider text-foreground/40">
                  {t.genes.length} genes · {t.pathways.length} pathways · {t.ingredients.length} ingredients
                </p>
              </GlassPanel>
            </Link>
          ))}
        </div>

        <div className="mt-14">
          <div className="flex flex-wrap items-center gap-2">
            <Eyebrow tone="muted">Ingredients</Eyebrow>
            {["All", ...classes].map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setActive(c)}
                aria-pressed={active === c}
                className={cn(
                  "rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-wider transition-colors",
                  active === c ? "border-accent/50 bg-accent/15 text-accent" : "border-border text-foreground/55",
                )}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {shown.map((i) => (
              <Link key={i.slug} to="/ingredient/$slug" params={{ slug: i.slug }} className="group">
                <GlassPanel className="h-full p-4 transition-colors group-hover:border-accent/40">
                  <div className="flex items-baseline justify-between gap-2">
                    <h3 className="font-display text-lg text-card-foreground">{i.name}</h3>
                    <span className="font-mono text-[10px] uppercase tracking-wider text-foreground/40">
                      {i.className}
                    </span>
                  </div>
                  <p className="mt-1 font-mono text-[11px] text-foreground/45">
                    {i.formula ?? "Formula unavailable"}
                    {i.molecularWeight ? ` · ${i.molecularWeight} g/mol` : ""}
                  </p>
                  <p className="mt-2 line-clamp-3 text-xs leading-relaxed text-foreground/60">{i.summary}</p>
                  <div className="mt-3">
                    <ReplicationBadge flag={replicationFlag(studiesForIngredient(i.slug))} />
                  </div>
                  <p className="mt-2 font-mono text-[10px] uppercase tracking-wider text-foreground/35">
                    {i.targets.length} targets · {i.pathways.length} pathways
                  </p>
                </GlassPanel>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </PageShell>
  );
}
