import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { BiologyNetwork } from "@/components/BiologyNetwork";
import { ConfidenceBadge } from "@/components/ConfidenceBadge";
import { StudyCard } from "@/components/Research";
import { SaveToLibraryButton } from "@/components/AccountActions";
import { CommunityEvidence } from "@/components/CommunityEvidence";
import { SourceList } from "@/components/Provenance";
import { PlainEnglishProvider, PlainEnglishToggle, PlainText } from "@/components/PlainLanguage";
import { topicBySlug } from "@/data/topics";
import { ingredientBySlug } from "@/data/ingredients";
import { studiesForTopic } from "@/data/studies";
import { buildTopicGraph } from "@/lib/graph";
import { externalLink } from "@/lib/links";

export const Route = createFileRoute("/topic/$slug")({
  staticData: { sitemap: true },
  loader: ({ params }) => {
    const topic = topicBySlug.get(params.slug);
    if (!topic) throw notFound();
    return { name: topic.name, overview: topic.overview };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Topic unavailable — Skinceptor" }, { name: "robots", content: "noindex" }] };
    }
    const title = `${loaderData.name} — beauty biology map | Skinceptor`;
    return {
      meta: [
        { title },
        { name: "description", content: loaderData.overview.slice(0, 155) },
        { property: "og:title", content: title },
        { property: "og:description", content: loaderData.overview.slice(0, 155) },
      ],
    };
  },
  notFoundComponent: () => (
    <PageShell>
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <h1 className="font-display text-3xl text-card-foreground">No biological data found.</h1>
        <p className="mt-2 text-sm text-foreground/60">Try an ingredient, gene, pathway, or beauty topic.</p>
      </div>
    </PageShell>
  ),
  errorComponent: ({ error }) => (
    <PageShell>
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <h1 className="font-display text-3xl text-card-foreground">This page didn't load</h1>
        <p className="mt-2 text-sm text-foreground/60">{error.message}</p>
      </div>
    </PageShell>
  ),
  component: TopicPage,
});

function TopicPage() {
  const { slug } = Route.useParams();
  const topic = topicBySlug.get(slug)!;
  const graph = buildTopicGraph(topic);
  const studies = studiesForTopic(slug);

  return (
    <PageShell>
      <PlainEnglishProvider>
      <article className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <Eyebrow tone="amber">Beauty biology map</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light tracking-tight text-card-foreground md:text-6xl">
          {topic.name}
        </h1>
        <p className="mt-4 max-w-3xl text-[15px] leading-relaxed text-foreground/70">
          <PlainText>{topic.overview}</PlainText>
        </p>

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <PlainEnglishToggle />
          <SaveToLibraryButton itemType="topic" slug={topic.slug} />
        </div>

        <div className="mt-10">
          <BiologyNetwork graph={graph} caption={`${topic.name} biology network`} />
        </div>

        <div className="mt-10 grid gap-4 lg:grid-cols-3">
          <GlassPanel className="p-5">
            <Eyebrow as="h2">Genes & proteins</Eyebrow>
            <ul className="mt-4 space-y-2.5">
              {topic.genes.map((g) => (
                <li key={g.symbol} className="border-b border-border/60 pb-2 last:border-0">
                  <div className="flex items-center justify-between gap-2">
                    <a
                      href={g.uniprot ? externalLink.uniprot(g.uniprot) : externalLink.ncbiGene(g.ncbiGene ?? "")}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="font-mono text-xs text-accent underline underline-offset-4"
                    >
                      {g.symbol}
                    </a>
                    <ConfidenceBadge level={g.confidence} />
                  </div>
                  <p className="mt-0.5 text-xs text-foreground/55">{g.name}</p>
                </li>
              ))}
            </ul>
          </GlassPanel>

          <GlassPanel className="p-5">
            <Eyebrow as="h2" tone="brand">Pathways</Eyebrow>
            <ul className="mt-4 space-y-3">
              {topic.pathways.map((p) => (
                <li key={p.name} className="border-b border-border/60 pb-3 last:border-0">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm text-card-foreground">{p.name}</p>
                    <ConfidenceBadge level={p.confidence} />
                  </div>
                  <p className="mt-1 text-xs leading-relaxed text-foreground/55">
                    <PlainText>{p.summary}</PlainText>
                  </p>
                  <p className="mt-1 font-mono text-[10px] text-foreground/35">
                    {p.db}
                    {p.id ? ` ${p.id}` : ""}
                  </p>
                </li>
              ))}
            </ul>
          </GlassPanel>

          <GlassPanel className="p-5">
            <Eyebrow as="h2" tone="violet">Ingredients studied here</Eyebrow>
            <ul className="mt-4 flex flex-wrap gap-1.5">
              {topic.ingredients.map((s) => {
                const ing = ingredientBySlug.get(s);
                if (!ing) return null;
                return (
                  <li key={s}>
                    <Link
                      to="/ingredient/$slug"
                      params={{ slug: s }}
                      className="rounded-full border border-border bg-foreground/5 px-3 py-1 text-xs transition-colors hover:bg-foreground/10"
                    >
                      {ing.name}
                    </Link>
                  </li>
                );
              })}
            </ul>
            <p className="mt-5 font-mono text-[10px] uppercase tracking-wider text-foreground/40">Processes</p>
            <ul className="mt-2 space-y-1 text-xs text-foreground/60">
              {topic.processes.map((p) => (
                <li key={p.name}>
                  <PlainText>{`${p.name}${p.tissue ? ` — ${p.tissue}` : ""}`}</PlainText>
                </li>
              ))}
            </ul>
          </GlassPanel>
        </div>

        <section className="mt-12">
          <Eyebrow as="h2" tone="muted">Research on this topic</Eyebrow>
          {studies.length === 0 ? (
            <p className="mt-3 text-sm text-foreground/55">No curated studies mapped to this topic yet.</p>
          ) : (
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {studies.map((s) => (
                <StudyCard key={s.id} study={s} />
              ))}
            </div>
          )}
        </section>

        <div className="mt-10">
          <CommunityEvidence topicSlug={topic.slug} />
        </div>

        <GlassPanel className="mt-10 p-5">
          <Eyebrow as="h2" tone="muted">Sources</Eyebrow>
          <SourceList sources={topic.sources} />
        </GlassPanel>
      </article>
      </PlainEnglishProvider>
    </PageShell>
  );
}
