import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { PageShell } from "@/components/SiteChrome";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { ReplicationBadge } from "@/components/EvidenceFlags";
import { SaveSearchButton } from "@/components/AccountActions";
import { ingredients } from "@/data/ingredients";
import { studiesForIngredient } from "@/data/studies";
import { computeEvidence, replicationFlag } from "@/lib/evidence";
import type { Ingredient } from "@/data/types";

/** Keeps the last-analysed list around when navigating away and back. */
const LIST_STORAGE_KEY = "skinceptor:ingredient-checker:list";
const RAW_STORAGE_KEY = "skinceptor:ingredient-checker:raw";

export const Route = createFileRoute("/ingredient-checker")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Skincare Ingredient Checker — map an INCI list to biology | Skinceptor" },
      {
        name: "description",
        content:
          "Paste a skincare ingredient list (INCI) and see which ingredients are biologically characterised, what pathways and processes they act on, and how much curated evidence exists.",
      },
      { property: "og:title", content: "Skincare Ingredient Checker — Skinceptor" },
      {
        property: "og:description",
        content:
          "Paste a product's ingredient list and see the biology and published evidence behind each recognised ingredient.",
      },
      { property: "og:url", content: "https://skinceptor.tech/ingredient-checker" },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: "https://skinceptor.tech/ingredient-checker" }],
  }),
  component: IngredientChecker,
});

const EXAMPLE = `Aqua, Glycerin, Niacinamide, Butylene Glycol, Sodium Hyaluronate, Panthenol, Zinc PCA, Centella Asiatica Extract, Tocopherol, Phenoxyethanol`;

const normalise = (s: string) =>
  s
    .toLowerCase()
    .normalize("NFKD")
    .replace(/\(.*?\)/g, " ")
    .replace(/[^a-z0-9\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

/** Split a pasted INCI list on commas, semicolons, bullets or newlines. */
function splitList(raw: string): string[] {
  return raw
    .split(/[,;\n•·|]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

interface Row {
  raw: string;
  match: Ingredient | undefined;
}

function matchIngredient(term: string): Ingredient | undefined {
  const q = normalise(term);
  if (!q) return undefined;
  let best: { ing: Ingredient; score: number } | undefined;
  for (const ing of ingredients) {
    const candidates = [ing.name, ing.inci ?? "", ing.slug.replace(/-/g, " "), ...ing.aliases]
      .map(normalise)
      .filter(Boolean);
    for (const c of candidates) {
      let score = 0;
      if (c === q) score = 1;
      else if (q.includes(c) && c.length >= 5) score = 0.85;
      else if (c.includes(q) && q.length >= 5) score = 0.75;
      if (score > (best?.score ?? 0)) best = { ing, score };
    }
  }
  return best && best.score >= 0.75 ? best.ing : undefined;
}

function IngredientChecker() {
  const [raw, setRaw] = useState(() => {
    if (typeof window === "undefined") return "";
    return window.sessionStorage.getItem(RAW_STORAGE_KEY) ?? "";
  });
  const [submitted, setSubmitted] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    return window.sessionStorage.getItem(LIST_STORAGE_KEY) ?? null;
  });

  // Persist the analysed list so navigating to an ingredient and back keeps it.
  useEffect(() => {
    if (submitted) {
      window.sessionStorage.setItem(LIST_STORAGE_KEY, submitted);
      window.sessionStorage.setItem(RAW_STORAGE_KEY, raw);
    }
  }, [submitted, raw]);

  // Clear stored analysis when the user starts a new, empty list.
  useEffect(() => {
    if (!submitted && !raw) {
      window.sessionStorage.removeItem(LIST_STORAGE_KEY);
      window.sessionStorage.removeItem(RAW_STORAGE_KEY);
    }
  }, [submitted, raw]);

  const rows = useMemo<Row[]>(() => {
    if (!submitted) return [];
    const seen = new Set<string>();
    return splitList(submitted)
      .filter((t) => {
        const key = normalise(t);
        if (!key || seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .map((t) => ({ raw: t, match: matchIngredient(t) }));
  }, [submitted]);

  const matched = rows.filter((r) => r.match).map((r) => r.match!);
  const unmatched = rows.filter((r) => !r.match);

  const processCounts = new Map<string, number>();
  const pathwayCounts = new Map<string, number>();
  for (const ing of matched) {
    for (const p of ing.processes) processCounts.set(p.name, (processCounts.get(p.name) ?? 0) + 1);
    for (const p of ing.pathways) pathwayCounts.set(p.name, (pathwayCounts.get(p.name) ?? 0) + 1);
  }
  const topProcesses = [...processCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
  const topPathways = [...pathwayCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);

  return (
    <PageShell>
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <Eyebrow tone="brand">Ingredient list analysis</Eyebrow>
        <h1 className="mt-3 font-display text-4xl font-light tracking-tight text-card-foreground md:text-6xl">
          Skincare Ingredient Checker
        </h1>
        <p className="mt-4 max-w-3xl text-[15px] leading-relaxed text-foreground/70">
          Paste the ingredient list (INCI) from a product label. Skinceptor matches each entry against its curated
          dataset and shows the biological targets, pathways and published evidence behind the ones it recognises — and
          says plainly where it has nothing. This is educational biology, not a safety, quality or suitability rating.
        </p>

        <GlassPanel className="mt-8 p-5">
          <label htmlFor="inci" className="font-mono text-[11px] uppercase tracking-[0.18em] text-accent">
            Ingredient list
          </label>
          <textarea
            id="inci"
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
            rows={5}
            placeholder="Aqua, Glycerin, Niacinamide, …"
            className="mt-3 w-full resize-y rounded-xl border border-border bg-foreground/5 px-4 py-3 text-sm text-card-foreground outline-none placeholder:text-foreground/35 focus:border-accent/60"
          />
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setSubmitted(raw)}
              className="min-h-11 rounded-lg border border-accent/40 bg-accent/10 px-4 font-mono text-[11px] uppercase tracking-wider text-accent transition-colors hover:bg-accent/20"
            >
              Analyse list
            </button>
            <button
              type="button"
              onClick={() => {
                setRaw(EXAMPLE);
                setSubmitted(EXAMPLE);
              }}
              className="min-h-11 rounded-lg border border-border px-4 font-mono text-[11px] uppercase tracking-wider text-foreground/60 transition-colors hover:bg-foreground/5"
            >
              Try an example
            </button>
            {submitted ? <SaveSearchButton query={submitted} label="Ingredient list" kind="search" /> : null}
          </div>
        </GlassPanel>

        {submitted && rows.length === 0 ? (
          <p className="mt-8 text-sm text-foreground/55">
            No ingredient entries were detected. Separate ingredients with commas or new lines.
          </p>
        ) : null}

        {rows.length > 0 ? (
          <>
            <section className="mt-12">
              <Eyebrow as="h2" tone="brand">
                Recognised ingredients
              </Eyebrow>
              <p className="mt-2 font-mono text-xs text-foreground/45">
                {matched.length} of {rows.length} entries are in the curated dataset
              </p>
              {matched.length === 0 ? (
                <p className="mt-4 text-sm text-foreground/55">
                  None of these entries are in the curated dataset yet — that means they are not characterised here, not
                  that they are inactive or unsafe.
                </p>
              ) : (
                <div className="mt-4 grid gap-3 md:grid-cols-2">
                  {matched.map((ing) => {
                    const evidence = computeEvidence(studiesForIngredient(ing.slug));
                    const flag = replicationFlag(studiesForIngredient(ing.slug));
                    return (
                      <GlassPanel key={ing.slug} className="p-5">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <Link
                              to="/ingredient/$slug"
                              params={{ slug: ing.slug }}
                              className="font-display text-xl text-card-foreground underline-offset-4 hover:underline"
                            >
                              {ing.name}
                            </Link>
                            <p className="mt-0.5 font-mono text-[10px] uppercase tracking-wider text-foreground/40">
                              {ing.className}
                              {ing.inci ? ` · ${ing.inci}` : ""}
                            </p>
                          </div>
                          <span className="shrink-0 font-mono text-[10px] text-foreground/50">
                            Index {evidence.index} · {evidence.strength}
                          </span>
                        </div>
                        <p className="mt-3 text-sm leading-relaxed text-foreground/65">{ing.summary}</p>
                        <div className="mt-3">
                          <ReplicationBadge flag={flag} />
                        </div>
                        {ing.processes.length ? (
                          <p className="mt-3 text-xs leading-relaxed text-foreground/55">
                            <span className="font-mono text-[10px] uppercase tracking-wider text-foreground/40">
                              Processes ·{" "}
                            </span>
                            {ing.processes.map((p) => p.name).join(", ")}
                          </p>
                        ) : null}
                      </GlassPanel>
                    );
                  })}
                </div>
              )}
            </section>

            {matched.length > 1 ? (
              <section className="mt-12 grid gap-4 md:grid-cols-2">
                <GlassPanel className="p-5">
                  <Eyebrow as="h2" tone="amber">
                    Where this formula concentrates
                  </Eyebrow>
                  <ul className="mt-4 space-y-1.5 text-sm text-foreground/70">
                    {topProcesses.map(([name, n]) => (
                      <li key={name} className="flex items-baseline justify-between gap-3">
                        {name}
                        <span className="font-mono text-[10px] text-foreground/40">{n} ingredient{n > 1 ? "s" : ""}</span>
                      </li>
                    ))}
                  </ul>
                </GlassPanel>
                <GlassPanel className="p-5">
                  <Eyebrow as="h2" tone="violet">
                    Pathways touched
                  </Eyebrow>
                  <ul className="mt-4 space-y-1.5 text-sm text-foreground/70">
                    {topPathways.map(([name, n]) => (
                      <li key={name} className="flex items-baseline justify-between gap-3">
                        {name}
                        <span className="font-mono text-[10px] text-foreground/40">{n}</span>
                      </li>
                    ))}
                  </ul>
                </GlassPanel>
              </section>
            ) : null}

            <section className="mt-12">
              <Eyebrow as="h2" tone="muted">
                Not in the dataset
              </Eyebrow>
              {unmatched.length === 0 ? (
                <p className="mt-3 text-sm text-foreground/55">Every entry was recognised.</p>
              ) : (
                <>
                  <p className="mt-2 max-w-3xl text-sm leading-relaxed text-foreground/60">
                    These entries are not curated here. Many are solvents, preservatives, texture agents or fragrance
                    components; absence is a gap in this dataset, not a judgement about the ingredient.
                  </p>
                  <ul className="mt-4 flex flex-wrap gap-1.5">
                    {unmatched.map((r) => (
                      <li
                        key={r.raw}
                        className="rounded-full border border-border bg-foreground/5 px-3 py-1 text-xs text-foreground/60"
                      >
                        {r.raw}
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </section>
          </>
        ) : null}

        <GlassPanel className="mt-12 p-5">
          <Eyebrow as="h2" tone="rose">
            What this is not
          </Eyebrow>
          <p className="mt-3 max-w-3xl text-sm leading-relaxed text-foreground/65">
            This checker does not rate products, judge safety, flag irritants or allergens, or account for
            concentration, formulation or order on the label — none of which an ingredient list alone reveals. It maps
            named ingredients to published biology so you can read the mechanism for yourself. It is not medical advice,
            diagnosis or treatment.{" "}
            <Link to="/methodology" className="text-accent underline underline-offset-4">
              How evidence is scored →
            </Link>
          </p>
        </GlassPanel>
      </div>
    </PageShell>
  );
}
