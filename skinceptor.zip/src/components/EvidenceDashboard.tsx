import { Link } from "@tanstack/react-router";
import type { Study, StudyType } from "@/data/types";
import { STUDY_TYPE_LABEL, computeEvidence, strengthCopy } from "@/lib/evidence";
import { Eyebrow, GlassPanel } from "./GlassPanel";

const BAR_TONE: Record<StudyType, string> = {
  rct: "bg-accent",
  human: "bg-gradient-to-r from-brand to-accent",
  "meta-analysis": "bg-amber",
  "in-vitro": "bg-violet",
  animal: "bg-rose",
  review: "bg-foreground/40",
};

export function EvidenceDashboard({ studies }: { studies: Study[] }) {
  const report = computeEvidence(studies);
  const maxCount = Math.max(1, ...Object.values(report.counts));

  return (
    <GlassPanel className="p-5 sm:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <Eyebrow tone="brand">Evidence engine</Eyebrow>
          <p className="mt-2 font-display text-3xl text-card-foreground">{report.strength}</p>
          <p className="mt-1 max-w-md text-sm text-foreground/60">{strengthCopy[report.strength]}</p>
        </div>
        <div className="text-right">
          <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-foreground/45">
            Skinceptor Evidence Index
          </p>
          <p className="font-display text-4xl text-accent">{report.index}</p>
          <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-foreground/40">experimental · of 100</p>
        </div>
      </div>

      <p className="mt-4 rounded-xl border border-amber/25 bg-amber/8 px-4 py-3 text-xs leading-relaxed text-amber">
        This index is a research-navigation aid describing how much evidence exists and how it was produced. It is not a
        medical safety score, an efficacy guarantee, or a clinical recommendation.
      </p>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-foreground/40">Study composition</p>
          <ul className="mt-3 space-y-2.5">
            {(Object.keys(report.counts) as StudyType[])
              .filter((k) => report.counts[k] > 0)
              .map((k) => (
                <li key={k}>
                  <div className="mb-1 flex justify-between text-xs text-foreground/60">
                    <span>{STUDY_TYPE_LABEL[k]}</span>
                    <span className="font-mono">{report.counts[k]}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-foreground/10">
                    <div
                      className={`h-full rounded-full ${BAR_TONE[k]}`}
                      style={{ width: `${(report.counts[k] / maxCount) * 100}%` }}
                    />
                  </div>
                </li>
              ))}
            {report.total === 0 && <li className="text-sm text-foreground/55">No curated studies yet.</li>}
          </ul>
          <dl className="mt-4 grid grid-cols-2 gap-3 font-mono text-[11px] text-foreground/55">
            <div>
              <dt>Total studies</dt>
              <dd className="text-card-foreground">{report.total}</dd>
            </div>
            <div>
              <dt>Human studies</dt>
              <dd className="text-card-foreground">{report.humanCount}</dd>
            </div>
            <div>
              <dt>Largest sample</dt>
              <dd className="text-card-foreground">{report.largestSample ?? "Data unavailable"}</dd>
            </div>
            <div>
              <dt>Range</dt>
              <dd className="text-card-foreground">
                {report.oldestYear ? `${report.oldestYear}–${report.newestYear}` : "Data unavailable"}
              </dd>
            </div>
          </dl>
        </div>

        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-foreground/40">Index breakdown</p>
          <ul className="mt-3 space-y-2.5">
            {report.components.map((c) => (
              <li key={c.key}>
                <div className="mb-1 flex justify-between text-xs text-foreground/60">
                  <span>{c.label}</span>
                  <span className="font-mono">
                    {Math.round(c.value * 100)}% × {Math.round(c.weight * 100)}%
                  </span>
                </div>
                <div className="h-1.5 rounded-full bg-foreground/10">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-brand to-accent"
                    style={{ width: `${c.value * 100}%` }}
                  />
                </div>
                <p className="mt-1 text-[11px] leading-relaxed text-foreground/40">{c.explanation}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-4">
        <Link to="/methodology" className="text-xs text-accent underline underline-offset-4 hover:text-card-foreground">
          How is this determined? →
        </Link>
        <p className="text-xs text-foreground/45">
          {report.quantitativeSynthesisPossible
            ? "Enough comparable human studies exist to attempt quantitative synthesis in a future release."
            : "Insufficient comparable evidence for quantitative synthesis."}
        </p>
      </div>
    </GlassPanel>
  );
}
