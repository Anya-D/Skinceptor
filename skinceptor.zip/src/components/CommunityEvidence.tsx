import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Eyebrow, GlassPanel } from "@/components/GlassPanel";
import { listApprovedEvidence } from "@/lib/account.functions";

export function CommunityEvidence({
  ingredientSlug,
  topicSlug,
}: {
  ingredientSlug?: string;
  topicSlug?: string;
}) {
  const fetchApproved = useServerFn(listApprovedEvidence);
  const { data } = useQuery({
    queryKey: ["approved-evidence", ingredientSlug ?? null, topicSlug ?? null],
    queryFn: () =>
      fetchApproved({
        data: {
          ...(ingredientSlug ? { ingredientSlug } : {}),
          ...(topicSlug ? { topicSlug } : {}),
        },
      }),
  });

  const rows = data ?? [];

  return (
    <GlassPanel className="p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Eyebrow tone="violet">Community evidence</Eyebrow>
          <h2 className="mt-2 font-display text-2xl text-card-foreground">Submitted by readers</h2>
        </div>
        <Link
          to="/submit-evidence"
          search={{ ingredient: ingredientSlug ?? "", topic: topicSlug ?? "" }}
          className="rounded-full border border-border px-3 py-1.5 text-xs text-foreground/70 transition-colors hover:text-card-foreground"
        >
          Submit a study
        </Link>
      </div>

      <p className="mt-3 text-xs leading-relaxed text-foreground/50">
        Reader submissions appear here only after review. They are not part of the curated dataset and do not affect the
        Skinceptor Evidence Index.
      </p>

      {rows.length === 0 ? (
        <p className="mt-4 text-sm text-foreground/55">No approved community submissions yet.</p>
      ) : (
        <ul className="mt-4 space-y-3">
          {rows.map((r) => (
            <li key={r.id} className="rounded-xl border border-border bg-ink-2/40 p-4">
              <p className="text-sm text-card-foreground">{r.title}</p>
              <p className="mt-1 font-mono text-[11px] uppercase tracking-wider text-foreground/45">
                {[r.journal, r.year, r.study_type, r.sample_size ? `n=${r.sample_size}` : null]
                  .filter(Boolean)
                  .join(" · ") || "Details unavailable"}
              </p>
              <p className="mt-2 text-sm leading-relaxed text-foreground/70">{r.summary}</p>
              {r.limitations && (
                <p className="mt-2 text-xs leading-relaxed text-amber/80">Limitations: {r.limitations}</p>
              )}
              <div className="mt-2 flex flex-wrap gap-3 text-xs text-foreground/50">
                {r.pmid && (
                  <a
                    href={`https://pubmed.ncbi.nlm.nih.gov/${r.pmid}/`}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="hover:text-card-foreground"
                  >
                    PMID {r.pmid}
                  </a>
                )}
                {r.doi && (
                  <a
                    href={`https://doi.org/${r.doi}`}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="hover:text-card-foreground"
                  >
                    DOI {r.doi}
                  </a>
                )}
                {r.url && (
                  <a href={r.url} target="_blank" rel="noreferrer noopener" className="hover:text-card-foreground">
                    Source link
                  </a>
                )}
                {r.submitter_label && <span>Submitted by {r.submitter_label}</span>}
              </div>
            </li>
          ))}
        </ul>
      )}
    </GlassPanel>
  );
}
