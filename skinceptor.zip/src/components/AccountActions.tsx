import { Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { listLibrary, toggleLibraryItem, saveSearch } from "@/lib/account.functions";

const chip =
  "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs transition-colors disabled:opacity-50";

/** Save / remove an ingredient or biology map from the signed-in user's library. */
export function SaveToLibraryButton({
  itemType,
  slug,
}: {
  itemType: "ingredient" | "topic";
  slug: string;
}) {
  const { signedIn, loading } = useAuth();
  const qc = useQueryClient();
  const fetchLibrary = useServerFn(listLibrary);
  const toggle = useServerFn(toggleLibraryItem);

  const { data: items } = useQuery({
    queryKey: ["library"],
    queryFn: () => fetchLibrary(),
    enabled: signedIn,
  });

  const mutation = useMutation({
    mutationFn: () => toggle({ data: { itemType, slug } }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["library"] }),
  });

  if (loading) return null;
  if (!signedIn) {
    return (
      <Link to="/auth" className={`${chip} border-border text-foreground/60 hover:text-card-foreground`}>
        Sign in to save
      </Link>
    );
  }

  const saved = (items ?? []).some((i) => i.item_type === itemType && i.slug === slug);

  return (
    <button
      type="button"
      onClick={() => mutation.mutate()}
      disabled={mutation.isPending}
      aria-pressed={saved}
      className={
        saved
          ? `${chip} border-accent/40 bg-accent/15 text-accent`
          : `${chip} border-border text-foreground/70 hover:text-card-foreground`
      }
    >
      {saved ? "Saved to library" : "Save to library"}
    </button>
  );
}

/** Save the current query (or claim) to the signed-in user's saved searches. */
export function SaveSearchButton({
  query,
  label,
  kind = "search",
}: {
  query: string;
  label?: string;
  kind?: "search" | "claim";
}) {
  const { signedIn, loading } = useAuth();
  const qc = useQueryClient();
  const save = useServerFn(saveSearch);
  const [done, setDone] = useState(false);

  const mutation = useMutation({
    mutationFn: () => save({ data: { query, label: label ?? null, kind } }),
    onSuccess: () => {
      setDone(true);
      void qc.invalidateQueries({ queryKey: ["saved-searches"] });
    },
  });

  if (loading) return null;
  if (!signedIn) {
    return (
      <Link to="/auth" className={`${chip} border-border text-foreground/60 hover:text-card-foreground`}>
        Sign in to save {kind === "claim" ? "this claim" : "this search"}
      </Link>
    );
  }

  return (
    <button
      type="button"
      onClick={() => mutation.mutate()}
      disabled={mutation.isPending || !query.trim()}
      className={`${chip} border-border text-foreground/70 hover:text-card-foreground`}
    >
      {mutation.isPending ? "Saving…" : done ? "Saved" : kind === "claim" ? "Save this claim" : "Save this search"}
    </button>
  );
}
