import { useEffect, useMemo, useRef, useState } from "react";
import type { BiologyGraph, Confidence, GraphNode, NodeKind } from "@/data/types";
import { NODE_COLOR_VAR, TIER_LABELS, connectedTo, filterGraph, layoutGraph } from "@/lib/graph";
import { useIsMobile } from "@/hooks/use-mobile";
import { ConfidenceBadge } from "./ConfidenceBadge";
import { cn } from "@/lib/utils";

/**
 * Small-screen view of the same graph: one collapsible band per tier, in
 * biological order, with each node's outgoing relationships written out. No
 * panning or zooming required, and nothing is hidden that the graph would show.
 */
function TieredView({
  graph,
  onSelect,
  selectedId,
}: {
  graph: BiologyGraph;
  onSelect: (n: GraphNode) => void;
  selectedId?: string | undefined;
}) {
  const tiers = [...new Set(graph.nodes.map((n) => n.tier))].sort((a, b) => a - b);
  const labelFor = (id: string) => graph.nodes.find((n) => n.id === id)?.label ?? id;

  return (
    <div className="space-y-2">
      {tiers.map((tier) => {
        const nodes = graph.nodes.filter((n) => n.tier === tier);
        return (
          <details key={tier} open={tier <= 2} className="rounded-2xl border border-border bg-ink-2/40">
            <summary className="flex cursor-pointer items-center justify-between gap-2 px-4 py-3">
              <span
                className="font-mono text-[10px] uppercase tracking-[0.16em]"
                style={{ color: NODE_COLOR_VAR[nodes[0]?.kind ?? "outcome"] }}
              >
                {TIER_LABELS[tier] ?? `Tier ${tier}`}
              </span>
              <span className="font-mono text-[10px] text-foreground/40">{nodes.length}</span>
            </summary>
            <ul className="space-y-1.5 px-3 pb-3">
              {nodes.map((n) => {
                const rels = graph.edges.filter((e) => e.source === n.id);
                return (
                  <li key={n.id}>
                    <button
                      type="button"
                      onClick={() => onSelect(n)}
                      className={cn(
                        "w-full rounded-xl border px-3 py-2 text-left transition-colors",
                        selectedId === n.id ? "border-accent/50 bg-accent/10" : "border-border/70 bg-foreground/5",
                      )}
                    >
                      <span className="flex flex-wrap items-center gap-2">
                        <span className="text-sm text-card-foreground">{n.label}</span>
                        <ConfidenceBadge level={n.confidence} />
                      </span>
                      {rels.length > 0 && (
                        <span className="mt-1 block text-[11px] leading-relaxed text-foreground/50">
                          {rels
                            .slice(0, 4)
                            .map((e) => `${e.relation} ${labelFor(e.target)}`)
                            .join(" · ")}
                          {rels.length > 4 ? ` · +${rels.length - 4} more` : ""}
                        </span>
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          </details>
        );
      })}
    </div>
  );
}

const KIND_LABEL: Record<NodeKind, string> = {
  ingredient: "Ingredient",
  molecule: "Molecule",
  target: "Target",
  gene: "Gene",
  protein: "Protein",
  pathway: "Pathway",
  process: "Process",
  outcome: "Outcome",
};

const LEGEND: NodeKind[] = ["ingredient", "molecule", "target", "gene", "pathway", "process", "outcome"];

export function BiologyNetwork({
  graph,
  caption,
  className,
}: {
  graph: BiologyGraph;
  caption?: string;
  className?: string;
}) {
  const [minConfidence, setMinConfidence] = useState<Confidence>("MEDIUM");
  const [selected, setSelected] = useState<GraphNode | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const drag = useRef<{ x: number; y: number; panX: number; panY: number } | null>(null);
  const isMobile = useIsMobile();
  const [mode, setMode] = useState<"graph" | "tiers">("graph");
  const [modeTouched, setModeTouched] = useState(false);
  // Small screens open in the simplified tiered view unless the reader changes it.
  useEffect(() => {
    if (!modeTouched) setMode(isMobile ? "tiers" : "graph");
  }, [isMobile, modeTouched]);

  const filtered = useMemo(() => filterGraph(graph, minConfidence), [graph, minConfidence]);
  const layout = useMemo(() => layoutGraph(filtered), [filtered]);
  const isolated = useMemo(
    () => (hovered ? connectedTo(filtered, hovered) : null),
    [filtered, hovered],
  );

  const nodeById = useMemo(() => new Map(layout.nodes.map((n) => [n.id, n])), [layout]);
  const hiddenCount = graph.nodes.length - filtered.nodes.length;

  const dim = (nodeId: string) => (isolated ? !isolated.has(nodeId) : false);

  return (
    <div className={cn("bb-glass rounded-3xl p-3 sm:p-4", className)}>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {(["HIGH", "MEDIUM", "LOW"] as Confidence[]).map((level) => (
            <button
              key={level}
              type="button"
              onClick={() => setMinConfidence(level)}
              aria-pressed={minConfidence === level}
              className={cn(
                "rounded-full border px-3 py-1 font-mono text-[10px] uppercase tracking-[0.12em] transition-colors",
                minConfidence === level
                  ? "border-accent/50 bg-accent/15 text-accent"
                  : "border-border text-foreground/55 hover:text-card-foreground",
              )}
            >
              {level === "HIGH" ? "High only" : level === "MEDIUM" ? "Medium +" : "Show more biology"}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          <div className="mr-1 flex rounded-full border border-border p-0.5">
            {(["tiers", "graph"] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  setModeTouched(true);
                  setMode(m);
                }}
                aria-pressed={mode === m}
                className={cn(
                  "rounded-full px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider transition-colors",
                  mode === m ? "bg-accent/15 text-accent" : "text-foreground/50 hover:text-card-foreground",
                )}
              >
                {m === "tiers" ? "Simple" : "Graph"}
              </button>
            ))}
          </div>
          {mode === "graph" && (
          <>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.15).toFixed(2)))}
            className="size-7 rounded-lg border border-border font-mono text-xs text-foreground/70 hover:text-card-foreground"
            aria-label="Zoom out"
          >
            −
          </button>
          <span className="w-10 text-center font-mono text-[10px] text-foreground/50">{Math.round(zoom * 100)}%</span>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(2.2, +(z + 0.15).toFixed(2)))}
            className="size-7 rounded-lg border border-border font-mono text-xs text-foreground/70 hover:text-card-foreground"
            aria-label="Zoom in"
          >
            +
          </button>
          <button
            type="button"
            onClick={() => {
              setZoom(1);
              setPan({ x: 0, y: 0 });
            }}
            className="rounded-lg border border-border px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-foreground/60 hover:text-card-foreground"
          >
            Reset
          </button>
          </>
          )}
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-3">
        <div className="lg:col-span-2">
        {mode === "tiers" && (
          <>
            <TieredView graph={filtered} onSelect={setSelected} selectedId={selected?.id} />
            <p className="mt-3 text-xs leading-relaxed text-foreground/45">
              Simplified view: the same curated relationships, grouped from ingredient through to outcome. Switch to
              “Graph” for the connected network.
            </p>
          </>
        )}
        {mode === "graph" && (
          <div>
          <div
            className="relative overflow-hidden rounded-2xl border border-border bg-ink-2/60"
            onPointerDown={(e) => {
              drag.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y };
              (e.target as Element).setPointerCapture?.(e.pointerId);
            }}
            onPointerMove={(e) => {
              if (!drag.current) return;
              setPan({
                x: drag.current.panX + (e.clientX - drag.current.x),
                y: drag.current.panY + (e.clientY - drag.current.y),
              });
            }}
            onPointerUp={() => {
              drag.current = null;
            }}
            onPointerLeave={() => {
              drag.current = null;
            }}
          >
            <div className="bb-dots absolute inset-0 opacity-40" aria-hidden="true" />
            <svg
              viewBox={`0 0 ${layout.width} ${layout.height}`}
              className="relative h-[360px] w-full touch-none sm:h-[440px]"
              role="img"
              aria-label={
                caption ??
                `Biological network with ${filtered.nodes.length} entities and ${filtered.edges.length} relationships`
              }
            >
              <g transform={`translate(${pan.x} ${pan.y}) scale(${zoom})`}>
                {layout.edges.map((e) => {
                  const a = nodeById.get(e.source);
                  const b = nodeById.get(e.target);
                  if (!a || !b) return null;
                  const faded = dim(e.source) || dim(e.target);
                  const mx = (a.x + b.x) / 2;
                  return (
                    <g key={e.id} opacity={faded ? 0.12 : 1}>
                      <path
                        d={`M${a.x},${a.y} C${mx},${a.y} ${mx},${b.y} ${b.x},${b.y}`}
                        fill="none"
                        stroke={NODE_COLOR_VAR[b.kind]}
                        strokeOpacity={e.confidence === "HIGH" ? 0.55 : e.confidence === "MEDIUM" ? 0.34 : 0.18}
                        strokeWidth={e.confidence === "HIGH" ? 1.4 : 1}
                        strokeDasharray={e.confidence === "LOW" ? "3 4" : undefined}
                      />
                      {(hovered === e.source || hovered === e.target) && (
                        <text
                          x={mx}
                          y={(a.y + b.y) / 2 - 6}
                          textAnchor="middle"
                          className="fill-current text-foreground/70"
                          style={{ font: "400 9px var(--font-mono)" }}
                        >
                          {e.relation}
                        </text>
                      )}
                    </g>
                  );
                })}

                {layout.nodes.map((n) => {
                  const faded = dim(n.id);
                  const isSelected = selected?.id === n.id;
                  return (
                    <g
                      key={n.id}
                      opacity={faded ? 0.18 : 1}
                      tabIndex={0}
                      role="button"
                      aria-label={`${KIND_LABEL[n.kind]}: ${n.label}, ${n.confidence.toLowerCase()} confidence`}
                      onMouseEnter={() => setHovered(n.id)}
                      onMouseLeave={() => setHovered(null)}
                      onFocus={() => setHovered(n.id)}
                      onBlur={() => setHovered(null)}
                      onClick={() => setSelected(n)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          setSelected(n);
                        }
                      }}
                      className="cursor-pointer outline-none"
                    >
                      <rect
                        x={n.x - 6}
                        y={n.y - 12}
                        rx={11}
                        width={Math.min(190, 22 + n.label.length * 6.1)}
                        height={24}
                        fill={NODE_COLOR_VAR[n.kind]}
                        fillOpacity={isSelected ? 0.32 : 0.14}
                        stroke={NODE_COLOR_VAR[n.kind]}
                        strokeOpacity={isSelected ? 0.85 : 0.35}
                      />
                      <text
                        x={n.x + 5}
                        y={n.y + 4}
                        style={{ font: "500 10px var(--font-mono)", fill: NODE_COLOR_VAR[n.kind] }}
                      >
                        {n.label.length > 26 ? `${n.label.slice(0, 25)}…` : n.label}
                      </text>
                    </g>
                  );
                })}
              </g>
            </svg>
            <p className="pointer-events-none absolute bottom-2 left-3 font-mono text-[10px] uppercase tracking-wider text-foreground/35">
              drag to pan · hover to isolate a path · click a node for detail
            </p>
          </div>

          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5 font-mono text-[10px] uppercase tracking-[0.12em] text-foreground/50">
            {LEGEND.map((kind) => (
              <span key={kind} className="flex items-center gap-1.5">
                <span className="size-2 rounded-full" style={{ background: NODE_COLOR_VAR[kind] }} aria-hidden="true" />
                {KIND_LABEL[kind]}
              </span>
            ))}
          </div>
          {hiddenCount > 0 && (
            <p className="mt-2 text-xs text-foreground/45">
              {hiddenCount} lower-confidence {hiddenCount === 1 ? "relationship is" : "relationships are"} hidden at this
              filter level. Use “Show more biology” to include them.
            </p>
          )}
          </div>
        )}
        </div>

        <aside className="rounded-2xl border border-border bg-ink-2/40 p-4" aria-live="polite">
          {selected ? (
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.18em]" style={{ color: NODE_COLOR_VAR[selected.kind] }}>
                {KIND_LABEL[selected.kind]}
              </p>
              <h3 className="mt-1.5 font-display text-xl leading-snug text-card-foreground">{selected.label}</h3>
              <div className="mt-2">
                <ConfidenceBadge level={selected.confidence} />
              </div>
              {selected.detail && <p className="mt-3 text-sm leading-relaxed text-foreground/70">{selected.detail}</p>}
              {selected.externalId && (
                <p className="mt-3 font-mono text-[11px] text-foreground/50">{selected.externalId}</p>
              )}
              {selected.href && (
                <a
                  href={selected.href}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="mt-3 inline-block text-xs text-accent underline underline-offset-4 hover:text-card-foreground"
                >
                  Open source record →
                </a>
              )}
              <div className="mt-4">
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-foreground/40">Relationships</p>
                <ul className="mt-2 space-y-1.5 text-xs text-foreground/65">
                  {filtered.edges
                    .filter((e) => e.source === selected.id || e.target === selected.id)
                    .slice(0, 8)
                    .map((e) => {
                      const other = e.source === selected.id ? e.target : e.source;
                      return (
                        <li key={e.id}>
                          <span className="font-mono text-foreground/45">{e.relation}</span>{" "}
                          {nodeById.get(other)?.label ?? other}
                        </li>
                      );
                    })}
                </ul>
              </div>
              <button
                type="button"
                onClick={() => setSelected(null)}
                className="mt-4 rounded-lg border border-border px-3 py-1.5 font-mono text-[10px] uppercase tracking-wider text-foreground/60 hover:text-card-foreground"
              >
                Close
              </button>
            </div>
          ) : (
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-accent">Node detail</p>
              <p className="mt-2 text-sm leading-relaxed text-foreground/65">
                Select any node to see its category, confidence tier, curated description and source record.
              </p>
              <dl className="mt-4 space-y-2 font-mono text-[11px] text-foreground/55">
                <div className="flex justify-between">
                  <dt>Entities shown</dt>
                  <dd className="text-card-foreground">{filtered.nodes.length}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>Relationships</dt>
                  <dd className="text-card-foreground">{filtered.edges.length}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>Confidence floor</dt>
                  <dd className="text-card-foreground">{minConfidence}</dd>
                </div>
              </dl>
            </div>
          )}
        </aside>
      </div>

      <details className="mt-3 rounded-xl border border-border px-4 py-3">
        <summary className="cursor-pointer font-mono text-[10px] uppercase tracking-[0.16em] text-foreground/50">
          Text alternative for this network
        </summary>
        <ul className="mt-3 space-y-1 text-xs leading-relaxed text-foreground/65">
          {filtered.edges.map((e) => (
            <li key={e.id}>
              {nodeById.get(e.source)?.label} <span className="text-foreground/40">{e.relation}</span>{" "}
              {nodeById.get(e.target)?.label} — {e.confidence.toLowerCase()} confidence
            </li>
          ))}
        </ul>
      </details>
    </div>
  );
}
