import { Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import { groupResults, isAmbiguous, search, suggestions } from "@/lib/search";
import { ingredientBySlug } from "@/data/ingredients";
import { cn } from "@/lib/utils";

const EXAMPLES = [
  "Niacinamide",
  "Retinol",
  "Hyaluronic acid",
  "Ceramide NP",
  "Melanin",
  "Skin barrier",
  "Collagen",
  "Peptides",
];

export function SearchBar({
  autoFocus = false,
  showExamples = true,
  size = "lg",
}: {
  autoFocus?: boolean;
  showExamples?: boolean;
  size?: "lg" | "sm";
}) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const navigate = useNavigate();
  const listId = "search-results";
  const inputRef = useRef<HTMLInputElement>(null);

  const results = useMemo(() => search(query), [query]);
  const grouped = useMemo(() => groupResults(results), [results]);
  const ambiguous = useMemo(() => (query ? isAmbiguous(query) : null), [query]);
  const ordered = useMemo(() => grouped.flatMap((g) => g.items), [grouped]);
  const hints = useMemo(() => (query && results.length === 0 ? suggestions(query) : []), [query, results.length]);
  const active = ordered[Math.min(activeIndex, ordered.length - 1)];

  const go = (result: (typeof results)[number]) => {
    setOpen(false);
    setQuery("");
    if (result.params) navigate({ to: result.to, params: result.params });
    else navigate({ to: result.to });
  };

  return (
    <div className="relative">
      <div
        className={cn(
          "bb-glass rounded-2xl",
          size === "lg" ? "p-2.5" : "p-1.5",
        )}
      >
        <form
          role="search"
          onSubmit={(e) => {
            e.preventDefault();
            if (active) go(active);
          }}
          className="flex items-center gap-3 px-3 py-2"
        >
          <span className="font-mono text-sm text-foreground/40" aria-hidden="true">
            ⌕
          </span>
          <label htmlFor="bb-search" className="sr-only">
            Search an ingredient, gene, pathway, or beauty topic
          </label>
          <input
            id="bb-search"
            ref={inputRef}
            autoFocus={autoFocus}
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setActiveIndex(0);
              setOpen(true);
            }}
            onFocus={() => setOpen(true)}
            onBlur={() => window.setTimeout(() => setOpen(false), 150)}
            onKeyDown={(e) => {
              if (e.key === "Escape") {
                setOpen(false);
                return;
              }
              if (e.key === "ArrowDown" && ordered.length) {
                e.preventDefault();
                setOpen(true);
                setActiveIndex((i) => (i + 1) % ordered.length);
              }
              if (e.key === "ArrowUp" && ordered.length) {
                e.preventDefault();
                setActiveIndex((i) => (i - 1 + ordered.length) % ordered.length);
              }
            }}
            aria-activedescendant={active ? `search-option-${ordered.indexOf(active)}` : undefined}
            role="combobox"
            aria-expanded={open && query.length > 0}
            aria-controls={listId}
            aria-autocomplete="list"
            placeholder="Search an ingredient, gene, pathway, or beauty topic…"
            className={cn(
              "flex-1 bg-transparent text-card-foreground placeholder:text-foreground/40 focus:outline-none",
              size === "lg" ? "text-[15px]" : "text-sm",
            )}
          />
          <button
            type="submit"
            className="rounded-full border border-border bg-foreground/10 px-3 py-1 font-mono text-[11px] uppercase tracking-[0.14em] transition-colors hover:bg-foreground/15"
          >
            Search
          </button>
        </form>

        {showExamples && (
          <div className="flex flex-wrap gap-1.5 px-2 pb-1 pt-2">
            <span className="mr-1 font-mono text-[11px] uppercase tracking-wider text-foreground/40">Try</span>
            {EXAMPLES.map((label) => (
              <button
                key={label}
                type="button"
                onClick={() => {
                  setQuery(label);
                  setOpen(true);
                  inputRef.current?.focus();
                }}
                className="rounded-full border border-border bg-foreground/5 px-3 py-1 text-xs transition-colors hover:bg-foreground/10"
              >
                {label}
              </button>
            ))}
          </div>
        )}
      </div>

      {open && query.length > 0 && (
        <div
          id={listId}
          role="listbox"
          aria-label="Search results"
          className="bb-glass absolute left-0 right-0 top-full z-30 mt-2 max-h-[60vh] overflow-auto rounded-2xl p-2"
        >
          {ambiguous && (
            <p className="mx-2 mb-2 rounded-lg border border-amber/30 bg-amber/10 px-3 py-2 text-xs text-amber">
              “{query}” is ambiguous. Did you mean{" "}
              {ambiguous.map((slug, i) => (
                <span key={slug}>
                  {i > 0 && " or "}
                  <Link to="/ingredient/$slug" params={{ slug }} className="underline">
                    {ingredientBySlug.get(slug)?.name ?? slug}
                  </Link>
                </span>
              ))}
              ?
            </p>
          )}

          {grouped.length === 0 ? (
            <div className="px-3 py-6 text-center">
              <p className="font-display text-lg text-card-foreground">No biological data found.</p>
              <p className="mt-1 text-sm text-foreground/55">
                Skinceptor covers a curated set of ingredients and biology maps, so “{query}” may simply not be in it
                yet.
              </p>
              <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.18em] text-foreground/40">Try instead</p>
              <div className="mt-2 flex flex-wrap justify-center gap-1.5">
                {hints.map((h) => (
                  <button
                    key={`${h.to}-${h.label}`}
                    type="button"
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() => {
                      setOpen(false);
                      setQuery("");
                      navigate({ to: h.to, params: h.params });
                    }}
                    className="rounded-full border border-border bg-foreground/5 px-3 py-1 text-xs transition-colors hover:bg-foreground/10"
                  >
                    {h.label}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            grouped.map((group) => (
              <div key={group.kind} className="mb-1">
                <p className="px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.18em] text-foreground/40">
                  {group.label}
                </p>
                {group.items.map((item) => {
                  const index = ordered.indexOf(item);
                  return (
                  <button
                    key={`${item.kind}-${item.title}`}
                    id={`search-option-${index}`}
                    type="button"
                    role="option"
                    aria-selected={index === activeIndex}
                    onMouseDown={(e) => e.preventDefault()}
                    onMouseEnter={() => setActiveIndex(index)}
                    onClick={() => go(item)}
                    className={cn(
                      "flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2 text-left transition-colors hover:bg-foreground/5",
                      index === activeIndex && "bg-foreground/8 ring-1 ring-accent/30",
                    )}
                  >
                    <span>
                      <span className="block text-sm text-card-foreground">{item.title}</span>
                      <span className="block text-xs text-foreground/50">{item.subtitle}</span>
                    </span>
                    {item.badge && (
                      <span className="shrink-0 rounded-md border border-border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-foreground/50">
                        {item.badge}
                      </span>
                    )}
                  </button>
                  );
                })}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
