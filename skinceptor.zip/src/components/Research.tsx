import { useState } from "react";
import type { Study, StudyType } from "@/data/types";
import { STUDY_TYPE_LABEL } from "@/lib/evidence";
import { externalLink } from "@/lib/links";
import { ingredientBySlug } from "@/data/ingredients";
import { cn } from "@/lib/utils";
import { Eyebrow, GlassPanel } from "./GlassPanel";

const TYPE_TONE: Record<StudyType, string> = {
  rct: "border-accent/40 bg-accent/10 text-accent",
  human: "border-brand/40 bg-brand/10 text-brand",
  "meta-analysis": "border-amber/40 bg-amber/10 text-amber",
  "in-vitro": "border-violet/40 bg-violet/10 text-violet",
  animal: "border-rose/40 bg-rose/10 text-rose",
  review: "border-border bg-foreground/5 text-foreground/55",
};

export function StudyTypeTag({ type }: { type: StudyType }) {
  return (
    <span
      className={cn(
        "rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.12em]",
        TYPE_TONE[type],
      )}
    >
      {STUDY_TYPE_LABEL[type]}
    </span>
  );
}

export function StudyCard({ study }: { study: Study }) {
  return (
    <article className="rounded-2xl border border-border bg-ink-2/40 p-4">
      <div className="flex flex-wrap items-center gap-2">
        <StudyTypeTag type={study.type} />
        <span className="font-mono text-[11px] text-foreground/45">
          {study.journal} · {study.year}
        </span>
        {study.sampleSize && (
          <span className="font-mono text-[11px] text-foreground/45">n = {study.sampleSize}</span>
        )}
      </div>
      <h3 className="mt-2 text-sm leading-snug text-card-foreground">{study.title}</h3>
      <p className="mt-2 text-xs leading-relaxed text-foreground/65">{study.finding}</p>
      <p className="mt-2 text-xs leading-relaxed text-foreground/45">
        <span className="font-mono uppercase tracking-wider">Limitations</span> — {study.limitations}
      </p>
      <div className="mt-3 flex flex-wrap items-center gap-3 text-[11px]">
        {study.pmid ? (
          <a
            href={externalLink.pubmed(study.pmid)}
            target="_blank"
            rel="noreferrer noopener"
            className="font-mono text-accent underline underline-offset-4"
          >
            PMID {study.pmid}
          </a>
        ) : study.doi ? (
          <a
            href={externalLink.doi(study.doi)}
            target="_blank"
            rel="noreferrer noopener"
            className="font-mono text-accent underline underline-offset-4"
          >
            DOI {study.doi}
          </a>
        ) : (
          <a
            href={externalLink.europePmcSearch(study.title)}
            target="_blank"
            rel="noreferrer noopener"
            className="font-mono text-foreground/50 underline underline-offset-4"
          >
            Identifier not curated — search Europe PMC
          </a>
        )}
        <span className="font-mono text-foreground/35">
          {study.ingredients.map((s) => ingredientBySlug.get(s)?.name ?? s).join(" · ")}
        </span>
      </div>
    </article>
  );
}

const FILTERS: (StudyType | "all")[] = ["all", "human", "rct", "meta-analysis", "in-vitro", "animal", "review"];

export function ResearchTimeline({ studies }: { studies: Study[] }) {
  const [filter, setFilter] = useState<StudyType | "all">("all");
  const shown = (filter === "all" ? studies : studies.filter((s) => s.type === filter)).slice().sort((a, b) => a.year - b.year);

  return (
    <GlassPanel className="p-5 sm:p-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <Eyebrow tone="amber">Research timeline</Eyebrow>
          <h2 className="mt-2 font-display text-2xl text-card-foreground">How the evidence accumulated</h2>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {FILTERS.map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              aria-pressed={filter === f}
              className={cn(
                "rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider transition-colors",
                filter === f ? "border-accent/50 bg-accent/15 text-accent" : "border-border text-foreground/55",
              )}
            >
              {f === "all" ? "All" : STUDY_TYPE_LABEL[f]}
            </button>
          ))}
        </div>
      </div>

      {shown.length === 0 ? (
        <p className="mt-6 text-sm text-foreground/55">No curated studies of this type for this entry.</p>
      ) : (
        <ol className="mt-6 border-l border-border pl-5">
          {shown.map((s) => (
            <li key={s.id} className="relative pb-5">
              <span
                className={cn(
                  "absolute -left-[26px] top-1.5 size-2.5 rounded-full",
                  s.type === "rct" || s.type === "human"
                    ? "bg-accent bb-glow"
                    : s.type === "meta-analysis"
                      ? "bg-amber"
                      : s.type === "in-vitro"
                        ? "bg-violet"
                        : s.type === "animal"
                          ? "bg-rose"
                          : "bg-foreground/40",
                )}
                aria-hidden="true"
              />
              <p className="font-mono text-xs text-foreground/50">{s.year}</p>
              <p className="mt-0.5 text-sm text-card-foreground">{s.title}</p>
              <p className="mt-1 flex flex-wrap items-center gap-2 text-xs text-foreground/50">
                <StudyTypeTag type={s.type} />
                {s.sampleSize ? `n = ${s.sampleSize}` : "sample size unavailable"} · {s.journal}
              </p>
            </li>
          ))}
        </ol>
      )}
    </GlassPanel>
  );
}
