import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function GlassPanel({
  children,
  className,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  as?: "div" | "section" | "aside" | "article" | "header" | "footer";
}) {
  return <Tag className={cn("bb-glass rounded-2xl", className)}>{children}</Tag>;
}

export function Eyebrow({
  children,
  tone = "accent",
  as: Tag = "p",
}: {
  children: ReactNode;
  tone?: "accent" | "brand" | "amber" | "rose" | "violet" | "muted";
  as?: "p" | "h2" | "h3";
}) {
  const tones = {
    accent: "text-accent",
    brand: "text-brand",
    amber: "text-amber",
    rose: "text-rose",
    violet: "text-violet",
    muted: "text-foreground/50",
  } as const;
  return (
    <Tag className={cn("font-mono text-[11px] font-normal uppercase tracking-[0.18em]", tones[tone])}>{children}</Tag>
  );
}
