import type { SourceRef } from "@/data/types";
import { sourceUrl } from "@/lib/links";
import { checkRetrieved, summariseProvenance, PROVENANCE_STALE_DAYS } from "@/lib/provenance";
import { GlassPanel, Eyebrow } from "@/components/GlassPanel";

const TONE: Record<string, string> = {
  verified: "border-emerald-400/25 bg-emerald-400/10 text-emerald-200/85",
  aging: "border-amber-400/25 bg-amber-400/10 text-amber-200/85",
  stale: "border-rose-400/25 bg-rose-400/10 text-rose-200/85",
  unknown: "border-white/15 bg-white/5 text-foreground/55",
};

export function RetrievedBadge({ retrieved }: { retrieved: string }) {
  const f = checkRetrieved(retrieved);
  return (
    <span
      title={f.detail}
      className={`rounded-full border px-2 py-[2px] font-mono text-[10px] tracking-wide ${TONE[f.status]}`}
    >
      {f.label}
    </span>
  );
}

/** Source list with a per-reference verification-date check. */
export function SourceList({ sources }: { sources: SourceRef[] }) {
  if (sources.length === 0) {
    return <p className="mt-3 text-xs text-foreground/50">No database references recorded — data unavailable.</p>;
  }
  return (
    <ul className="mt-3 space-y-2 text-xs text-foreground/60">
      {sources.map((s) => (
        <li key={`${s.db}-${s.id}`} className="flex flex-wrap items-center gap-2">
          <a
            href={sourceUrl(s.db, s.id)}
            target="_blank"
            rel="noreferrer noopener"
            className="font-mono text-accent underline underline-offset-4"
          >
            {s.db} {s.id}
          </a>
          <RetrievedBadge retrieved={s.retrieved} />
        </li>
      ))}
    </ul>
  );
}

/** Dataset-wide freshness roll-up, shown on /sources. */
export function ProvenanceSummary() {
  const s = summariseProvenance();
  const needsCheck = s.aging + s.stale + s.unknown;
  return (
    <GlassPanel className="p-6">
      <Eyebrow tone="muted">Provenance check</Eyebrow>
      <h2 className="mt-3 font-display text-2xl font-light text-card-foreground">
        When each identifier was last verified
      </h2>
      <p className="mt-3 text-sm leading-relaxed text-foreground/65">
        Public records change: accessions are merged, deprecated or re-annotated. Every database reference in Skinceptor
        stores the date it was checked against the live record, and anything older than {PROVENANCE_STALE_DAYS} days is
        flagged for re-verification rather than presented as current.
      </p>
      <dl className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "References", value: s.total },
          { label: "Verified", value: s.verified },
          { label: "Re-check due", value: s.aging },
          { label: "Needs re-check", value: s.stale + s.unknown },
        ].map((k) => (
          <div key={k.label} className="rounded-lg border border-white/10 bg-white/[0.03] p-3">
            <dt className="font-mono text-[10px] uppercase tracking-widest text-foreground/45">{k.label}</dt>
            <dd className="mt-1 font-display text-2xl text-card-foreground">{k.value}</dd>
          </div>
        ))}
      </dl>
      <ul className="mt-5 grid gap-2 text-xs text-foreground/60 sm:grid-cols-2">
        {s.byDb.map((d) => (
          <li key={d.db} className="flex items-center justify-between gap-3 rounded-md border border-white/10 px-3 py-2">
            <span className="font-mono">{d.db}</span>
            <span className="text-foreground/45">
              {d.count} ref{d.count === 1 ? "" : "s"}
              {d.stale > 0 ? ` · ${d.stale} to re-check` : ""}
            </span>
          </li>
        ))}
      </ul>
      <p className="mt-4 text-xs text-foreground/45">
        {needsCheck === 0
          ? `All ${s.total} references were verified within the last ${PROVENANCE_STALE_DAYS} days.`
          : `${needsCheck} of ${s.total} references are due for re-verification.`}{" "}
        {s.oldest ? `Oldest check ${s.oldest}.` : null} {s.newest ? `Most recent ${s.newest}.` : null}
      </p>
    </GlassPanel>
  );
}
