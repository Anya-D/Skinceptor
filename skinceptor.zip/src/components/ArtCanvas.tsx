import { useMemo, useRef, useState } from "react";
import type { BiologyGraph, NodeKind } from "@/data/types";
import { type ArtStyle, generateArtwork, svgToPngBlob } from "@/lib/art";
import { cn } from "@/lib/utils";

export function ArtCanvas({
  graph,
  seed,
  style,
  showLabels = false,
  hiddenKinds = [],
  className,
  size = 720,
  interactive = true,
}: {
  graph: BiologyGraph;
  seed: string;
  style: ArtStyle;
  showLabels?: boolean;
  hiddenKinds?: NodeKind[];
  className?: string;
  size?: number;
  interactive?: boolean;
}) {
  const svgRef = useRef<SVGSVGElement>(null);
  const [rotation, setRotation] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [exporting, setExporting] = useState(false);

  const visible = useMemo<BiologyGraph>(() => {
    const nodes = graph.nodes.filter((n) => !hiddenKinds.includes(n.kind));
    const keep = new Set(nodes.map((n) => n.id));
    return { nodes, edges: graph.edges.filter((e) => keep.has(e.source) && keep.has(e.target)) };
  }, [graph, hiddenKinds]);

  const art = useMemo(() => generateArtwork(visible, style, seed, size), [visible, style, seed, size]);

  const exportPng = async () => {
    if (!svgRef.current) return;
    setExporting(true);
    try {
      const blob = await svgToPngBlob(svgRef.current);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `skinceptor-${seed}-${style}.png`;
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className={cn("rounded-2xl border border-border bg-ink-2/60", className)}>
      <svg
        ref={svgRef}
        viewBox={`0 0 ${art.size} ${art.size}`}
        className="h-auto w-full"
        role="img"
        aria-label={`Generative artwork derived from ${art.seedSummary}`}
      >
        <g transform={`rotate(${rotation} ${art.size / 2} ${art.size / 2}) scale(${zoom}) translate(${(art.size * (1 - zoom)) / (2 * zoom)} ${(art.size * (1 - zoom)) / (2 * zoom)})`}>
          {art.rings.map((r) => (
            <path key={r.id} d={r.d} fill="none" stroke={r.color} strokeOpacity={r.opacity} strokeWidth={1} />
          ))}
          {art.lines.map((l) => (
            <line
              key={l.id}
              x1={l.x1}
              y1={l.y1}
              x2={l.x2}
              y2={l.y2}
              stroke="var(--fog)"
              strokeOpacity={l.opacity}
              strokeWidth={0.7}
            />
          ))}
          {art.points.map((p) => (
            <g key={p.id}>
              <circle cx={p.x} cy={p.y} r={p.r * 3} fill={p.color} opacity={p.opacity * 0.14} />
              <circle cx={p.x} cy={p.y} r={p.r} fill={p.color} opacity={p.opacity} />
              {showLabels && (
                <text
                  x={p.x + p.r + 4}
                  y={p.y + 3}
                  style={{ font: "400 8px var(--font-mono)", fill: "var(--fog)" }}
                  opacity={0.6}
                >
                  {p.label.length > 22 ? `${p.label.slice(0, 21)}…` : p.label}
                </text>
              )}
            </g>
          ))}
        </g>
      </svg>

      {interactive && (
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border px-4 py-3">
          <p className="font-mono text-[10px] uppercase tracking-wider text-foreground/40">{art.seedSummary}</p>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setRotation((r) => (r + 30) % 360)}
              className="rounded-lg border border-border px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-foreground/60 hover:text-card-foreground"
            >
              Rotate
            </button>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(1.8, +(z + 0.15).toFixed(2)))}
              className="size-7 rounded-lg border border-border font-mono text-xs text-foreground/60"
              aria-label="Zoom in"
            >
              +
            </button>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.6, +(z - 0.15).toFixed(2)))}
              className="size-7 rounded-lg border border-border font-mono text-xs text-foreground/60"
              aria-label="Zoom out"
            >
              −
            </button>
            <button
              type="button"
              onClick={exportPng}
              disabled={exporting}
              className="rounded-lg border border-accent/40 bg-accent/10 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-accent disabled:opacity-50"
            >
              {exporting ? "Exporting…" : "Export PNG"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
