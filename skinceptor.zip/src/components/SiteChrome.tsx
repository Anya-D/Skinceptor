import { Link, useNavigate } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { listMyRoles } from "@/lib/review.functions";

const navItems = [
  { to: "/explore", label: "Explore" },
  { to: "/ingredient-checker", label: "Ingredient checker" },
  { to: "/research", label: "Research" },
  { to: "/compare", label: "Compare" },
  { to: "/art", label: "Art" },
  { to: "/sources", label: "Sources" },
  { to: "/about", label: "About" },
] as const;

export function AmbientBackdrop() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden="true">
      <div className="absolute -left-32 -top-40 size-[520px] rounded-full bg-brand/25 blur-[130px]" />
      <div className="absolute right-[-160px] top-1/3 size-[480px] rounded-full bg-accent/20 blur-[130px]" />
      <div className="absolute bottom-[-160px] left-1/3 size-[460px] rounded-full bg-violet/20 blur-[130px]" />
      <div className="bb-dots absolute inset-0 opacity-[0.35]" />
    </div>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { signedIn, loading } = useAuth();
  const navigate = useNavigate();
  const fetchRoles = useServerFn(listMyRoles);
  const roles = useQuery({
    queryKey: ["my-roles"],
    queryFn: () => fetchRoles(),
    enabled: signedIn,
    staleTime: 5 * 60 * 1000,
  });
  const isReviewer = (roles.data ?? []).some((r) => r === "reviewer" || r === "admin");

  async function signOut() {
    await supabase.auth.signOut();
    await navigate({ to: "/" });
  }

  return (
    <header className="relative z-20 mx-auto max-w-7xl px-4 pt-4 sm:px-6 sm:pt-6">
      <div className="bb-glass flex items-center justify-between gap-3 rounded-2xl px-4 py-3 sm:px-5">
        <Link to="/" className="flex items-center gap-2.5">
          <span className="grid size-8 place-items-center rounded-lg bg-gradient-to-br from-brand to-accent font-display font-semibold text-ink">
            S
          </span>
          <span className="font-display text-lg tracking-tight text-card-foreground">Skinceptor</span>
          <span className="ml-1 hidden font-mono text-[10px] uppercase tracking-[0.2em] text-foreground/50 lg:inline">
            Biological Intelligence
          </span>
        </Link>

        <nav aria-label="Main" className="hidden items-center gap-7 text-sm text-foreground/70 md:flex">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="transition-colors hover:text-card-foreground"
              activeProps={{ className: "text-card-foreground" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            to="/claim-checker"
            className="hidden text-sm text-foreground/70 transition-colors hover:text-card-foreground sm:block"
          >
            Check a claim
          </Link>
          {!loading && signedIn && (
            <Link
              to="/library"
              className="hidden text-sm text-foreground/70 transition-colors hover:text-card-foreground sm:block"
              activeProps={{ className: "text-card-foreground" }}
            >
              My library
            </Link>
          )}
          {!loading && signedIn && isReviewer && (
            <Link
              to="/review"
              className="hidden text-sm text-amber/90 transition-colors hover:text-card-foreground sm:block"
              activeProps={{ className: "text-card-foreground" }}
            >
              Review queue
            </Link>
          )}
          {!loading && signedIn ? (
            <button
              type="button"
              onClick={() => void signOut()}
              className="rounded-full border border-border bg-foreground/10 px-4 py-1.5 text-sm font-medium transition-colors hover:bg-foreground/15"
            >
              Sign out
            </button>
          ) : (
            <Link
              to="/auth"
              className="rounded-full border border-border bg-foreground/10 px-4 py-1.5 text-sm font-medium transition-colors hover:bg-foreground/15"
            >
              Sign in
            </Link>
          )}
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            className="rounded-lg border border-border px-2.5 py-1.5 font-mono text-[11px] uppercase tracking-wider text-foreground/70 md:hidden"
          >
            Menu
          </button>
        </div>
      </div>

      {open && (
        <nav
          id="mobile-nav"
          aria-label="Mobile"
          className="bb-glass mt-2 grid gap-1 rounded-2xl p-3 text-sm md:hidden"
        >
          {[
            ...navItems,
            { to: "/claim-checker", label: "Claim checker" },
            { to: "/methodology", label: "Methodology" },
            ...(signedIn
              ? ([
                  { to: "/library", label: "My library" },
                  { to: "/submit-evidence", label: "Submit evidence" },
                  ...(isReviewer ? ([{ to: "/review", label: "Review queue" }] as const) : []),
                ] as const)
              : ([{ to: "/auth", label: "Sign in" }] as const)),
          ].map(
            (item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2 text-foreground/75 transition-colors hover:bg-foreground/5 hover:text-card-foreground"
              >
                {item.label}
              </Link>
            ),
          )}
        </nav>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="relative z-10 mx-auto max-w-7xl px-4 pb-10 sm:px-6">
      <div className="bb-glass flex flex-col justify-between gap-3 rounded-2xl px-5 py-4 text-xs text-foreground/50 md:flex-row md:items-center">
        <p className="font-mono">
          Skinceptor aggregates public scientific resources. It does not independently validate every claim, and it is
          not medical advice.
        </p>
        <div className="flex flex-wrap gap-5">
          <Link to="/about" className="transition-colors hover:text-card-foreground">
            About
          </Link>
          <Link to="/methodology" className="transition-colors hover:text-card-foreground">
            Methodology
          </Link>
          <Link to="/sources" className="transition-colors hover:text-card-foreground">
            Data sources
          </Link>
          <Link to="/claim-checker" className="transition-colors hover:text-card-foreground">
            Claim checker
          </Link>
        </div>
      </div>
    </footer>
  );
}

export function PageShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-screen">
      <AmbientBackdrop />
      <SiteHeader />
      <main id="main" className="relative z-10">
        {children}
      </main>
      <SiteFooter />
    </div>
  );
}
