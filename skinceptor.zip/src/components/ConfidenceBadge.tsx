import type { Confidence } from "@/data/types";
import { cn } from "@/lib/utils";

const styles: Record<Confidence, string> = {
  HIGH: "border-accent/40 bg-accent/10 text-accent",
  MEDIUM: "border-brand/40 bg-brand/10 text-brand",
  LOW: "border-border bg-foreground/5 text-foreground/55",
};

const labels: Record<Confidence, string> = {
  HIGH: "high confidence",
  MEDIUM: "medium confidence",
  LOW: "low confidence",
};

export function ConfidenceBadge({ level, className }: { level: Confidence; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.12em]",
        styles[level],
        className,
      )}
    >
      <span className="size-1.5 rounded-full bg-current" aria-hidden="true" />
      {labels[level]}
    </span>
  );
}
