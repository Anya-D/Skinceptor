import type { ReplicationFlag, ReplicationKey } from "@/lib/evidence";
import { cn } from "@/lib/utils";

const TONE: Record<ReplicationKey, string> = {
  replicated: "border-accent/45 bg-accent/12 text-accent",
  emerging: "border-brand/45 bg-brand/12 text-brand",
  "single-study": "border-amber/45 bg-amber/12 text-amber",
  mechanistic: "border-violet/45 bg-violet/12 text-violet",
  none: "border-border bg-foreground/5 text-foreground/50",
};

export function ReplicationBadge({
  flag,
  className,
  showDetail = false,
}: {
  flag: ReplicationFlag;
  className?: string;
  showDetail?: boolean;
}) {
  return (
    <span className={cn("inline-flex flex-col gap-1", className)}>
      <span
        title={flag.detail}
        className={cn(
          "inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.12em]",
          TONE[flag.key],
        )}
      >
        <span className="size-1.5 rounded-full bg-current" aria-hidden="true" />
        {flag.label}
      </span>
      {showDetail && <span className="text-xs leading-relaxed text-foreground/50">{flag.detail}</span>}
    </span>
  );
}

export function OverstatedBadge({ reasons }: { reasons: string[] }) {
  return (
    <div className="rounded-2xl border border-rose/45 bg-rose/10 p-4">
      <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-rose">
        This claim is overstated relative to evidence
      </p>
      <ul className="mt-2 space-y-1 text-xs leading-relaxed text-rose/90">
        {reasons.map((r) => (
          <li key={r}>· {r}</li>
        ))}
      </ul>
      <p className="mt-2 text-[11px] leading-relaxed text-rose/70">
        Overstated wording is not the same as a false mechanism — the biology may still be real, just less certain than
        the claim implies.
      </p>
    </div>
  );
}
