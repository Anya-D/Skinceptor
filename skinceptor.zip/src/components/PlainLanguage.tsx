import { createContext, useCallback, useContext, useId, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { segmentGlossary } from "@/lib/glossary";
import { cn } from "@/lib/utils";

/**
 * Plain-English translation layer.
 *
 * Technical terms in curated copy become small buttons. Pressing one reveals an
 * everyday-English explanation; the page-level toggle opens all of them at once.
 * Translations explain wording only — they never add claims.
 */

interface PlainEnglishState {
  expandAll: boolean;
  setExpandAll: (value: boolean) => void;
}

const PlainEnglishContext = createContext<PlainEnglishState>({ expandAll: false, setExpandAll: () => {} });

export function PlainEnglishProvider({ children }: { children: ReactNode }) {
  const [expandAll, setExpandAll] = useState(false);
  const value = useMemo(() => ({ expandAll, setExpandAll }), [expandAll]);
  return <PlainEnglishContext.Provider value={value}>{children}</PlainEnglishContext.Provider>;
}

export function PlainEnglishToggle({ className }: { className?: string }) {
  const { expandAll, setExpandAll } = useContext(PlainEnglishContext);
  return (
    <button
      type="button"
      onClick={() => setExpandAll(!expandAll)}
      aria-pressed={expandAll}
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm transition-colors",
        expandAll
          ? "border-accent/50 bg-accent/15 text-accent"
          : "border-border bg-foreground/10 text-foreground/75 hover:text-card-foreground",
        className,
      )}
    >
      <span aria-hidden>{expandAll ? "◉" : "◎"}</span>
      {expandAll ? "Plain English: on" : "Explain in plain English"}
    </button>
  );
}

function TranslatableTerm({ text, plain }: { text: string; plain: string }) {
  const { expandAll } = useContext(PlainEnglishContext);
  const [open, setOpen] = useState(false);
  const id = useId();
  const shown = open || expandAll;
  const toggle = useCallback(() => setOpen((v) => !v), []);

  return (
    <span className="relative inline">
      <button
        type="button"
        onClick={toggle}
        aria-expanded={shown}
        aria-controls={id}
        title={`Translate "${text}" into plain English`}
        className="cursor-help rounded-[3px] underline decoration-accent/50 decoration-dotted decoration-from-font underline-offset-[3px] transition-colors hover:text-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent/60"
      >
        {text}
        <span aria-hidden className="ml-[2px] align-super font-mono text-[8px] tracking-wide text-accent">
          EN
        </span>
      </button>
      {shown && (
        <span
          id={id}
          role="note"
          className="my-1 block rounded-lg border border-accent/25 bg-accent/[0.07] px-3 py-2 text-[13px] font-normal not-italic leading-relaxed text-foreground/80"
        >
          <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-accent">In plain English</span>
          <span className="mt-1 block normal-case tracking-normal">{plain}</span>
        </span>
      )}
    </span>
  );
}

/** Renders text with every known technical term made translatable. */
export function PlainText({ children, className }: { children: string | null | undefined; className?: string }) {
  const segments = useMemo(() => segmentGlossary(children ?? ""), [children]);
  if (!children) return null;
  return (
    <span className={className}>
      {segments.map((seg, i) =>
        seg.entry ? (
          <TranslatableTerm key={`${seg.text}-${i}`} text={seg.text} plain={seg.entry.plain} />
        ) : (
          <span key={`t-${i}`}>{seg.text}</span>
        ),
      )}
    </span>
  );
}
