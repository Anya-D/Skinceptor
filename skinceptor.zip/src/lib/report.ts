import type { Ingredient, Study } from "@/data/types";
import { STUDY_TYPE_LABEL, computeEvidence, replicationFlag } from "./evidence";

/**
 * Builds a self-contained, print-ready HTML evidence report and opens the
 * browser print dialog, where it can be saved as a PDF. Everything in the
 * report is generated from curated records — no values are invented.
 */

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function studyRows(studies: Study[]) {
  if (!studies.length) return `<p class="muted">No curated studies for this ingredient.</p>`;
  return `<table>
    <thead><tr><th>Year</th><th>Study</th><th>Design</th><th>n</th><th>Identifier</th></tr></thead>
    <tbody>${studies
      .slice()
      .sort((a, b) => b.year - a.year)
      .map(
        (s) => `<tr>
          <td>${s.year}</td>
          <td><strong>${esc(s.title)}</strong><br /><span class="muted">${esc(s.journal)} — ${esc(s.finding)}</span><br /><span class="muted">Limitations: ${esc(s.limitations)}</span></td>
          <td>${STUDY_TYPE_LABEL[s.type]}</td>
          <td>${s.sampleSize ?? "—"}</td>
          <td>${s.pmid ? `PMID ${esc(s.pmid)}` : s.doi ? `DOI ${esc(s.doi)}` : "not curated"}</td>
        </tr>`,
      )
      .join("")}</tbody></table>`;
}

function ingredientSection(ing: Ingredient, studies: Study[]) {
  const report = computeEvidence(studies);
  const flag = replicationFlag(studies);
  return `<section>
    <h2>${esc(ing.name)}</h2>
    <p class="meta">${esc(ing.className)} · ${esc(ing.formula ?? "formula unavailable")} · ${
      ing.molecularWeight ? `${ing.molecularWeight} g/mol` : "MW unavailable"
    } · ${ing.pubchemCid ? `PubChem ${esc(ing.pubchemCid)}` : "PubChem unavailable"}</p>
    <p>${esc(ing.summary)}</p>
    <p class="pill">Evidence Index (experimental) ${report.index}/100 · strength ${report.strength} · ${flag.label}</p>
    <h3>Biological targets</h3>
    <ul>${ing.targets
      .map((t) => `<li>${esc(t.name)} — ${esc(t.relation)} (${t.confidence.toLowerCase()} confidence)</li>`)
      .join("")}</ul>
    <h3>Pathways</h3>
    <ul>${ing.pathways.map((p) => `<li>${esc(p.name)} <span class="muted">${esc(p.db)}</span></li>`).join("")}</ul>
    <h3>Cellular processes</h3>
    <ul>${ing.processes.map((p) => `<li>${esc(p.name)}</li>`).join("")}</ul>
    <h3>Index breakdown</h3>
    <ul>${report.components
      .map(
        (c) =>
          `<li>${esc(c.label)}: ${Math.round(c.value * 100)}% × weight ${Math.round(c.weight * 100)}% — ${esc(
            c.explanation,
          )}</li>`,
      )
      .join("")}</ul>
    <h3>Curated literature (${studies.length})</h3>
    ${studyRows(studies)}
  </section>`;
}

const STYLES = `
  * { box-sizing: border-box; }
  body { font: 12px/1.55 Georgia, "Times New Roman", serif; color: #101418; margin: 32px; }
  h1 { font-size: 24px; margin: 0 0 4px; }
  h2 { font-size: 17px; margin: 22px 0 4px; border-bottom: 1px solid #ccc; padding-bottom: 4px; }
  h3 { font-size: 12px; text-transform: uppercase; letter-spacing: .08em; margin: 14px 0 4px; color: #45505c; }
  p { margin: 6px 0; }
  ul { margin: 4px 0 4px 18px; padding: 0; }
  li { margin: 2px 0; }
  .meta, .muted { color: #5a6673; font-size: 11px; }
  .pill { display: inline-block; border: 1px solid #9aa7b4; border-radius: 999px; padding: 3px 10px; font-size: 11px; }
  .boundary { border: 1px solid #b48a2f; background: #fdf6e6; padding: 10px; font-size: 11px; margin-top: 18px; }
  table { width: 100%; border-collapse: collapse; margin-top: 6px; }
  th, td { border-bottom: 1px solid #dce1e6; padding: 5px 6px; text-align: left; vertical-align: top; font-size: 11px; }
  th { font-size: 10px; text-transform: uppercase; letter-spacing: .06em; color: #45505c; }
  section { page-break-inside: auto; }
  @page { margin: 16mm; }
`;

export function exportEvidenceReport(entries: { ingredient: Ingredient; studies: Study[] }[], title: string) {
  const generated = new Date().toISOString().slice(0, 10);
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8" />
    <title>${esc(title)}</title><style>${STYLES}</style></head><body>
    <h1>${esc(title)}</h1>
    <p class="meta">Skinceptor evidence report · generated ${generated} · skinceptor.tech</p>
    ${entries.map((e) => ingredientSection(e.ingredient, e.studies)).join("")}
    <div class="boundary">
      The Skinceptor Evidence Index is an experimental research-navigation aid describing how much evidence exists and
      how it was produced. It is not a safety score, an efficacy guarantee, a ranking, or a clinical recommendation, and
      nothing in this report is medical advice. Missing values are shown as unavailable rather than estimated.
    </div>
    <script>window.onload = function () { window.focus(); window.print(); };</script>
  </body></html>`;

  const win = window.open("", "_blank", "width=900,height=1100");
  if (!win) return false;
  win.document.open();
  win.document.write(html);
  win.document.close();
  return true;
}
