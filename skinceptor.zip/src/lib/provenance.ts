/**
 * Provenance freshness checks.
 *
 * Every SourceRef carries the ISO date its identifier was last verified against
 * the public record (PubChem, UniProt, Reactome, …). Identifiers drift: records
 * get merged, accessions get deprecated. Rather than silently presenting an old
 * check as current, the UI flags how long ago each reference was verified.
 */

import type { SourceRef } from "@/data/types";
import { ingredients } from "@/data/ingredients";
import { topics } from "@/data/topics";

/** A reference older than this is treated as needing re-verification. */
export const PROVENANCE_STALE_DAYS = 365;
/** A reference older than this is flagged as due for a check soon. */
export const PROVENANCE_AGING_DAYS = 180;

export type ProvenanceStatus = "verified" | "aging" | "stale" | "unknown";

export interface Freshness {
  status: ProvenanceStatus;
  /** Whole days since the identifier was verified; null when the date is unparsable. */
  days: number | null;
  label: string;
  detail: string;
}

const DAY = 86_400_000;

export function checkRetrieved(retrieved: string | undefined, now: Date = new Date()): Freshness {
  const parsed = retrieved ? Date.parse(retrieved) : Number.NaN;
  if (!retrieved || Number.isNaN(parsed)) {
    return {
      status: "unknown",
      days: null,
      label: "Verification date unavailable",
      detail: "No verification date was recorded for this reference.",
    };
  }
  const days = Math.max(0, Math.floor((now.getTime() - parsed) / DAY));
  if (days > PROVENANCE_STALE_DAYS) {
    return {
      status: "stale",
      days,
      label: `Needs re-check · ${retrieved}`,
      detail: `Last verified ${days} days ago, beyond the ${PROVENANCE_STALE_DAYS}-day re-verification window.`,
    };
  }
  if (days > PROVENANCE_AGING_DAYS) {
    return {
      status: "aging",
      days,
      label: `Re-check due · ${retrieved}`,
      detail: `Last verified ${days} days ago; due for re-verification within ${PROVENANCE_STALE_DAYS} days of curation.`,
    };
  }
  return {
    status: "verified",
    days,
    label: `Verified ${retrieved}`,
    detail: days === 0 ? "Verified today." : `Verified ${days} day${days === 1 ? "" : "s"} ago.`,
  };
}

export interface ProvenanceSummaryData {
  total: number;
  verified: number;
  aging: number;
  stale: number;
  unknown: number;
  oldest: string | null;
  newest: string | null;
  byDb: { db: SourceRef["db"]; count: number; stale: number }[];
}

export function allSourceRefs(): SourceRef[] {
  return [...ingredients.flatMap((i) => i.sources), ...topics.flatMap((t) => t.sources)];
}

export function summariseProvenance(now: Date = new Date()): ProvenanceSummaryData {
  const refs = allSourceRefs();
  const counts = { verified: 0, aging: 0, stale: 0, unknown: 0 };
  const dbMap = new Map<SourceRef["db"], { count: number; stale: number }>();
  let oldest: string | null = null;
  let newest: string | null = null;

  for (const ref of refs) {
    const f = checkRetrieved(ref.retrieved, now);
    counts[f.status] += 1;
    const entry = dbMap.get(ref.db) ?? { count: 0, stale: 0 };
    entry.count += 1;
    if (f.status === "stale") entry.stale += 1;
    dbMap.set(ref.db, entry);
    if (f.days !== null) {
      if (!oldest || ref.retrieved < oldest) oldest = ref.retrieved;
      if (!newest || ref.retrieved > newest) newest = ref.retrieved;
    }
  }

  return {
    total: refs.length,
    ...counts,
    oldest,
    newest,
    byDb: [...dbMap.entries()]
      .map(([db, v]) => ({ db, ...v }))
      .sort((a, b) => b.count - a.count),
  };
}
