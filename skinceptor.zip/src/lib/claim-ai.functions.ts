import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export interface ClaimAnalysis {
  verdict: "biologically plausible" | "partially supported" | "unsupported" | "overstated" | "not assessable";
  plausibility_summary: string;
  mechanism_steps: { step: string; explanation: string; study_ids: string[] }[];
  supported_by: string[];
  evidence_gaps: string[];
  overstated_language: string[];
  medical_caveat: string;
}

const ANALYSIS_SCHEMA = {
  type: "object",
  additionalProperties: false,
  required: [
    "verdict",
    "plausibility_summary",
    "mechanism_steps",
    "supported_by",
    "evidence_gaps",
    "overstated_language",
    "medical_caveat",
  ],
  properties: {
    verdict: {
      type: "string",
      enum: ["biologically plausible", "partially supported", "unsupported", "overstated", "not assessable"],
    },
    plausibility_summary: { type: "string" },
    mechanism_steps: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["step", "explanation", "study_ids"],
        properties: {
          step: { type: "string" },
          explanation: { type: "string" },
          study_ids: { type: "array", items: { type: "string" } },
        },
      },
    },
    supported_by: { type: "array", items: { type: "string" } },
    evidence_gaps: { type: "array", items: { type: "string" } },
    overstated_language: { type: "array", items: { type: "string" } },
    medical_caveat: { type: "string" },
  },
} as const;

const SYSTEM = `You are a cautious biology analyst for Skinceptor, an educational tool about the biology of cosmetic ingredients.
Assess whether a beauty marketing claim is biologically plausible, using only the curated context provided plus well-established biology.
Rules:
- Never make medical, diagnostic or treatment claims, and never promise outcomes.
- Prefer "studied for", "associated with", "reported in" over causal certainty.
- Say plainly when evidence is absent, in-vitro only, or limited; use verdict "not assessable" when the curated context has nothing relevant.
- Do not invent studies, PMIDs, numbers or effect sizes. Reference only titles present in the context.
- Flag absolute marketing language (permanently, erases, cures, guaranteed) in overstated_language.
- Keep every field concise. mechanism_steps: at most 5 steps, ordered ingredient -> target -> pathway -> tissue process -> outcome.
- Every STUDY line in the context begins with an id in square brackets, e.g. [id=niacinamide-2002-hakozaki]. For each mechanism step, put the ids of the specific studies that support THAT step in study_ids. Copy ids exactly. Use an empty array when no curated study supports the step — never guess an id, and never attach a study to a step it does not actually test.`;

export const analyzeClaim = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { claim: string; context: string; save?: boolean }) => {
    const claim = input.claim?.trim();
    if (!claim) throw new Error("Enter a claim to analyse.");
    return {
      claim: claim.slice(0, 600),
      context: (input.context ?? "").slice(0, 12000),
      save: input.save !== false,
    };
  })
  .handler(async ({ data, context }) => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("AI is not configured for this project yet.");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": apiKey,
        "X-Lovable-AIG-SDK": "fetch",
      },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        stream: true,
        reasoning: { effort: "low", summary: "auto" },
        input: [
          { role: "system", content: [{ type: "input_text", text: SYSTEM }] },
          {
            role: "user",
            content: [
              {
                type: "input_text",
                text: `Claim: "${data.claim}"\n\nCurated Skinceptor context:\n${data.context || "(no curated matches were found)"}\n\nReturn the analysis as json.`,
              },
            ],
          },
        ],
        text: {
          format: {
            type: "json_schema",
            name: "claim_analysis",
            strict: true,
            schema: ANALYSIS_SCHEMA,
          },
        },
      }),
    });

    if (!res.ok) {
      const body = await res.text();
      if (res.status === 429) throw new Error("AI analysis is rate limited right now. Try again in a moment.");
      if (res.status === 402)
        throw new Error("AI analysis is unavailable: this workspace is out of AI credits. Add credits to continue.");
      if (res.status === 403)
        throw new Error("AI analysis is blocked by workspace settings. An admin needs to enable Lovable AI.");
      throw new Error(`AI analysis failed (${res.status}). ${body.slice(0, 200)}`);
    }

    // Read the SSE stream and accumulate the JSON output.
    const reader = res.body?.getReader();
    if (!reader) throw new Error("AI analysis returned no response body.");
    const decoder = new TextDecoder();
    let buffer = "";
    let text = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        try {
          const event = JSON.parse(payload) as {
            type?: string;
            delta?: string;
            response?: { output_text?: string };
          };
          if (event.type === "response.output_text.delta" && typeof event.delta === "string") {
            text += event.delta;
          } else if (event.type === "response.completed" && event.response?.output_text) {
            if (!text) text = event.response.output_text;
          }
        } catch {
          // ignore keep-alive / non-JSON frames
        }
      }
    }

    if (!text.trim()) {
      throw new Error("The model returned an empty analysis. Try rephrasing the claim.");
    }

    let analysis: ClaimAnalysis;
    try {
      analysis = JSON.parse(text) as ClaimAnalysis;
    } catch {
      throw new Error("The analysis could not be read. Try again.");
    }

    let savedId: string | null = null;
    if (data.save) {
      const { data: row } = await context.supabase
        .from("claim_analyses")
        .insert({
          user_id: context.userId,
          claim: data.claim,
          verdict: analysis.verdict,
          plausibility: analysis.plausibility_summary,
          analysis: analysis as unknown as never,
          model: "openai/gpt-6-astra",
        })
        .select("id")
        .maybeSingle();
      savedId = row?.id ?? null;
    }

    return { analysis, savedId };
  });

export const listClaimAnalyses = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("claim_analyses")
      .select("id, claim, verdict, plausibility, analysis, created_at")
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const deleteClaimAnalysis = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => ({ id: input.id }))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("claim_analyses").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
