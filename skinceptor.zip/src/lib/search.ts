import { ingredients } from "@/data/ingredients";
import { topics } from "@/data/topics";
import { studies } from "@/data/studies";

export type ResultKind = "ingredient" | "topic" | "gene" | "protein" | "pathway" | "research";

export interface SearchResult {
  kind: ResultKind;
  title: string;
  subtitle: string;
  to: string;
  /** Route params for TanStack Router links, when the route is dynamic. */
  params?: Record<string, string>;
  score: number;
  badge?: string;
}

const normalise = (s: string) =>
  s
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[^a-z0-9\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

/** Levenshtein distance, capped for speed on short strings. */
function editDistance(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length || !b.length) return Math.max(a.length, b.length);
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const row = [i];
    for (let j = 1; j <= b.length; j++) {
      row[j] = Math.min((prev[j] ?? 0) + 1, (row[j - 1] ?? 0) + 1, (prev[j - 1] ?? 0) + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    prev = row;
  }
  return prev[b.length] ?? 0;
}

/** 0-1 similarity, tolerant of typos and of prefix/substring matches. */
function similarity(query: string, candidate: string): number {
  if (!query) return 0;
  if (candidate === query) return 1;
  if (candidate.startsWith(query)) return 0.92;
  if (candidate.includes(query)) return 0.8;
  const words = candidate.split(" ");
  if (words.some((w) => w.startsWith(query))) return 0.72;
  const d = editDistance(query, candidate);
  const tolerance = query.length <= 4 ? 1 : query.length <= 7 ? 2 : 3;
  if (d <= tolerance) return 0.65 - d * 0.05;
  const near = words.find((w) => editDistance(query, w) <= tolerance);
  return near ? 0.55 : 0;
}

/** Short forms that are genuinely ambiguous get flagged rather than guessed. */
export const AMBIGUOUS_TERMS: Record<string, string[]> = {
  ha: ["hyaluronic-acid"],
  aha: ["glycolic-acid", "lactic-acid"],
  bha: ["salicylic-acid"],
  c: ["l-ascorbic-acid"],
  a: ["retinol"],
  vitamin: ["niacinamide", "l-ascorbic-acid", "tocopherol", "biotin"],
};

export function isAmbiguous(query: string): string[] | null {
  const q = normalise(query);
  const hits = AMBIGUOUS_TERMS[q];
  return hits && hits.length > 1 ? hits : null;
}

export function search(rawQuery: string, limit = 12): SearchResult[] {
  const q = normalise(rawQuery);
  if (q.length < 1) return [];
  const results: SearchResult[] = [];

  for (const ing of ingredients) {
    const haystack = [ing.name, ing.inci ?? "", ing.slug.replace(/-/g, " "), ...ing.aliases].map(normalise);
    const score = Math.max(...haystack.map((h) => similarity(q, h)));
    if (score > 0.5) {
      results.push({
        kind: "ingredient",
        title: ing.name,
        subtitle: `${ing.className} · ${ing.formula ?? "formula unavailable"}`,
        to: "/ingredient/$slug",
        params: { slug: ing.slug },
        score: score + 0.06,
        badge: ing.className,
      });
    }
  }

  for (const t of topics) {
    const haystack = [t.name, t.slug.replace(/-/g, " "), ...t.aliases].map(normalise);
    const score = Math.max(...haystack.map((h) => similarity(q, h)));
    if (score > 0.5) {
      results.push({
        kind: "topic",
        title: t.name,
        subtitle: `${t.genes.length} genes · ${t.pathways.length} pathways · ${t.ingredients.length} ingredients`,
        to: "/topic/$slug",
        params: { slug: t.slug },
        score: score + 0.04,
        badge: "Topic",
      });
    }
  }

  // Genes and proteins are indexed from ingredient and topic records.
  const geneIndex = new Map<string, { name: string; owners: string[]; uniprot?: string | undefined }>();
  for (const ing of ingredients) {
    for (const g of ing.genes) {
      const entry = geneIndex.get(g.symbol) ?? { name: g.name, owners: [], uniprot: g.uniprot };
      entry.owners.push(ing.slug);
      geneIndex.set(g.symbol, entry);
    }
  }
  for (const t of topics) {
    for (const g of t.genes) {
      const entry = geneIndex.get(g.symbol) ?? { name: g.name, owners: [], uniprot: g.uniprot };
      geneIndex.set(g.symbol, entry);
    }
  }
  for (const [symbol, entry] of geneIndex) {
    const score = Math.max(similarity(q, normalise(symbol)), similarity(q, normalise(entry.name)));
    if (score > 0.6) {
      results.push({
        kind: "gene",
        title: symbol,
        subtitle: entry.name,
        to: "/explore",
        score,
        badge: "Gene",
      });
    }
  }

  const pathwayIndex = new Map<string, string>();
  for (const ing of ingredients) for (const p of ing.pathways) pathwayIndex.set(p.name, p.db);
  for (const t of topics) for (const p of t.pathways) pathwayIndex.set(p.name, p.db);
  for (const [name, db] of pathwayIndex) {
    const score = similarity(q, normalise(name));
    if (score > 0.6) {
      results.push({ kind: "pathway", title: name, subtitle: db, to: "/explore", score, badge: "Pathway" });
    }
  }

  for (const s of studies) {
    const score = similarity(q, normalise(s.title));
    if (score > 0.7) {
      results.push({
        kind: "research",
        title: s.title,
        subtitle: `${s.journal} · ${s.year}`,
        to: "/research",
        score: score - 0.1,
        badge: "Research",
      });
    }
  }

  return results.sort((a, b) => b.score - a.score).slice(0, limit);
}

export function groupResults(results: SearchResult[]) {
  const order: ResultKind[] = ["ingredient", "topic", "gene", "protein", "pathway", "research"];
  const labels: Record<ResultKind, string> = {
    ingredient: "Ingredients",
    topic: "Topics",
    gene: "Genes",
    protein: "Proteins",
    pathway: "Pathways",
    research: "Research",
  };
  return order
    .map((kind) => ({ kind, label: labels[kind], items: results.filter((r) => r.kind === kind) }))
    .filter((g) => g.items.length > 0);
}

/** Suggestions shown when a query returns nothing — nearest curated entries first. */
export function suggestions(rawQuery: string, limit = 5): { label: string; to: string; params: Record<string, string> }[] {
  const q = normalise(rawQuery);
  const scored: { label: string; to: string; params: Record<string, string>; score: number }[] = [];
  if (q) {
    for (const ing of ingredients) {
      const hay = [ing.name, ing.className, ...ing.aliases].map(normalise);
      const score = Math.max(...hay.map((h) => similarity(q, h)), 0);
      const partial = hay.some((h) => h.includes(q.slice(0, 3))) ? 0.3 : 0;
      scored.push({
        label: ing.name,
        to: "/ingredient/$slug",
        params: { slug: ing.slug },
        score: Math.max(score, partial),
      });
    }
    for (const t of topics) {
      const hay = [t.name, ...t.aliases].map(normalise);
      const score = Math.max(...hay.map((h) => similarity(q, h)), 0);
      const partial = hay.some((h) => h.includes(q.slice(0, 3))) ? 0.32 : 0;
      scored.push({ label: t.name, to: "/topic/$slug", params: { slug: t.slug }, score: Math.max(score, partial) });
    }
  }
  const near = scored
    .filter((s) => s.score > 0.2)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
  if (near.length) return near.map(({ label, to, params }) => ({ label, to, params }));
  // Fall back to well-covered starting points rather than showing nothing.
  const fallback = ["niacinamide", "retinol", "hyaluronic-acid", "l-ascorbic-acid"]
    .map((slug) => ingredients.find((i) => i.slug === slug))
    .filter((i): i is (typeof ingredients)[number] => Boolean(i))
    .map((i) => ({ label: i.name, to: "/ingredient/$slug", params: { slug: i.slug } }));
  return fallback.slice(0, limit);
}
