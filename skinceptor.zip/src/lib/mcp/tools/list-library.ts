import { defineTool } from "@lovable.dev/mcp-js";
import { supabaseForUser } from "../supabase";
import { ingredientBySlug } from "@/data/ingredients";
import { topicBySlug } from "@/data/topics";

export default defineTool({
  name: "list_my_library",
  title: "List my saved library",
  description:
    "List the signed-in Skinceptor user's saved ingredients and biology maps, with their private notes, plus their saved searches and saved claims.",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async (_input, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not signed in." }], isError: true };
    }
    const supabase = supabaseForUser(ctx);
    const [items, searches] = await Promise.all([
      supabase.from("library_items").select("item_type, slug, note, created_at").order("created_at", { ascending: false }),
      supabase.from("saved_searches").select("query, label, kind, created_at").order("created_at", { ascending: false }),
    ]);
    if (items.error) return { content: [{ type: "text", text: items.error.message }], isError: true };
    if (searches.error) return { content: [{ type: "text", text: searches.error.message }], isError: true };

    const named = (items.data ?? []).map((i) => ({
      ...i,
      name:
        i.item_type === "ingredient"
          ? ingredientBySlug.get(i.slug)?.name ?? i.slug
          : topicBySlug.get(i.slug)?.name ?? i.slug,
    }));

    const text = [
      named.length ? "Saved items:" : "No saved ingredients or biology maps yet.",
      ...named.map((i) => `- [${i.item_type}] ${i.name} (${i.slug})${i.note ? ` — note: ${i.note}` : ""}`),
      "",
      (searches.data ?? []).length ? "Saved searches and claims:" : "No saved searches or claims yet.",
      ...(searches.data ?? []).map((s) => `- [${s.kind}] ${s.label ?? s.query}`),
    ].join("\n");

    return {
      content: [{ type: "text", text }],
      structuredContent: { items: named, savedSearches: searches.data ?? [] },
    };
  },
});
