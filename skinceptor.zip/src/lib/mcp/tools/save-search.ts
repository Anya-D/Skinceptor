import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "save_search_or_claim",
  title: "Save a search or claim",
  description:
    "Save a research query or a beauty claim to the signed-in Skinceptor user's library so they can revisit it in the app.",
  inputSchema: {
    query: z.string().trim().min(1).max(600).describe("The search text or the claim wording."),
    label: z.string().trim().max(200).nullable().optional().describe("Optional short label."),
    kind: z.enum(["search", "claim"]).describe("'search' for a research query, 'claim' for a beauty claim."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
  handler: async ({ query, label, kind }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not signed in." }], isError: true };
    }
    const supabase = supabaseForUser(ctx);
    const { data, error } = await supabase
      .from("saved_searches")
      .insert({ user_id: ctx.getUserId(), query, label: label ?? null, kind })
      .select("id, query, label, kind")
      .maybeSingle();

    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: `Saved this ${kind} to your Skinceptor library.` }],
      structuredContent: { savedSearch: data },
    };
  },
});
