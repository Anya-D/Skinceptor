import { defineTool, ToolError } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";
import { ingredientBySlug } from "@/data/ingredients";
import { topicBySlug } from "@/data/topics";

export default defineTool({
  name: "save_to_library",
  title: "Save to my library",
  description:
    "Save an ingredient or biology map to the signed-in Skinceptor user's library, optionally with a private note. Saving an item that is already saved updates its note.",
  inputSchema: {
    itemType: z.enum(["ingredient", "topic"]).describe("'ingredient' or 'topic' (a biology map)."),
    slug: z.string().trim().min(1).describe("Slug of the ingredient or biology map."),
    note: z.string().trim().max(2000).nullable().optional().describe("Optional private note to attach."),
  },
  annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
  handler: async ({ itemType, slug, note }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not signed in." }], isError: true };
    }
    const known = itemType === "ingredient" ? ingredientBySlug.get(slug) : topicBySlug.get(slug);
    if (!known) throw new ToolError(`No curated ${itemType} with slug "${slug}".`);

    const supabase = supabaseForUser(ctx);
    const { data, error } = await supabase
      .from("library_items")
      .upsert(
        { user_id: ctx.getUserId(), item_type: itemType, slug, note: note ?? null },
        { onConflict: "user_id,item_type,slug" },
      )
      .select("item_type, slug, note")
      .maybeSingle();

    if (error) return { content: [{ type: "text", text: error.message }], isError: true };
    return {
      content: [{ type: "text", text: `Saved ${known.name} to your Skinceptor library.` }],
      structuredContent: { item: data },
    };
  },
});
