import { defineTool, ToolError } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { ingredientBySlug, ingredients } from "@/data/ingredients";
import { studiesForIngredient } from "@/data/studies";
import { computeEvidence } from "@/lib/evidence";

export default defineTool({
  name: "get_ingredient",
  title: "Get ingredient biology",
  description:
    "Return Skinceptor's curated biology for one ingredient: chemical identity, biological targets with confidence, genes, pathways, cellular processes, the experimental Evidence Index and the curated studies behind it.",
  inputSchema: {
    slug: z
      .string()
      .trim()
      .min(1)
      .describe("Ingredient slug, e.g. 'niacinamide' or 'l-ascorbic-acid'. Use search_biology to resolve names."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ slug }) => {
    const ing = ingredientBySlug.get(slug);
    if (!ing) {
      throw new ToolError(
        `No curated ingredient with slug "${slug}". Known slugs include: ${ingredients
          .slice(0, 12)
          .map((i) => i.slug)
          .join(", ")}…`,
      );
    }
    const studies = studiesForIngredient(slug);
    const evidence = computeEvidence(studies);

    const text = [
      `${ing.name} (${ing.className})`,
      ing.summary,
      "",
      `Chemical identity: formula ${ing.formula ?? "unavailable"}; MW ${
        ing.molecularWeight ? `${ing.molecularWeight} g/mol` : "unavailable"
      }; PubChem CID ${ing.pubchemCid ?? "unavailable"}.`,
      "",
      "Biological targets:",
      ...ing.targets.map((t) => `- ${t.name} (${t.kind}, ${t.relation}) — confidence ${t.confidence}`),
      "",
      "Pathways: " + (ing.pathways.map((p) => p.name).join("; ") || "none curated"),
      "Cellular processes: " + (ing.processes.map((p) => p.name).join("; ") || "none curated"),
      "",
      `Skinceptor Evidence Index (experimental): ${evidence.index}/100, strength ${evidence.strength}, from ${
        evidence.total
      } curated studies (${evidence.humanCount} in humans). Quantitative synthesis ${
        evidence.quantitativeSynthesisPossible ? "possible" : "not possible — insufficient comparable evidence"
      }.`,
      "This index is a research-navigation aid, not a safety, efficacy or clinical rating.",
    ].join("\n");

    return {
      content: [{ type: "text", text }],
      structuredContent: {
        ingredient: ing as never,
        evidence: evidence as never,
        studies: studies.map((s) => ({
          id: s.id,
          title: s.title,
          year: s.year,
          journal: s.journal,
          type: s.type,
          sampleSize: s.sampleSize ?? null,
          pmid: s.pmid ?? null,
          doi: s.doi ?? null,
          finding: s.finding,
          limitations: s.limitations,
        })),
      },
    };
  },
});
