import { defineTool, ToolError } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { topicBySlug, topics } from "@/data/topics";
import { studiesForTopic } from "@/data/studies";
import { ingredients } from "@/data/ingredients";

export default defineTool({
  name: "get_biology_map",
  title: "Get biology map",
  description:
    "Return one Skinceptor biology map (e.g. skin barrier, photoaging, melanogenesis): its overview, genes and proteins, pathways, cellular processes, ingredients studied against it and curated studies.",
  inputSchema: {
    slug: z
      .string()
      .trim()
      .min(1)
      .describe(`Biology map slug. Available: ${topics.map((t) => t.slug).join(", ")}.`),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ slug }) => {
    const topic = topicBySlug.get(slug);
    if (!topic) throw new ToolError(`No biology map "${slug}". Available: ${topics.map((t) => t.slug).join(", ")}.`);

    const related = ingredients.filter((i) => i.topics.includes(slug));
    const studies = studiesForTopic(slug);

    const text = [
      topic.name,
      topic.overview,
      "",
      "Genes / proteins: " + (topic.genes.map((g) => `${g.symbol} (${g.confidence})`).join("; ") || "none curated"),
      "Pathways: " + (topic.pathways.map((p) => p.name).join("; ") || "none curated"),
      "Ingredients studied here: " + (related.map((i) => `${i.name} (${i.slug})`).join("; ") || "none curated"),
      `Curated studies: ${studies.length}.`,
    ].join("\n");

    return {
      content: [{ type: "text", text }],
      structuredContent: {
        topic: topic as never,
        ingredients: related.map((i) => ({ slug: i.slug, name: i.name, className: i.className })),
        studyCount: studies.length,
      },
    };
  },
});
