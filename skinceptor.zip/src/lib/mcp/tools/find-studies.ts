import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { studies } from "@/data/studies";
import { STUDY_TYPE_LABEL } from "@/lib/evidence";

const STUDY_TYPES = ["human", "rct", "animal", "in-vitro", "ex-vivo", "review", "meta-analysis"] as const;

export default defineTool({
  name: "find_studies",
  title: "Find curated studies",
  description:
    "Search Skinceptor's curated literature. Filter by ingredient slug, biology-map slug, study design, or free text over titles, journals and findings. Every record carries its design, sample size where reported, finding and limitations.",
  inputSchema: {
    query: z.string().trim().optional().describe("Free text over title, journal and finding."),
    ingredientSlug: z.string().trim().optional().describe("Restrict to one ingredient slug."),
    topicSlug: z.string().trim().optional().describe("Restrict to one biology-map slug."),
    studyType: z
      .enum(STUDY_TYPES)
      .optional()
      .describe("Restrict to one study design (human, rct, animal, in-vitro, ex-vivo, review, meta-analysis)."),
    limit: z.number().int().min(1).max(50).optional().describe("Maximum records to return (default 15)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ query, ingredientSlug, topicSlug, studyType, limit }) => {
    const q = query?.toLowerCase().trim();
    const matches = studies
      .filter((s) => (ingredientSlug ? s.ingredients.includes(ingredientSlug) : true))
      .filter((s) => (topicSlug ? s.topics.includes(topicSlug) : true))
      .filter((s) => (studyType ? s.type === studyType : true))
      .filter((s) => (q ? `${s.title} ${s.journal} ${s.finding}`.toLowerCase().includes(q) : true))
      .sort((a, b) => b.year - a.year)
      .slice(0, limit ?? 15);

    const text = matches.length
      ? matches
          .map(
            (s) =>
              `- "${s.title}" (${s.year}, ${s.journal}) — ${STUDY_TYPE_LABEL[s.type]}${
                s.sampleSize ? `, n=${s.sampleSize}` : ""
              }${s.pmid ? `, PMID ${s.pmid}` : ""}\n  Finding: ${s.finding}\n  Limitations: ${s.limitations}`,
          )
          .join("\n")
      : "No curated studies match those filters. That is not evidence the claim is false — the curated dataset is limited.";

    return {
      content: [{ type: "text", text }],
      structuredContent: { count: matches.length, studies: matches as never },
    };
  },
});
