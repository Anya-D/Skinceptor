import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { search, isAmbiguous } from "@/lib/search";

export default defineTool({
  name: "search_biology",
  title: "Search Skinceptor biology",
  description:
    "Search Skinceptor's curated dataset for ingredients, biology maps, genes, proteins, pathways and studies. Tolerates synonyms and shorthand such as 'vit b3' or 'HA'.",
  inputSchema: {
    query: z.string().trim().min(1).describe("Free-text query: ingredient, gene, pathway, or beauty topic."),
    limit: z.number().int().min(1).max(30).optional().describe("Maximum results to return (default 12)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ query, limit }) => {
    const results = search(query, limit ?? 12);
    const ambiguous = isAmbiguous(query);
    const lines = results.length
      ? results.map(
          (r) =>
            `- [${r.kind}] ${r.title}${r.params?.["slug"] ? ` (slug: ${r.params["slug"]})` : ""} — ${r.subtitle}`,
        )
      : ["No curated match. Skinceptor covers a curated set of ingredients and biology maps, not every substance."];
    return {
      content: [
        {
          type: "text",
          text: [ambiguous ? `"${query}" is ambiguous; it may mean: ${ambiguous.join(", ")}.` : null, ...lines]
            .filter(Boolean)
            .join("\n"),
        },
      ],
      structuredContent: { query, ambiguous: ambiguous ?? [], results } as never,
    };
  },
});
