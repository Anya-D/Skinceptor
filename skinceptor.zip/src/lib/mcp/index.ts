import { auth, defineMcp } from "@lovable.dev/mcp-js";
import searchBiologyTool from "./tools/search-biology";
import getIngredientTool from "./tools/get-ingredient";
import getBiologyMapTool from "./tools/get-topic";
import findStudiesTool from "./tools/find-studies";
import listMyLibraryTool from "./tools/list-library";
import saveToLibraryTool from "./tools/save-to-library";
import saveSearchTool from "./tools/save-search";

const projectRef = import.meta.env['VITE_SUPABASE_PROJECT_ID'] ?? "project-ref-unset";

export default defineMcp({
  name: "skinceptor",
  title: "skinceptor",
  version: "0.1.0",
  instructions: [
    "Skinceptor is an educational biological-intelligence tool for beauty ingredients. It exposes a curated, cited dataset: ingredient chemistry, biological targets, genes, pathways, cellular processes and human/in-vitro studies.",
    "Use search_biology to resolve a name to a slug, then get_ingredient or get_biology_map. Use find_studies for literature with designs, sample sizes and limitations.",
    "The Skinceptor Evidence Index is experimental and is a research-navigation aid only — never present it as a safety score, efficacy guarantee, or clinical recommendation.",
    "Never turn these results into medical advice, diagnosis or treatment recommendations. Preserve hedged language and cite PMIDs/DOIs where present.",
    "list_my_library, save_to_library and save_search_or_claim act as the signed-in Skinceptor user.",
  ].join(" "),
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [
    searchBiologyTool,
    getIngredientTool,
    getBiologyMapTool,
    findStudiesTool,
    listMyLibraryTool,
    saveToLibraryTool,
    saveSearchTool,
  ],
});
