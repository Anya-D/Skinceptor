import type { BiologyGraph, NodeKind } from "@/data/types";
import { NODE_COLOR_VAR } from "./graph";

/**
 * Deterministic generative art derived from a biology graph.
 *
 * Every coordinate is a pure function of node identifiers, node category and
 * edge structure — the same network always renders the same artwork, and no
 * decorative nodes are invented.
 */

export type ArtStyle = "constellation" | "galaxy" | "tapestry" | "fingerprint";

export const ART_STYLES: { id: ArtStyle; label: string; description: string }[] = [
  { id: "constellation", label: "Constellation", description: "Nodes as stars, edges as hairlines. Radial angle encodes category, radius encodes tier." },
  { id: "galaxy", label: "Pathway galaxy", description: "Logarithmic spiral arms, one arm per biological tier." },
  { id: "tapestry", label: "Cellular tapestry", description: "Woven grid: rows are tiers, cell weight encodes confidence." },
  { id: "fingerprint", label: "Ingredient fingerprint", description: "Concentric ridges displaced by the network's own structure — a visual signature." },
];

/** Deterministic 32-bit string hash. */
function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) / 4294967295;
}

export interface ArtPoint {
  id: string;
  label: string;
  kind: NodeKind;
  x: number;
  y: number;
  r: number;
  color: string;
  opacity: number;
}

export interface ArtLine {
  id: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  opacity: number;
}

export interface ArtRing {
  id: string;
  d: string;
  opacity: number;
  color: string;
}

export interface Artwork {
  size: number;
  points: ArtPoint[];
  lines: ArtLine[];
  rings: ArtRing[];
  seedSummary: string;
}

const CONF_OPACITY = { HIGH: 0.95, MEDIUM: 0.6, LOW: 0.32 } as const;

export function generateArtwork(graph: BiologyGraph, style: ArtStyle, seed: string, size = 720): Artwork {
  const cx = size / 2;
  const cy = size / 2;
  const maxTier = Math.max(1, ...graph.nodes.map((n) => n.tier));
  const base = hash(seed);
  const points: ArtPoint[] = [];
  const rings: ArtRing[] = [];

  graph.nodes.forEach((n, i) => {
    const h1 = hash(n.id);
    const h2 = hash(`${n.id}:${seed}`);
    const tierNorm = n.tier / maxTier;
    let x: number;
    let y: number;
    let r = 3 + tierNorm * 4 + h1 * 3;

    if (style === "constellation") {
      const angle = (h1 * Math.PI * 2 + base * Math.PI * 2) % (Math.PI * 2);
      const radius = 40 + tierNorm * (size * 0.4) + h2 * 26;
      x = cx + Math.cos(angle) * radius;
      y = cy + Math.sin(angle) * radius;
    } else if (style === "galaxy") {
      const arm = n.tier;
      const t = 0.35 + h1 * 1.4 + i * 0.012;
      const angle = arm * ((Math.PI * 2) / (maxTier + 1)) + t * 1.9 + base;
      const radius = 26 + t * (size * 0.2);
      x = cx + Math.cos(angle) * radius;
      y = cy + Math.sin(angle) * radius * 0.86;
      r = 2.4 + h2 * 4.5;
    } else if (style === "tapestry") {
      const cols = Math.max(3, Math.ceil(graph.nodes.length / (maxTier + 1)));
      const rowNodes = graph.nodes.filter((m) => m.tier === n.tier);
      const idx = rowNodes.findIndex((m) => m.id === n.id);
      x = 60 + ((idx + 0.5) / Math.max(1, rowNodes.length)) * (size - 120) + (h1 - 0.5) * 14;
      y = 60 + (n.tier / maxTier) * (size - 120) + (h2 - 0.5) * 10;
      r = 3 + (cols > 6 ? 2 : 4) + h1 * 3;
    } else {
      // fingerprint: nodes ride concentric ridges, displaced by their own hash
      const ridge = 1 + (n.tier % 6);
      const angle = h1 * Math.PI * 2;
      const radius = 42 + ridge * 34 + Math.sin(angle * 3 + base * 6) * 12 + h2 * 8;
      x = cx + Math.cos(angle) * radius;
      y = cy + Math.sin(angle) * radius;
      r = 2 + h2 * 3.4;
    }

    points.push({
      id: n.id,
      label: n.label,
      kind: n.kind,
      x,
      y,
      r,
      color: NODE_COLOR_VAR[n.kind],
      opacity: CONF_OPACITY[n.confidence],
    });
  });

  const byId = new Map(points.map((p) => [p.id, p]));
  const lines: ArtLine[] = graph.edges
    .map((e) => {
      const a = byId.get(e.source);
      const b = byId.get(e.target);
      if (!a || !b) return null;
      return {
        id: e.id,
        x1: a.x,
        y1: a.y,
        x2: b.x,
        y2: b.y,
        opacity: CONF_OPACITY[e.confidence] * 0.45,
      } satisfies ArtLine;
    })
    .filter((l): l is ArtLine => l !== null);

  if (style === "fingerprint") {
    // Ridge geometry is displaced by the number of nodes per tier, so the
    // silhouette differs for every ingredient network.
    for (let ridge = 1; ridge <= 6; ridge++) {
      const tierCount = graph.nodes.filter((n) => n.tier === ridge - 1).length;
      const amp = 6 + tierCount * 2.4;
      const steps = 160;
      let d = "";
      for (let s = 0; s <= steps; s++) {
        const a = (s / steps) * Math.PI * 2;
        const rad = 42 + ridge * 34 + Math.sin(a * (2 + ridge) + base * 6) * amp;
        const px = cx + Math.cos(a) * rad;
        const py = cy + Math.sin(a) * rad;
        d += `${s === 0 ? "M" : "L"}${px.toFixed(2)},${py.toFixed(2)} `;
      }
      rings.push({ id: `ridge-${ridge}`, d: `${d}Z`, opacity: 0.16 + ridge * 0.035, color: "var(--accent)" });
    }
  }

  if (style === "galaxy") {
    for (let arm = 0; arm <= maxTier; arm++) {
      const steps = 90;
      let d = "";
      for (let s = 0; s <= steps; s++) {
        const t = 0.3 + (s / steps) * 1.6;
        const angle = arm * ((Math.PI * 2) / (maxTier + 1)) + t * 1.9 + base;
        const radius = 26 + t * (size * 0.2);
        const px = cx + Math.cos(angle) * radius;
        const py = cy + Math.sin(angle) * radius * 0.86;
        d += `${s === 0 ? "M" : "L"}${px.toFixed(2)},${py.toFixed(2)} `;
      }
      rings.push({ id: `arm-${arm}`, d, opacity: 0.18, color: "var(--brand)" });
    }
  }

  return {
    size,
    points,
    lines,
    rings,
    seedSummary: `${graph.nodes.length} nodes · ${graph.edges.length} relationships · seed "${seed}"`,
  };
}

/** Serialise an SVG element to a downloadable PNG data URL (browser only). */
export async function svgToPngBlob(svg: SVGSVGElement, size = 1440): Promise<Blob> {
  const clone = svg.cloneNode(true) as SVGSVGElement;
  const computed = getComputedStyle(document.documentElement);
  // Inline the design tokens the artwork references so the export is self-contained.
  const vars = ["--accent", "--brand", "--violet", "--rose", "--amber", "--fog", "--ink"];
  const style = document.createElement("style");
  style.textContent = `:root{${vars.map((v) => `${v}:${computed.getPropertyValue(v).trim()}`).join(";")}}`;
  clone.insertBefore(style, clone.firstChild);
  clone.setAttribute("width", String(size));
  clone.setAttribute("height", String(size));
  const xml = new XMLSerializer().serializeToString(clone);
  const url = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(xml)}`;

  const img = new Image();
  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => reject(new Error("Artwork export failed"));
    img.src = url;
  });
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable");
  ctx.fillStyle = computed.getPropertyValue("--ink").trim() || "#080d1a";
  ctx.fillRect(0, 0, size, size);
  ctx.drawImage(img, 0, 0, size, size);
  return new Promise((resolve, reject) =>
    canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error("Artwork export failed"))), "image/png"),
  );
}
