/** Builders for links into public scientific databases. No API keys required. */

export const externalLink = {
  pubchem: (cid: string) => `https://pubchem.ncbi.nlm.nih.gov/compound/${cid}`,
  pubchemImage: (cid: string) =>
    `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/${cid}/PNG?record_type=2d&image_size=500x500`,
  uniprot: (id: string) => `https://www.uniprot.org/uniprotkb/${id}/entry`,
  ncbiGene: (id: string) => `https://www.ncbi.nlm.nih.gov/gene/${id}`,
  reactome: (id: string) => `https://reactome.org/content/detail/${id}`,
  geneOntology: (id: string) => `https://www.ebi.ac.uk/QuickGO/term/${id}`,
  chebi: (id: string) => `https://www.ebi.ac.uk/chebi/searchId.do?chebiId=${id}`,
  pubmed: (pmid: string) => `https://pubmed.ncbi.nlm.nih.gov/${pmid}/`,
  doi: (doi: string) => `https://doi.org/${doi}`,
  europePmcSearch: (title: string) =>
    `https://europepmc.org/search?query=${encodeURIComponent(`"${title}"`)}`,
};

export function sourceUrl(db: string, id: string): string {
  switch (db) {
    case "PubChem":
      return externalLink.pubchem(id);
    case "UniProt":
      return externalLink.uniprot(id);
    case "NCBI Gene":
      return externalLink.ncbiGene(id);
    case "Reactome":
      return externalLink.reactome(id);
    case "Gene Ontology":
      return externalLink.geneOntology(id);
    case "ChEBI":
      return externalLink.chebi(id);
    case "PubMed":
      return externalLink.pubmed(id);
    default:
      return `https://europepmc.org/search?query=${encodeURIComponent(id)}`;
  }
}
