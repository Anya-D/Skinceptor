import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type ReviewRole = "admin" | "reviewer";

/** Roles held by the signed-in account. Empty array for ordinary readers. */
export const listMyRoles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase.from("user_roles").select("role");
    if (error) throw new Error(error.message);
    return (data ?? []).map((r) => r.role as ReviewRole);
  });

async function assertReviewer(context: { supabase: any; userId: string }) {
  const { data, error } = await context.supabase.from("user_roles").select("role").eq("user_id", context.userId);
  if (error) throw new Error(error.message);
  const roles = (data ?? []).map((r: { role: string }) => r.role);
  if (!roles.includes("reviewer") && !roles.includes("admin")) {
    throw new Error("You do not have reviewer access.");
  }
}

const STATUSES = ["pending", "approved", "rejected"] as const;

export const listSubmissionsForReview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { status?: string }) => ({
    status: (STATUSES as readonly string[]).includes(input?.status ?? "") ? (input.status as string) : "pending",
  }))
  .handler(async ({ data, context }) => {
    await assertReviewer(context);
    const { data: rows, error } = await context.supabase
      .from("evidence_submissions")
      .select(
        "id, title, journal, year, study_type, sample_size, pmid, doi, url, summary, limitations, status, review_note, ingredient_slug, topic_slug, submitter_label, created_at, updated_at",
      )
      .eq("status", data.status)
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const reviewSubmission = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string; status: string; reviewNote?: string }) => {
    if (!input?.id) throw new Error("Missing submission.");
    if (input.status !== "approved" && input.status !== "rejected" && input.status !== "pending") {
      throw new Error("Invalid review decision.");
    }
    return {
      id: input.id,
      status: input.status,
      reviewNote: input.reviewNote?.trim() ? input.reviewNote.trim().slice(0, 1000) : null,
    };
  })
  .handler(async ({ data, context }) => {
    await assertReviewer(context);
    const { data: row, error } = await context.supabase
      .from("evidence_submissions")
      .update({ status: data.status, review_note: data.reviewNote })
      .eq("id", data.id)
      .select("id, status, review_note")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const reviewCounts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertReviewer(context);
    const out: Record<string, number> = { pending: 0, approved: 0, rejected: 0 };
    for (const status of STATUSES) {
      const { count, error } = await context.supabase
        .from("evidence_submissions")
        .select("id", { count: "exact", head: true })
        .eq("status", status);
      if (error) throw new Error(error.message);
      out[status] = count ?? 0;
    }
    return out;
  });
