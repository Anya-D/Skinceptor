/**
 * Plain-English glossary.
 *
 * Every entry translates a technical term used in the curated dataset into
 * everyday language. Translations are descriptive only — they never add a
 * benefit claim, a dose, or a clinical recommendation that the underlying
 * scientific record does not support.
 */

export interface GlossaryEntry {
  /** Canonical technical term as a reader would meet it in the text. */
  term: string;
  /** Extra spellings / abbreviations that should also be translatable. */
  aliases?: string[];
  /** Short, everyday-English explanation. One or two plain sentences. */
  plain: string;
}

export const glossary: GlossaryEntry[] = [
  // ---- structure & anatomy
  { term: "stratum corneum", plain: "The outermost layer of skin — flat, dead cells packed with fats. It is the part that holds water in and keeps irritants out." },
  { term: "epidermis", plain: "The thin top part of the skin you can see and touch." },
  { term: "dermis", plain: "The thicker layer underneath the surface, where collagen, blood vessels and hair roots sit." },
  { term: "corneocyte", aliases: ["corneocytes"], plain: "A flattened, dead surface skin cell — one of the 'bricks' of the outer layer." },
  { term: "keratinocyte", aliases: ["keratinocytes"], plain: "The main type of skin cell. It is made deep in the epidermis and slowly moves up to the surface." },
  { term: "fibroblast", aliases: ["fibroblasts"], plain: "A cell in the deeper skin layer that builds collagen and other support material." },
  { term: "melanocyte", aliases: ["melanocytes"], plain: "The cell that makes skin pigment and hands it to neighbouring skin cells." },
  { term: "melanosome", aliases: ["melanosomes"], plain: "A tiny package of pigment that a pigment cell passes to surrounding skin cells." },
  { term: "sebaceous gland", aliases: ["sebaceous glands", "sebaceous"], plain: "The small gland attached to a pore that makes skin oil." },
  { term: "sebum", plain: "The natural oil your skin makes." },
  { term: "dermal papilla", plain: "The cluster of cells at the base of a hair follicle that signals the hair to grow." },
  { term: "hair follicle", aliases: ["follicle", "follicles", "follicular"], plain: "The pocket in the skin that a hair grows out of." },
  { term: "anagen", plain: "The active growing phase of a hair." },
  { term: "telogen", plain: "The resting phase of a hair, before it is shed." },
  { term: "extracellular matrix", aliases: ["matrix organisation", "extracellular matrix organisation"], plain: "The mesh of collagen and other material between cells that gives skin its firmness and bounce." },
  { term: "basement membrane", plain: "The thin sheet that glues the top layer of skin to the layer below it." },

  // ---- molecules & proteins
  { term: "collagen", plain: "The main structural protein in skin. It works like scaffolding that keeps skin firm." },
  { term: "procollagen", plain: "The unfinished form of collagen that cells release before it is assembled into fibres." },
  { term: "elastin", plain: "A stretchy protein that lets skin spring back after it is pulled." },
  { term: "keratin", plain: "The tough protein that makes up hair, nails and the skin's surface cells." },
  { term: "filaggrin", aliases: ["FLG"], plain: "A protein that helps pack surface skin cells tightly together and helps skin hold water." },
  { term: "ceramide", aliases: ["ceramides"], plain: "A fat that fills the gaps between surface skin cells, like mortar between bricks." },
  { term: "lipid", aliases: ["lipids"], plain: "A fat. In skin, fats seal the surface so water does not escape." },
  { term: "hyaluronic acid", plain: "A large sugar-like molecule that holds a lot of water. Skin makes it naturally." },
  { term: "glycosaminoglycan", aliases: ["glycosaminoglycans"], plain: "A water-holding sugar chain found in the deeper layers of skin." },
  { term: "peptide", aliases: ["peptides"], plain: "A very short chain of amino acids — a small fragment of a protein." },
  { term: "amino acid", aliases: ["amino acids"], plain: "One of the building blocks that proteins are made from." },
  { term: "enzyme", aliases: ["enzymes"], plain: "A protein that speeds up one specific chemical reaction in the body." },
  { term: "receptor", aliases: ["receptors"], plain: "A protein that acts like a lock: when the right molecule fits it, the cell changes what it is doing." },
  { term: "transporter", plain: "A protein that carries a substance across a cell's outer wall." },
  { term: "cofactor", plain: "A helper molecule an enzyme needs in order to work." },
  { term: "substrate", plain: "The starting material that an enzyme acts on." },
  { term: "precursor", plain: "An earlier form of a molecule that the body converts into the active version." },
  { term: "metabolite", aliases: ["metabolites"], plain: "A molecule produced when the body breaks down or converts something else." },
  { term: "molecular weight", plain: "How heavy a single molecule is. Smaller molecules can generally move through skin more easily." },
  { term: "tyrosinase", plain: "The key enzyme that skin uses to make pigment." },
  { term: "matrix metalloproteinase", aliases: ["matrix metallopeptidase", "MMP", "MMP1", "MMPs"], plain: "An enzyme that breaks down collagen and other support material in skin." },
  { term: "aquaporin", aliases: ["aquaporin 3", "AQP3"], plain: "A channel that lets water pass in and out of a cell." },
  { term: "sirtuin", aliases: ["sirtuins", "SIRT1"], plain: "A family of proteins involved in how cells respond to stress and energy levels." },
  { term: "NAD+", aliases: ["NAD", "nicotinamide adenine dinucleotide"], plain: "A helper molecule cells need to release energy from food and to run repair processes." },
  { term: "5-alpha reductase", aliases: ["SRD5A1", "5α-reductase"], plain: "An enzyme that converts testosterone into a stronger hormone linked to oil production and hair thinning." },
  { term: "retinoic acid receptor", aliases: ["RAR", "RARA", "RARG", "RARB"], plain: "The switch inside a skin cell that vitamin A signals attach to in order to change which genes are read." },
  { term: "nuclear receptor", plain: "A protein inside the cell that, once switched on, directly turns genes up or down." },
  { term: "growth factor", aliases: ["growth factors"], plain: "A signalling molecule that tells cells to grow, divide or repair." },
  { term: "cytokine", aliases: ["cytokines"], plain: "A messenger molecule immune cells use to signal each other — often part of inflammation." },
  { term: "prostaglandin", aliases: ["prostaglandins"], plain: "A local signalling molecule involved in redness, swelling and pain." },
  { term: "free radical", aliases: ["free radicals", "reactive oxygen species", "ROS"], plain: "An unstable molecule that damages cell parts by stealing electrons from them." },
  { term: "antioxidant", aliases: ["antioxidants"], plain: "A molecule that absorbs the damage from unstable molecules so cells take less of it." },

  // ---- processes & pathways
  { term: "pathway", aliases: ["pathways", "signalling pathway", "signaling pathway"], plain: "A chain of molecular steps inside cells — one thing switches on the next, like a relay." },
  { term: "gene expression", aliases: ["transcription", "gene transcription"], plain: "The process of a cell reading a gene and using it to make a protein." },
  { term: "upregulate", aliases: ["upregulation", "upregulated"], plain: "To increase how much of something a cell makes." },
  { term: "downregulate", aliases: ["downregulation", "downregulated"], plain: "To reduce how much of something a cell makes." },
  { term: "inhibit", aliases: ["inhibits", "inhibition", "inhibitor"], plain: "To slow down or block something from working." },
  { term: "activate", aliases: ["activates", "activation"], plain: "To switch something on or make it work harder." },
  { term: "modulate", aliases: ["modulates", "modulation"], plain: "To nudge something up or down rather than fully switching it on or off." },
  { term: "melanogenesis", plain: "The process of making skin pigment." },
  { term: "melanin", plain: "The pigment that gives skin, hair and eyes their colour." },
  { term: "keratinocyte differentiation", aliases: ["differentiation", "epidermal differentiation"], plain: "The way a young skin cell matures step by step as it travels up to become part of the surface layer." },
  { term: "proliferation", aliases: ["keratinocyte proliferation", "cell proliferation"], plain: "Cells dividing to make more cells." },
  { term: "desquamation", plain: "The natural shedding of dead surface skin cells." },
  { term: "epidermal turnover", aliases: ["cell turnover", "epidermal cell turnover", "skin cell turnover"], plain: "How long it takes for new skin cells to travel to the surface and replace the old ones." },
  { term: "keratolytic", plain: "Loosens the bonds holding dead surface cells together so they shed more easily." },
  { term: "transepidermal water loss", aliases: ["TEWL"], plain: "How much water evaporates out through the skin. Lower usually means a better-sealed surface." },
  { term: "barrier function", aliases: ["skin barrier", "epidermal barrier", "barrier formation", "epidermal barrier formation"], plain: "How well the skin's surface keeps water in and irritants out." },
  { term: "oxidative stress", plain: "The wear and tear on cells caused when unstable molecules build up faster than the body can neutralise them." },
  { term: "photoaging", aliases: ["photoageing", "photodamage"], plain: "The changes in skin — lines, roughness, uneven tone — that build up from years of sun exposure." },
  { term: "inflammation", aliases: ["inflammatory", "anti-inflammatory"], plain: "The body's response to injury or irritation: redness, heat, swelling and discomfort." },
  { term: "erythema", plain: "Visible redness of the skin." },
  { term: "collagen biosynthesis", aliases: ["collagen synthesis"], plain: "Cells building new collagen." },
  { term: "apoptosis", plain: "A controlled, tidy form of cell death the body uses to remove damaged cells." },
  { term: "autophagy", plain: "A cell's recycling process, where it breaks down and reuses its own worn-out parts." },
  { term: "metabolism", aliases: ["cellular energy metabolism", "energy metabolism"], plain: "All the chemical work a cell does to make and use energy." },
  { term: "sebogenesis", aliases: ["sebaceous lipid production", "lipogenesis"], plain: "The making of skin oil." },
  { term: "antimicrobial", plain: "Reduces the number of bacteria or other microbes." },
  { term: "comedogenic", plain: "Tends to block pores." },
  { term: "penetration", aliases: ["skin penetration", "percutaneous absorption"], plain: "How far a substance gets into the skin after it is applied." },
  { term: "bioavailability", plain: "How much of a substance actually reaches the place in the body where it could act." },
  { term: "chelate", aliases: ["chelation", "chelating"], plain: "Grabs hold of metal ions so they cannot cause damage." },
  { term: "pH", plain: "How acidic or alkaline something is. Healthy skin surface is slightly acidic." },
  { term: "hydrolysis", plain: "Splitting a molecule apart using water." },
  { term: "oxidation", plain: "A chemical change caused by losing electrons — the same kind of reaction that browns a cut apple." },

  // ---- evidence & study language
  { term: "in vitro", aliases: ["in-vitro"], plain: "Done in a dish or test tube using cells, not on living people. Useful for mechanism, weaker for real-life results." },
  { term: "in vivo", aliases: ["in-vivo"], plain: "Done in a living body rather than in a dish." },
  { term: "ex vivo", aliases: ["ex-vivo"], plain: "Done on living tissue that has been removed from the body, such as donated skin." },
  { term: "randomised controlled trial", aliases: ["randomized controlled trial", "RCT"], plain: "A study where people are randomly split into groups, so differences are less likely to be down to chance or wishful thinking." },
  { term: "placebo", aliases: ["vehicle control", "vehicle"], plain: "A look-alike product with no active ingredient, used for comparison." },
  { term: "double-blind", aliases: ["double blind"], plain: "Neither the participants nor the researchers know who got the real product until the study ends." },
  { term: "meta-analysis", plain: "A study that statistically pools the results of many earlier studies." },
  { term: "systematic review", aliases: ["review"], plain: "A structured summary of everything published on a question." },
  { term: "sample size", aliases: ["n ="], plain: "How many people or samples were studied. Small numbers make results less reliable." },
  { term: "statistically significant", aliases: ["significance", "p-value", "p value"], plain: "The result is unlikely to be pure chance. It does not by itself mean the effect is large or noticeable." },
  { term: "confidence tier", aliases: ["confidence"], plain: "How solid the evidence is for this specific link: high, medium or low." },
  { term: "mechanism", aliases: ["mechanism of action"], plain: "The step-by-step story of how something could work in the body." },
  { term: "endpoint", aliases: ["endpoints"], plain: "The specific thing a study measured, such as redness, water loss or wrinkle depth." },
  { term: "dose-dependent", aliases: ["dose dependent"], plain: "The effect gets stronger or weaker as the amount used changes." },
  { term: "bioinformatics", plain: "Using computers to make sense of biological data." },
  { term: "PMID", plain: "The ID number a study has in PubMed, the public medical research library." },
  { term: "DOI", plain: "A permanent web address for a published paper." },
  { term: "UniProt", plain: "A public database of proteins." },
  { term: "PubChem", plain: "A public database of chemicals and their properties." },
  { term: "Reactome", plain: "A public database that maps out biological pathways." },
  { term: "Gene Ontology", plain: "A shared vocabulary scientists use to label what genes do." },
  { term: "INCI", plain: "The standard international naming system used on cosmetic ingredient lists." },
];

/** Lookup table: normalized surface form → entry. */
const lookup = new Map<string, GlossaryEntry>();
for (const entry of glossary) {
  for (const form of [entry.term, ...(entry.aliases ?? [])]) {
    lookup.set(form.toLowerCase(), entry);
  }
}

function escapeRegex(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Longest forms first so "epidermal barrier formation" wins over "barrier". */
const allForms = [...lookup.keys()].sort((a, b) => b.length - a.length);
const pattern = new RegExp(`(?<![\\p{L}\\d-])(${allForms.map(escapeRegex).join("|")})(?![\\p{L}\\d-])`, "giu");

export interface GlossarySegment {
  text: string;
  entry?: GlossaryEntry;
}

/** Splits text into plain segments and translatable glossary segments. */
export function segmentGlossary(text: string): GlossarySegment[] {
  if (!text) return [];
  const segments: GlossarySegment[] = [];
  let cursor = 0;
  pattern.lastIndex = 0;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(text)) !== null) {
    const entry = lookup.get(match[0].toLowerCase());
    if (!entry) continue;
    if (match.index > cursor) segments.push({ text: text.slice(cursor, match.index) });
    segments.push({ text: match[0], entry });
    cursor = match.index + match[0].length;
  }
  if (cursor < text.length) segments.push({ text: text.slice(cursor) });
  return segments;
}

export function lookupTerm(text: string): GlossaryEntry | undefined {
  return lookup.get(text.trim().toLowerCase());
}

export const glossarySize = glossary.length;
