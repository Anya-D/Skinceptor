import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

/* ------------------------------------------------------------------ */
/* Saved searches                                                      */
/* ------------------------------------------------------------------ */

export const listSavedSearches = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("saved_searches")
      .select("id, query, label, kind, created_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const saveSearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { query: string; label?: string | null; kind?: string }) => {
    const query = input.query?.trim();
    if (!query) throw new Error("Enter something to save first.");
    return {
      query: query.slice(0, 500),
      label: input.label?.trim() ? input.label.trim().slice(0, 120) : null,
      kind: input.kind === "claim" ? "claim" : "search",
    };
  })
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("saved_searches")
      .insert({ ...data, user_id: context.userId })
      .select("id, query, label, kind, created_at")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteSavedSearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => ({ id: input.id }))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("saved_searches").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ------------------------------------------------------------------ */
/* Personal library                                                    */
/* ------------------------------------------------------------------ */

export const listLibrary = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("library_items")
      .select("id, item_type, slug, note, created_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const toggleLibraryItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { itemType: "ingredient" | "topic"; slug: string }) => {
    if (input.itemType !== "ingredient" && input.itemType !== "topic") {
      throw new Error("Unsupported item type.");
    }
    if (!input.slug) throw new Error("Missing item.");
    return { itemType: input.itemType, slug: input.slug };
  })
  .handler(async ({ data, context }) => {
    const existing = await context.supabase
      .from("library_items")
      .select("id")
      .eq("item_type", data.itemType)
      .eq("slug", data.slug)
      .maybeSingle();
    if (existing.error) throw new Error(existing.error.message);

    if (existing.data) {
      const { error } = await context.supabase.from("library_items").delete().eq("id", existing.data.id);
      if (error) throw new Error(error.message);
      return { saved: false };
    }

    const { error } = await context.supabase
      .from("library_items")
      .insert({ user_id: context.userId, item_type: data.itemType, slug: data.slug });
    if (error) throw new Error(error.message);
    return { saved: true };
  });

export const updateLibraryNote = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string; note: string }) => ({
    id: input.id,
    note: input.note.slice(0, 2000),
  }))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("library_items")
      .update({ note: data.note || null })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* ------------------------------------------------------------------ */
/* Evidence submissions                                                */
/* ------------------------------------------------------------------ */

const STUDY_TYPES = ["human", "rct", "animal", "in-vitro", "review", "meta-analysis", "other"] as const;

export const submitEvidence = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: {
      title: string;
      summary: string;
      ingredientSlug?: string;
      topicSlug?: string;
      journal?: string;
      year?: string;
      studyType?: string;
      sampleSize?: string;
      pmid?: string;
      doi?: string;
      url?: string;
      limitations?: string;
      submitterLabel?: string;
    }) => {
      const title = input.title?.trim();
      const summary = input.summary?.trim();
      if (!title) throw new Error("A study title or citation is required.");
      if (!summary) throw new Error("Describe the reported finding.");
      if (!input.ingredientSlug && !input.topicSlug) {
        throw new Error("Link the study to an ingredient or a biology map.");
      }
      const year = input.year ? Number(input.year) : NaN;
      const sample = input.sampleSize ? Number(input.sampleSize) : NaN;
      return {
        title: title.slice(0, 400),
        summary: summary.slice(0, 2000),
        ingredient_slug: input.ingredientSlug || null,
        topic_slug: input.topicSlug || null,
        journal: input.journal?.trim() ? input.journal.trim().slice(0, 200) : null,
        year: Number.isFinite(year) && year > 1800 && year < 2100 ? year : null,
        study_type: (STUDY_TYPES as readonly string[]).includes(input.studyType ?? "")
          ? (input.studyType as string)
          : "other",
        sample_size: Number.isFinite(sample) && sample > 0 ? Math.round(sample) : null,
        pmid: input.pmid?.trim() ? input.pmid.trim().slice(0, 40) : null,
        doi: input.doi?.trim() ? input.doi.trim().slice(0, 200) : null,
        url: input.url?.trim().startsWith("http") ? input.url.trim().slice(0, 500) : null,
        limitations: input.limitations?.trim() ? input.limitations.trim().slice(0, 1000) : null,
        submitter_label: input.submitterLabel?.trim() ? input.submitterLabel.trim().slice(0, 80) : null,
      };
    },
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("evidence_submissions")
      .insert({ ...data, user_id: context.userId, status: "pending" })
      .select("id, title, status, created_at")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const listMySubmissions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("evidence_submissions")
      .select(
        "id, title, journal, year, study_type, sample_size, pmid, doi, url, summary, limitations, status, review_note, ingredient_slug, topic_slug, created_at",
      )
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const deleteSubmission = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => ({ id: input.id }))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("evidence_submissions").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Public read of community evidence that has passed review. */
export const listApprovedEvidence = createServerFn({ method: "GET" })
  .inputValidator((input: { ingredientSlug?: string; topicSlug?: string }) => ({
    ingredientSlug: input?.ingredientSlug ?? undefined,
    topicSlug: input?.topicSlug ?? undefined,
  }))
  .handler(async ({ data }) => {
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
    const supabasePublic = createClient<Database>(process.env["SUPABASE_URL"]!, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });

    let query = supabasePublic
      .from("evidence_submissions")
      .select(
        "id, title, journal, year, study_type, sample_size, pmid, doi, url, summary, limitations, submitter_label, created_at",
      )
      .eq("status", "approved")
      .order("created_at", { ascending: false })
      .limit(25);
    if (data.ingredientSlug) query = query.eq("ingredient_slug", data.ingredientSlug);
    if (data.topicSlug) query = query.eq("topic_slug", data.topicSlug);

    const { data: rows, error } = await query;
    if (error) return [];
    return rows ?? [];
  });
