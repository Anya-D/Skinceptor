import type {
  BiologyGraph,
  Confidence,
  GraphEdge,
  GraphNode,
  Ingredient,
  NodeKind,
  Topic,
} from "@/data/types";
import { externalLink } from "./links";

const CONF_RANK: Record<Confidence, number> = { HIGH: 3, MEDIUM: 2, LOW: 1 };

export const TIER_LABELS = [
  "Ingredient",
  "Molecule",
  "Target",
  "Gene / Protein",
  "Pathway",
  "Process",
  "Outcome",
] as const;

export const NODE_COLOR_VAR: Record<NodeKind, string> = {
  ingredient: "var(--violet)",
  molecule: "var(--brand)",
  target: "var(--rose)",
  gene: "var(--accent)",
  protein: "var(--accent)",
  pathway: "var(--accent)",
  process: "var(--amber)",
  outcome: "var(--fog)",
};

const id = (kind: string, label: string) =>
  `${kind}:${label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}`;

/**
 * Build the ingredient → molecule → target → gene → pathway → process → outcome
 * chain. Only relationships present in the curated dataset are emitted; nothing
 * is inferred to make the graph look fuller.
 */
export function buildIngredientGraph(ing: Ingredient): BiologyGraph {
  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];
  const seen = new Set<string>();

  const push = (n: GraphNode) => {
    if (seen.has(n.id)) return;
    seen.add(n.id);
    nodes.push(n);
  };
  const link = (source: string, target: string, relation: GraphEdge["relation"], confidence: Confidence) => {
    const eid = `${source}->${target}:${relation}`;
    if (edges.some((e) => e.id === eid)) return;
    edges.push({ id: eid, source, target, relation, confidence });
  };

  const rootId = id("ingredient", ing.slug);
  push({
    id: rootId,
    label: ing.name,
    kind: "ingredient",
    tier: 0,
    confidence: "HIGH",
    detail: ing.summary,
    externalId: ing.pubchemCid ? `PubChem ${ing.pubchemCid}` : undefined,
    href: ing.pubchemCid ? externalLink.pubchem(ing.pubchemCid) : undefined,
  });

  for (const m of ing.molecules) {
    const mid = id("molecule", m.name);
    push({
      id: mid,
      label: m.name,
      kind: "molecule",
      tier: 1,
      confidence: "HIGH",
      detail: [m.formula, m.molecularWeight ? `${m.molecularWeight} g/mol` : null, m.note]
        .filter(Boolean)
        .join(" · "),
      externalId: m.pubchemCid ? `PubChem ${m.pubchemCid}` : undefined,
      href: m.pubchemCid ? externalLink.pubchem(m.pubchemCid) : undefined,
    });
    link(rootId, mid, "is molecule", "HIGH");
  }

  const firstMolecule = ing.molecules[0] ? id("molecule", ing.molecules[0].name) : rootId;

  for (const t of ing.targets) {
    const tid = id("target", t.name);
    push({
      id: tid,
      label: t.name,
      kind: "target",
      tier: 2,
      confidence: t.confidence,
      detail: [t.kind, t.note].filter(Boolean).join(" · "),
      externalId: t.uniprot ? `UniProt ${t.uniprot}` : undefined,
      href: t.uniprot ? externalLink.uniprot(t.uniprot) : undefined,
    });
    link(firstMolecule, tid, t.relation, t.confidence);
  }

  for (const g of ing.genes) {
    const gid = id("gene", g.symbol);
    push({
      id: gid,
      label: g.symbol,
      kind: "gene",
      tier: 3,
      confidence: g.confidence,
      detail: g.name,
      externalId: g.uniprot ? `UniProt ${g.uniprot}` : g.ncbiGene ? `Gene ${g.ncbiGene}` : undefined,
      href: g.uniprot ? externalLink.uniprot(g.uniprot) : g.ncbiGene ? externalLink.ncbiGene(g.ncbiGene) : undefined,
    });
    // Link a gene to its protein target when the curated UniProt accession matches.
    const match = ing.targets.find((t) => t.uniprot && t.uniprot === g.uniprot);
    if (match) link(id("target", match.name), gid, "encoded by", g.confidence);
    else if (ing.targets[0]) link(id("target", ing.targets[0].name), gid, "associated with", "LOW");
  }

  for (const p of ing.pathways) {
    const pid = id("pathway", p.name);
    push({
      id: pid,
      label: p.name,
      kind: "pathway",
      tier: 4,
      confidence: p.confidence,
      detail: p.summary,
      externalId: p.id ? `${p.db} ${p.id}` : p.db,
      href: p.id
        ? p.db === "Reactome"
          ? externalLink.reactome(p.id)
          : p.db === "Gene Ontology"
            ? externalLink.geneOntology(p.id)
            : undefined
        : undefined,
    });
    for (const g of ing.genes) link(id("gene", g.symbol), pid, "participates in", lower(g.confidence, p.confidence));
  }

  for (const pr of ing.processes) {
    const prid = id("process", pr.name);
    push({
      id: prid,
      label: pr.name,
      kind: "process",
      tier: 5,
      confidence: pr.confidence,
      detail: pr.tissue ? `Tissue: ${pr.tissue}` : undefined,
      externalId: pr.goId,
      href: pr.goId ? externalLink.geneOntology(pr.goId) : undefined,
    });
    for (const p of ing.pathways) link(id("pathway", p.name), prid, "associated with", lower(p.confidence, pr.confidence));
  }

  for (const o of ing.outcomes) {
    const oid = id("outcome", o.name);
    push({ id: oid, label: o.name, kind: "outcome", tier: 6, confidence: o.confidence });
    for (const pr of ing.processes) link(id("process", pr.name), oid, "studied in", lower(pr.confidence, o.confidence));
  }

  return { nodes, edges };
}

export function buildTopicGraph(topic: Topic): BiologyGraph {
  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];
  const seen = new Set<string>();
  const push = (n: GraphNode) => {
    if (!seen.has(n.id)) {
      seen.add(n.id);
      nodes.push(n);
    }
  };
  const link = (s: string, t: string, relation: GraphEdge["relation"], confidence: Confidence) => {
    const eid = `${s}->${t}:${relation}`;
    if (!edges.some((e) => e.id === eid)) edges.push({ id: eid, source: s, target: t, relation, confidence });
  };

  const rootId = id("process", topic.slug);
  push({ id: rootId, label: topic.name, kind: "process", tier: 0, confidence: "HIGH", detail: topic.overview });

  for (const g of topic.genes) {
    const gid = id("gene", g.symbol);
    push({
      id: gid,
      label: g.symbol,
      kind: "gene",
      tier: 1,
      confidence: g.confidence,
      detail: g.name,
      externalId: g.uniprot ? `UniProt ${g.uniprot}` : undefined,
      href: g.uniprot ? externalLink.uniprot(g.uniprot) : undefined,
    });
    link(rootId, gid, "associated with", g.confidence);
  }
  for (const p of topic.pathways) {
    const pid = id("pathway", p.name);
    push({
      id: pid,
      label: p.name,
      kind: "pathway",
      tier: 2,
      confidence: p.confidence,
      detail: p.summary,
      externalId: p.id,
      href: p.id && p.db === "Reactome" ? externalLink.reactome(p.id) : p.id && p.db === "Gene Ontology" ? externalLink.geneOntology(p.id) : undefined,
    });
    for (const g of topic.genes) link(id("gene", g.symbol), pid, "participates in", lower(g.confidence, p.confidence));
  }
  for (const pr of topic.processes) {
    const prid = id("process-sub", pr.name);
    push({ id: prid, label: pr.name, kind: "process", tier: 3, confidence: pr.confidence, detail: pr.tissue ? `Tissue: ${pr.tissue}` : undefined, externalId: pr.goId });
    for (const p of topic.pathways) link(id("pathway", p.name), prid, "associated with", lower(p.confidence, pr.confidence));
  }
  return { nodes, edges };
}

function lower(a: Confidence, b: Confidence): Confidence {
  return CONF_RANK[a] <= CONF_RANK[b] ? a : b;
}

/** Keep only relationships at or above a confidence floor, then drop orphans. */
export function filterGraph(graph: BiologyGraph, minConfidence: Confidence): BiologyGraph {
  const floor = CONF_RANK[minConfidence];
  const nodes = graph.nodes.filter((n) => CONF_RANK[n.confidence] >= floor || n.tier === 0);
  const keep = new Set(nodes.map((n) => n.id));
  const edges = graph.edges.filter(
    (e) => keep.has(e.source) && keep.has(e.target) && CONF_RANK[e.confidence] >= floor,
  );
  const connected = new Set<string>([...edges.flatMap((e) => [e.source, e.target])]);
  return {
    nodes: nodes.filter((n) => n.tier === 0 || connected.has(n.id)),
    edges,
  };
}

export interface PositionedNode extends GraphNode {
  x: number;
  y: number;
}

export interface GraphLayout {
  nodes: PositionedNode[];
  edges: GraphEdge[];
  width: number;
  height: number;
}

/** Deterministic layered layout: one column per tier, evenly spread rows. */
export function layoutGraph(graph: BiologyGraph, opts?: { columnWidth?: number; rowHeight?: number }): GraphLayout {
  const columnWidth = opts?.columnWidth ?? 210;
  const rowHeight = opts?.rowHeight ?? 62;
  const tiers = new Map<number, GraphNode[]>();
  for (const n of graph.nodes) {
    const list = tiers.get(n.tier) ?? [];
    list.push(n);
    tiers.set(n.tier, list);
  }
  const tierKeys = [...tiers.keys()].sort((a, b) => a - b);
  const maxRows = Math.max(1, ...tierKeys.map((k) => tiers.get(k)!.length));
  const height = maxRows * rowHeight + 60;
  const width = tierKeys.length * columnWidth + 60;

  const nodes: PositionedNode[] = [];
  tierKeys.forEach((tier, col) => {
    const list = tiers.get(tier)!;
    list.forEach((n, row) => {
      const span = height - 60;
      const y = list.length === 1 ? height / 2 : 30 + (span * row) / (list.length - 1);
      nodes.push({ ...n, x: 40 + col * columnWidth, y });
    });
  });

  return { nodes, edges: graph.edges, width, height };
}

/** All nodes reachable from a node, in either direction — used for path isolation. */
export function connectedTo(graph: BiologyGraph, nodeId: string): Set<string> {
  const result = new Set<string>([nodeId]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const e of graph.edges) {
      if (result.has(e.source) && !result.has(e.target)) {
        result.add(e.target);
        changed = true;
      }
      if (result.has(e.target) && !result.has(e.source)) {
        result.add(e.source);
        changed = true;
      }
    }
  }
  return result;
}
