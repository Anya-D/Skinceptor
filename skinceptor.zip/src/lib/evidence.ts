import type { Confidence, Study, StudyType } from "@/data/types";

/**
 * Skinceptor Evidence Index (experimental).
 *
 * A transparent, weighted research-navigation score. It is NOT a safety score,
 * an efficacy guarantee, or a clinical recommendation. Every component below is
 * computable from the curated study records, so the number can always be
 * explained back to the user.
 */

export type EvidenceStrength = "Strong" | "Moderate" | "Limited" | "Insufficient";

export interface EvidenceComponent {
  key: string;
  label: string;
  /** 0-1 normalised sub-score. */
  value: number;
  /** Weight in the composite. Weights sum to 1. */
  weight: number;
  explanation: string;
}

export interface EvidenceReport {
  index: number;
  strength: EvidenceStrength;
  components: EvidenceComponent[];
  counts: Record<StudyType, number>;
  total: number;
  humanCount: number;
  largestSample?: number | undefined;
  newestYear?: number | undefined;
  oldestYear?: number | undefined;
  quantitativeSynthesisPossible: boolean;
}

export const STUDY_TYPE_LABEL: Record<StudyType, string> = {
  human: "Human",
  rct: "Randomised controlled trial",
  animal: "Animal",
  "in-vitro": "In-vitro",
  review: "Review",
  "meta-analysis": "Meta-analysis",
};

/** Design-quality weights, highest for pooled human evidence. */
const DESIGN_QUALITY: Record<StudyType, number> = {
  "meta-analysis": 1,
  rct: 0.9,
  human: 0.7,
  review: 0.45,
  animal: 0.35,
  "in-vitro": 0.25,
};

export const EVIDENCE_WEIGHTS = {
  design: 0.28,
  human: 0.22,
  volume: 0.14,
  sample: 0.12,
  replication: 0.12,
  recency: 0.07,
  identifiers: 0.05,
} as const;

function clamp01(n: number) {
  return Math.max(0, Math.min(1, n));
}

export function emptyCounts(): Record<StudyType, number> {
  return { human: 0, rct: 0, animal: 0, "in-vitro": 0, review: 0, "meta-analysis": 0 };
}

export function computeEvidence(studies: Study[], currentYear = 2026): EvidenceReport {
  const counts = emptyCounts();
  for (const s of studies) counts[s.type] += 1;

  const total = studies.length;
  const humanCount = counts.human + counts.rct + counts["meta-analysis"];
  const samples = studies.map((s) => s.sampleSize).filter((n): n is number => typeof n === "number");
  const largestSample = samples.length ? Math.max(...samples) : undefined;
  const years = studies.map((s) => s.year);
  const newestYear = years.length ? Math.max(...years) : undefined;
  const oldestYear = years.length ? Math.min(...years) : undefined;

  const design = total ? studies.reduce((a, s) => a + DESIGN_QUALITY[s.type], 0) / total : 0;
  const human = total ? clamp01(humanCount / Math.max(3, total * 0.5)) : 0;
  const volume = clamp01(Math.log10(total + 1) / Math.log10(9));
  const sample = largestSample ? clamp01(Math.log10(largestSample) / 3) : 0;
  const humanStudies = studies.filter((s) => s.type === "human" || s.type === "rct");
  const replication = clamp01(humanStudies.length / 3);
  const recency = newestYear ? clamp01(1 - (currentYear - newestYear) / 20) : 0;
  const identified = studies.filter((s) => s.pmid || s.doi).length;
  const identifiers = total ? identified / total : 0;

  const components: EvidenceComponent[] = [
    {
      key: "design",
      label: "Study design quality",
      value: design,
      weight: EVIDENCE_WEIGHTS.design,
      explanation:
        "Mean design weight across curated studies (meta-analysis 1.0, RCT 0.9, other human 0.7, review 0.45, animal 0.35, in-vitro 0.25).",
    },
    {
      key: "human",
      label: "Human evidence share",
      value: human,
      weight: EVIDENCE_WEIGHTS.human,
      explanation: "Proportion of curated evidence measured in people rather than cells or animals.",
    },
    {
      key: "volume",
      label: "Evidence volume",
      value: volume,
      weight: EVIDENCE_WEIGHTS.volume,
      explanation: "Log-scaled count of curated studies, so volume alone cannot dominate the score.",
    },
    {
      key: "sample",
      label: "Largest sample size",
      value: sample,
      weight: EVIDENCE_WEIGHTS.sample,
      explanation: "Log-scaled largest reported sample size across curated human studies.",
    },
    {
      key: "replication",
      label: "Replication",
      value: replication,
      weight: EVIDENCE_WEIGHTS.replication,
      explanation: "Independent human studies, capped at three; one study is never treated as replicated.",
    },
    {
      key: "recency",
      label: "Recency",
      value: recency,
      weight: EVIDENCE_WEIGHTS.recency,
      explanation: "Linear decay over a twenty-year window from the most recent curated publication.",
    },
    {
      key: "identifiers",
      label: "Source traceability",
      value: identifiers,
      weight: EVIDENCE_WEIGHTS.identifiers,
      explanation: "Share of curated studies with a verified PMID or DOI in this dataset.",
    },
  ];

  const index = Math.round(components.reduce((a, c) => a + c.value * c.weight, 0) * 100);

  let strength: EvidenceStrength = "Insufficient";
  if (total === 0) strength = "Insufficient";
  else if (index >= 70 && humanStudies.length >= 2) strength = "Strong";
  else if (index >= 45 && humanCount >= 1) strength = "Moderate";
  else if (index >= 25) strength = "Limited";

  return {
    index,
    strength,
    components,
    counts,
    total,
    humanCount,
    largestSample,
    newestYear,
    oldestYear,
    /** Quantitative synthesis needs several comparable human studies. */
    quantitativeSynthesisPossible: humanStudies.length >= 4,
  };
}

export const confidenceLabel: Record<Confidence, string> = {
  HIGH: "High confidence",
  MEDIUM: "Medium confidence",
  LOW: "Low confidence",
};

export const strengthCopy: Record<EvidenceStrength, string> = {
  Strong: "Multiple independent human studies point in the same direction.",
  Moderate: "Some human evidence exists, but replication or sample sizes are limited.",
  Limited: "Mostly mechanistic, animal or single-study evidence.",
  Insufficient: "Not enough curated evidence to characterise this ingredient.",
};

export type ReplicationKey = "replicated" | "emerging" | "single-study" | "mechanistic" | "none";

export interface ReplicationFlag {
  key: ReplicationKey;
  label: string;
  detail: string;
}

/**
 * Describes how often an ingredient's effect has been seen in independent human
 * studies. Deliberately conservative: one human study is never "replicated",
 * and cell/animal-only evidence is labelled mechanistic rather than weak.
 */
export function replicationFlag(studies: Study[]): ReplicationFlag {
  const human = studies.filter((s) => s.type === "human" || s.type === "rct" || s.type === "meta-analysis");
  if (studies.length === 0)
    return { key: "none", label: "No curated studies", detail: "Nothing curated for this entry yet." };
  if (human.length === 0)
    return {
      key: "mechanistic",
      label: "Mechanistic only",
      detail: `${studies.length} curated ${studies.length === 1 ? "study" : "studies"}, none measured in people.`,
    };
  if (human.length === 1)
    return {
      key: "single-study",
      label: "Single human study",
      detail: "One curated human study — the finding has not been independently repeated in this dataset.",
    };
  if (human.length === 2)
    return {
      key: "emerging",
      label: "Repeated (2 studies)",
      detail: "Two independent human studies point the same way; more replication would strengthen this.",
    };
  return {
    key: "replicated",
    label: `Replicated (${human.length} studies)`,
    detail: `${human.length} independent human studies in the curated set.`,
  };
}

export const ABSOLUTE_CLAIM_WORDS = [
  "permanently",
  "permanent",
  "cures",
  "cure",
  "erases",
  "erase",
  "reverses",
  "reverse",
  "guaranteed",
  "guarantee",
  "instantly",
  "instant",
  "eliminates",
  "eliminate",
  "proven",
  "clinically proven",
  "miracle",
  "100%",
];

export interface OverstatementVerdict {
  overstated: boolean;
  reasons: string[];
  words: string[];
}

/**
 * Flags a claim as overstated relative to the curated evidence: absolute
 * marketing language, or strong wording sitting on thin/mechanistic evidence.
 */
export function assessOverstatement(claim: string, report: EvidenceReport, studies: Study[]): OverstatementVerdict {
  const lower = ` ${claim.toLowerCase()} `;
  const words = ABSOLUTE_CLAIM_WORDS.filter((w) => lower.includes(` ${w} `) || lower.includes(`${w} `));
  const reasons: string[] = [];
  if (words.length)
    reasons.push(
      `The wording uses absolute language (${words.join(", ")}). Biology in this field rarely supports permanence or guaranteed outcomes.`,
    );
  const flag = replicationFlag(studies);
  if (words.length && (flag.key === "single-study" || flag.key === "mechanistic" || flag.key === "none"))
    reasons.push(`Underlying evidence is ${flag.label.toLowerCase()}, which cannot carry a definitive claim.`);
  if (!words.length && report.total > 0 && report.strength === "Limited" && flag.key === "mechanistic")
    reasons.push("The mapped evidence is cell or animal work only, so an outcome-level claim runs ahead of it.");
  return { overstated: reasons.length > 0, reasons, words };
}
